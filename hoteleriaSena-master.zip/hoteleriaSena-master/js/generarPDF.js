function generarPDF(){
    setTimeout(gfg, 2500);
    function Generarpng(){
        const screenshotTarget = document.getElementById("PDF");

        html2canvas(screenshotTarget).then((canvas) =>{
        const base64image = canvas.toDataURL("image/png");
        var anchor = document.createElement("a");
        anchor.setAttribute("href", base64image);
        anchor.setAttribute("download","facturado.png")
        anchor.click();
        anchor.remove();
        })
    }
    Generarpng();
    function gfg() {
        // window.location.href="http://educapro.adsitech.com.co/Certificaciones.php";
        window.close()

    }
}