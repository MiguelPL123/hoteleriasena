
function iniModal(id){

    const v1 = document.getElementById("v1");
    const v2 = document.getElementById("v2");
    const v3 = document.getElementById("v3");
    const v4 = document.getElementById("v4");
    
    var modales = [v1,v2,v3,v4]
    OpenModal(modales,id);    
}

function OpenModal(modales,id){
    
    var classh = "active";
    if (id==4){
        var classh = "exactive";
    }
    
    for (var i = 0; i < modales.length; i+=1) {


        var element = modales[i];
        if(i=3){
            element.classList.remove("exactive");
        }else{
            element.classList.remove("active");

        }
    }
    modales[id-1].classList.add(classh);
}

function closeModals(id){
    const v1 = document.getElementById("v1");
    const v2 = document.getElementById("v2");
    const v3 = document.getElementById("v3");
    const v4 = document.getElementById("v4");
    
    var modales = [v1,v2,v3,v4]

    var classh = "active";

    if (id==4){
        var classh = "exactive";
    }
    for (var i = 0; i < modales.length; i+=1) {
        var element = modales[i];
        
       if(i == id-1){
            element.classList.remove(classh);
        }
      
    }
}
