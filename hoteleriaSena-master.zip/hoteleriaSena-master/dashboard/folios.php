<?php
    include("../includes/validacionAccesoDash.php");
    include("../includes/conexion.php");
    


    $result=mysqli_query($con,"SELECT * FROM `folios_extra` AS f INNER JOIN habitacion AS h ON f.idHabitacion=h.idHabitacion;");
    if(!$result) die("ERROR AL CONSULTAR FOLIOS EXTRAS");
    $folios=array();
    while ($row = mysqli_fetch_array($result)) {
        $folios[]=array(
            "codfolio"=>$row['folio_extra'],
            "habitacion"=>"Habitacion ".$row['numero_habitacion'],
            "foliomaestro"=>$row['folio_maestro'],
        );
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content ">
                
             
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Código Folio Extra</th>
                            <th>Habitación</th>
                            <th>Folio Maestro</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($folios as $key => $value):?>
                            <tr>
                                <td><?php echo $value['codfolio'];?></td>
    
                                <td><?php echo $value['habitacion'];?></td>
    
                                <td><?php echo $value['foliomaestro'];?></td>
    
                                <td class="tbOpt">
                                    <!-- <input type="button" class="bttn bttn4" value="Comsumo" onclick="window.location.href='forms/comsumohabitacion.php'"> -->
                                    <input type="button" class="bttn btn" value="Factura" onclick="window.location.href='forms/folioPersona.php'">
                                </td>
                            </tr>
                        <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
                
        <div class="modalContainer " id="v1"></div>
        <div class="modalContainer " id="v2"></div>
        <div class="modalContainer " id="v3"></div>
        <div class="modalContainer " id="v4"></div>


    </main>
</body>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>
    
    <script src="ajaxjs/checkout.js"></script>
    <script src="../js/table.js"></script>
    <script src="../js/modal.js"></script>
</html>