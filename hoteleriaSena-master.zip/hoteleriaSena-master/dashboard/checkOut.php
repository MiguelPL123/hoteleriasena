<?php
    include("../includes/validacionAccesoDash.php");
    include("../includes/conexion.php");
    
    $checkGlobal=array();
    unset($_SESSION['facturamaster']);
    
    if(isset($_REQUEST['fechaout'])){
        if(isset($_SESSION['reservaCode'])){
            $fechaout=$_POST['fechaout'];
            $reservaCodigo=$_SESSION['reservaCode'];

            $actualizar="UPDATE reserva SET date_out='$fechaout',fechaModificacion= CURRENT_DATE() WHERE cod_reserva='$reservaCodigo'";
            $qery=mysqli_query($con,$actualizar);

            if(!$qery){
                die("ERROR AL EDITAR CHECKOUT".mysqli_error($con));
            }
            header("Location: checkOut.php");
        }
    }
    
    if(isset($_SESSION['reservaCode'])){
        unset($_SESSION['reservaCode']);
    }

    $sql = "SELECT ca.categoria, h.numero_habitacion, h.precio, r.estado, r.cod_reserva, r.nit, r.date_in, r.date_out, r.numero_personas, cli.nombres, cli.apellidos FROM categorias_habitaciones AS ca 
    INNER JOIN habitacion AS h ON ca.codHab=h.codHab 
    INNER JOIN reserva AS r ON r.idhabitacion=h.idHabitacion
    INNER JOIN clientes AS cli ON r.cedula=cli.cedula WHERE r.estado!=1";
    $resultado = mysqli_query($con, $sql);
    if(!$resultado){
        die("ERROR AL CONSULTAR CHECK OUT".mysqli_error($con));
    }
    $checkout=array();
    $checkinIndividual=array();
    
    $estado=null;
    while($row = mysqli_fetch_array($resultado)){
        $estado=$row['estado'];
        if($estado==2){
            $checkout[]=array($row['cod_reserva'], $row['categoria'],$row['numero_habitacion'],$row['nit'],'Check-In',$row['nombres'],$row['apellidos'],$row['date_in'],$row['date_out'],$row['precio'],$row['numero_personas']);
            
            $checkinIndividual[]=array("codigoReserva"=>$row['cod_reserva'],
            "nombre"=>$row['nombres'],
            "apellido"=>$row['apellidos'],
            "categoria"=>$row['categoria'],
            "habitacion"=>$row['numero_habitacion'],
            "estado"=>'Check-In',"tipo"=>'Individual');
        
        }else{
            $checkout[]=array($row['cod_reserva'], $row['categoria'],$row['numero_habitacion'],$row['nit'],'Check-Out',$row['nombres'],$row['apellidos'],$row['date_in'],$row['date_out'],$row['precio'],$row['numero_personas']);
            $checkinIndividual[]=array("codigoReserva"=>$row['cod_reserva'],
            "nombre"=>$row['nombres'],
            "apellido"=>$row['apellidos'],
            "categoria"=>$row['categoria'],
            "habitacion"=>$row['numero_habitacion'],
            "estado"=>'Check-Out',"tipo"=>'Individual');
        
        }
    }

    $sql="SELECT rp.codigo_reserva, e.nombre, rp.folio_maestro, rp.estado FROM `reserva_grupal` AS rp INNER JOIN empresa as e WHERE rp.codigo_emp=e.codigo_emp and rp.estado!=1";
    $result=mysqli_query($con,$sql);
    if(!$result)die("error".mysqli_error($con));

    $checkinGurpal=array();
    while($row=mysqli_fetch_array($result)){
        $estado=$row['estado'];
        if($estado==3){
            $checkinGurpal[]=array("codigoReserva"=>$row['codigo_reserva'],
            "nombre"=>$row['nombre'],
            "apellido"=>$row['nombre'],
            "categoria"=>$row['folio_maestro'],
            "habitacion"=>$row['folio_maestro'],
            "estado"=>'Check-Out',"tipo"=>'Grupal');
        }else if($estado==5 || $estado==2){
            $checkinGurpal[]=array("codigoReserva"=>$row['codigo_reserva'],
            "nombre"=>$row['nombre'],
            "apellido"=>$row['nombre'],
            "categoria"=>$row['folio_maestro'],
            "habitacion"=>$row['folio_maestro'],
            "estado"=>'Check-In',"tipo"=>'Grupal');
        }
    }

    array_push($checkGlobal,$checkinIndividual);
    if (count($checkinGurpal)>0) {
        array_push($checkGlobal,$checkinGurpal);
    }

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content ">
                
             
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th class="tbId"># Reserva</th>
                            <th>Nombres</th>
                            <th>Categoria</th>
                            <th>Habitación</th>
                            <th>Estado</th>
                            <th>Tipo</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($checkGlobal as $value1):?>
                            <?php foreach($value1 as $value2):?>
                        <tr>
                            <td><?php echo $value2["codigoReserva"]?></td>
                            <?php if($value2['tipo']=="Individual"):?>
                                <td><?php echo $value2["nombre"]?>&nbsp;<?php echo $value2["apellido"]?></td>
                            <?php else:?>
                                <td><?php echo $value2["nombre"]?></td>
                            <?php endif;?>
                            <?php if($value2["tipo"]=="Individual"):?>
                                <td><?php echo $value2["categoria"]?></td>
                            <?php else: ?>     
                                <td>Folio Maestro:</td>
                            <?php endif;?>
                            <?php if($value2["tipo"]=="Individual"):?>
                                <td>Habitacion <?php echo $value2["habitacion"]?></td>
                            <?php else: ?>  
                                <td ><a href="#" codigoFolio="<?php echo $value2["habitacion"]?>" id="FExtra"><?php echo $value2["habitacion"]?></a></td>
                            <?php endif;?>
                            <td><?php echo $value2["estado"]?></td>
                            <td><?php echo $value2["tipo"]?></td>
                            <td class="tbOpt" tipo="<?php echo $value2["tipo"]?>" estado="<?php echo $value2["estado"]?>" NumHabitacion="<?php echo $value2["habitacion"]?>" codigoFolio="<?php echo  $value2["codigoReserva"]; ?>">
                                <input type="button" class="bttn btn1" value="Ver" id="VerCheckout" onclick="abrirModalCheck()">

                                <?php if($value2["estado"]=="Check-In" && $value2['tipo']=='Individual'):?>
                                    <input type="button" class="bttn bttn4" value="Consu" id="consumo" onclick="window.location.href='forms/consumo.php'">
                                <?php endif;?>
                            </td>
                        </tr>   
                           <?php endforeach;?>
                        <?php endforeach;       
                        ?>
<!-- forms/verRegistro__personas-grupal_check.php -->
                    </tbody>
                </table>
            </div>
        </div>
                
        <div class="modalContainer " id="v2"></div>
        <div class="modalContainer " id="v3"></div>
        <?php include("../includes/modales/checkOut.php") ?>
        <?php include("../includes/modales/checkOut4.php") ?>



    </main>
</body>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>
    
    <script src="ajaxjs/checkout.js"></script>
    <script src="../js/table.js"></script>
    <script src="../js/modal.js"></script>

    <script>
        function abrirModalCheck(){
            $(document).on('click', '#VerCheckout', function(){
            let element = $(this)[0].parentElement;
            let tipo = $(element).attr('tipo');

            if(tipo=='Individual'){
                document.getElementById('individual').style.display='block';
                document.getElementById('grupal').style.display='none';
                iniModal(1)
            }else{
                document.getElementById('individual').style.display='none';
                document.getElementById('grupal').style.display='block';
                iniModal(1)
            }
         });
        }        
    </script>
</html>