<?php
    include('../includes/conexion.php');
    include("../includes/validacionAccesoDash.php");
    unset($_SESSION['cedClie']);
    $result=mysqli_query($con,"SELECT * FROM clientes");
    if (!$result) {
        die("ERROR AL CONSULTAR CLIENTES ".mysqli_error($con));
    }

    $clientes=array();

    while ($row = mysqli_fetch_array($result)) {
        $clientes[]=array(
            "cedula"=>$row['cedula'],
            "nombres"=>$row['nombres'],
            "apellidos"=>$row['apellidos']
        );
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content ">
                <div class="head">
                    <a href="forms/newClien.php" class="bttn btnMg">+ Nueva cliente</a>
                    <a href="forms/verAcompa.php" class="bttn bttn4 btnMg">Acompañantes</a>

                </div>
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Identificación</th>
                            <th>Nombres</th>
                            <th>Apellidos</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clientes as $key => $value):?>
                        <tr>
                            <td><?php echo $value["cedula"]?></td>
                            <td><?php echo $value["nombres"]?></td>
                            <td><?php echo $value["apellidos"]?></td>
                            <td class="tbOpt" clie="<?php echo $value["cedula"]?>">
                                <a class="bttn btn" id="editarClie">Editar</a>
                                <input type="button" class="bttn btn3" value="Mostrar" id="mostrarClie" onclick="iniModal(2)">
                                <input type="button" class="bttn btn2" value="Eliminar" id="deleteClie" onclick="iniModal(3);">
                            </td>
                        </tr>
                        <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php include("../includes/modales/clientesVer.php") ?>
        <div class="modalContainer " id="v1"></div>
        <?php include("../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v4"></div>

  
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="../js/modal.js"></script>
<script src="ajaxjs/clientes.js"></script>
</html>