<?php

    include("../includes/validacionAccesoDash.php");


    include("../includes/conexion.php");

    $alerta=null;

    /* REGISTRAR NUEVA CATEGORIA */
    if(isset($_POST['nombre'])){
        $nombre=$_POST['nombre'];
        $nombreArchivo = $_FILES['imagen']['name'];
        $nombreTemporal = $_FILES['imagen']['tmp_name'];
        $ruta = "../images/habitaciones/". $nombreArchivo;

        $verificar = "SELECT * FROM categorias_habitaciones WHERE categoria='$nombre'";
        $buscar = mysqli_query($con,$verificar);
        if(!$buscar){
            die("ERROR AL BUSCAR CATEGORIA".mysqli_error($con));
        }else{
            if(mysqli_num_rows($buscar)>0){
                $alerta="ESTA CATEGORIA YA EXISTE";
            }else if(!empty($nombreArchivo)){             
                move_uploaded_file($nombreTemporal,"../images/habitaciones/". $nombreArchivo);
                $sql="INSERT INTO categorias_habitaciones(categoria,imagen) VALUES ('$nombre','$ruta')";
                $result = mysqli_query($con, $sql);
                if(!$result){
                    die("ERROR AL INSERTAR CATEGORIA".mysqli_error($con));
                }
        
                header("Location: catHab.php");
            }else{
                $alerta = "SELECCIONE UNA IMAGEN";
            }
        }
    }

    //EDITAR CATEGORIAS

    if(isset($_POST['categoria1'])){
        if(isset($_SESSION['ruta'])){
            $nombre = $_POST['categoria1'];
            $imagen = $_SESSION['ruta'];
            $id = $_SESSION['idCategoria'];
            $categoria=$_SESSION['NombreCategoria'];

            
            $nombreArchivo = $_FILES['imagen1']['name'];
            $nombreTemporal = $_FILES['imagen1']['tmp_name'];
            $ruta = "../images/habitaciones/". $nombreArchivo;
            


            $numRow=0;
            if($categoria!=$nombre){
                $verificar = "SELECT * FROM categorias_habitaciones WHERE categoria='$nombre'";
                $buscar=mysqli_query($con,$verificar);
                if(!$buscar){
                    die("ERROR AL VERIFICAR EXISTENCIA DE CATEGORIA".mysqli_error($con));
                }
                $numRow=mysqli_num_rows($buscar);
            }
            if($numRow>0){
                /* echo "YA EXISTE CATEGORIA CON ESE NOMBRE"; */
            }else{
                if(!empty($nombreArchivo)){
                    move_uploaded_file($nombreTemporal,"../images/habitaciones/". $nombreArchivo);
                        
                    $sql="UPDATE categorias_habitaciones SET categoria='$nombre', imagen='$ruta' WHERE codHab=$id";
                    $result = mysqli_query($con, $sql);
                    if(!$result){
                        die("ERROR AL ACTUALIZAR CATEGORIA CON NUEVA IMAGEN".mysqli_error($con));
                    } 
                    header("Location: catHab.php");
        
                }else{
                    $sql="UPDATE categorias_habitaciones SET categoria='$nombre', imagen='$imagen' WHERE codHab=$id";
                    $result = mysqli_query($con, $sql);
                    if(!$result){
                        die("ERROR AL ACTUALIZAR CATEGORIA".mysqli_error($con));
                    } 
                    header("Location: catHab.php");
                }       
            }
            
        }
    }

    //CONSULTAR CATEGORIAS
    $categorias=array();

    $sql = "SELECT * FROM categorias_habitaciones";
    $consulta = mysqli_query($con, $sql);

    if(!$consulta){
        die("ERROR AL CONSULTAR CATEGORIAS". mysqli_error($con));
    }

    while($registro = mysqli_fetch_array($consulta)){
        $categorias[]=array($registro['codHab'],$registro['categoria'],$registro['imagen']);
    }

    

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content">
               <div class="dual">
                    <div class="left minForm">
                 
                            <span>Categoria de habitaciones</span>
                       
                       <form method="POST" enctype="multipart/form-data">
                            <label for="">Categoria  </label>
                            <input type="text" name="nombre" placeholder="Categoria  " 
                            value="<?php if(isset($nombre)){echo $nombre;}?>" required>

                            <label for="">Imagen  </label>
                            <input type="file" placeholder="" name="imagen" onchange="displayImg(this,$(this))">

                            <img src="" alt="" id="cimg">

                            <?php if(isset($alerta)):?>
                            <div class="alert">
                                <p><?php echo $alerta;?></p>
                            </div>
                            <?php endif;?>
                            <div class="formFooter">
                                <input type="submit" value="Guardar cambios" class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2" onclick="quitarImg()">
                            </div>
                        </form>

                    </div>
                    <div class="right">
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th class="tbId">#</th>
                                    <th>Imagen</th>
                                    <th>Categoria</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categorias as $value):?>
                                <tr>
                                    <td><?php echo $value[0]?></td>
                                    <td> <img src="<?php echo $value[2]?>" alt=""></td>
                                    <td>
                                        <div class="tbItem">
                                            <span>Nombre:  <?php echo $value[1]?></span>
                                         </div>
                                     </td>
                                    <td class="tbOpt" categoria="<?php echo $value[0];?>" ruta="<?php echo $value[2]?>" categoriaNombre="<?php echo $value[1]?>">
                                        <input type="button" class="bttn btn" value="Editar" id="EditCategoria" onclick="iniModal(1)">
                                        <input type="button" class="bttn btn2" value="Eliminar" id="DeleteCategoria" onclick="iniModal(3)">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
        <div class="modalContainer " id="v2"></div>
        <?php include("../includes/modales/catHab.php") ?>
        <?php include("../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v3"></div>

        <div class="modalContainer " id="v4"></div>



    </main>
</body>
<script>
    function displayImg(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#cimg').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}
    function displayImg2(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#foto1').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}
    function quitarImg(){
        $('#cimg').attr('src', null);
    }
</script>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="ajaxjs/categoria.js"></script>
<script src="../js/modal.js"></script>
</html>