<?php
    function consultarcargoAlojamientoFolioExtra($folioExtra)
    {
        global $con;
        
        $fechaActual=consultarfechaactual();
        $alojamiento=0;
        
        //Consultar folio extra
        $sql="SELECT * FROM `folios_extra` as fm INNER JOIN habitacion as h ON fm.idHabitacion=h.idHabitacion WHERE folio_extra='$folioExtra';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR FOLIOS EXTRA". mysqli_error($con));
        $folioMaestro=null;
        $preciohab=0;
        while ($row = mysqli_fetch_array($result)) {
            $folioMaestro=$row['folio_maestro'];
            $preciohab=$row['precio'];
        }
        
        //Contar detalles de reserva
        $datos=consultardatosReservaGruapl($folioMaestro);
        $estadoReserva=$datos[0];
        $fechaSalida=$datos[1];

        //Consultar clientes en la habitacion
        $sql2="SELECT * FROM clie_reserva_grupál WHERE folio_extra='$folioExtra'";
        $result2= mysqli_query($con,$sql2);
        if(!$result2) die("ERROR AL CONSULTAR DATOS DE CLIENTES". mysqli_error($con));

        if (mysqli_num_rows($result2)>0) {
            while ($row2 = mysqli_fetch_array($result2)) {
                $fechallegada=$row2['fecha_llegada'];
                $fechaFinal=$fechaActual;
                if ($estadoReserva==3) {
                    $fechaFinal=$fechaSalida;
                }
                
                if ($fechallegada!=null) {
                    $fecha_inicio = strtotime($fechallegada);
                    $fecha_final = strtotime($fechaFinal);

                    if($fecha_inicio <= $fecha_final){
                        $datetime1 = date_create($fechallegada);
                        $datetime2 = date_create($fechaFinal);
                        $contador = date_diff($datetime1, $datetime2);
                        $differenceFormat = '%a';
                        $dias= 1;
                        $dias+=intval($contador->format($differenceFormat));
                        /* echo "$folioExtra: ".$dias."<br>"; */
                        $alojamiento+= ($preciohab*$dias);
                    }
                }
            }
        }

        return $alojamiento;
    }

    function consultarcargosextra($folioExtra){
        global $con;
        $consumos=array();
        //Consultar comsumos de folios
        $sql2="SELECT * FROM `cargos_folios_habitacion` AS c INNER JOIN servicios AS s ON c.codServicio=s.codServicio WHERE folioextra='$folioExtra'";
        $result2= mysqli_query($con,$sql2);
        if(!$result2) die("ERROR AL CONSULTAR DATOS DE COMSUMOS". mysqli_error($con));

        while ($row = mysqli_fetch_array($result2)) {
            $nombreservicio=$row['nombres'];
            $preciototalcargo=$row['total'];
            if (array_key_exists($nombreservicio,$consumos)) {
                $consumos[$nombreservicio]+=$preciototalcargo;
            }else{
                $consumos[$nombreservicio]=$preciototalcargo;
            }
        }

        return $consumos;
    }

    //Folio extra
    function consultafoliomaestro($folioextra)
    {
        global $con;
        $sql="SELECT * FROM `folios_extra` WHERE folio_extra='$folioextra';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR FOLIO MAESTRO CON EL EXTRA". mysqli_error($con));
        return mysqli_fetch_array($result)['folio_maestro'];
    }

?>