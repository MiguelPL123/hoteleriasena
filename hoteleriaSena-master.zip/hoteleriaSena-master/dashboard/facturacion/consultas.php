<?php

    
    function consultarcargoAlojamiento($folioMaestro)
    {
        global $con;
        
        $fechaActual=consultarfechaactual();
        $datos=consultardatosReservaGruapl($folioMaestro);
        $estadoReserva=$datos[0];
        $fechaSalida=$datos[1];
        $alojamiento=0;
        //Consultar folios extras y precios de habitaciones
        $sql="SELECT * FROM `folios_extra` as fm INNER JOIN habitacion as h ON fm.idHabitacion=h.idHabitacion WHERE folio_maestro='$folioMaestro';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR FOLIOS EXTRAS". mysqli_error($con));

        while ($row = mysqli_fetch_array($result)) {
            $folioExtra=$row['folio_extra'];
            $preciohab=$row['precio'];
            /* $datos[]=array($folioExtra,$preciohab); */

            //Consultar clientes en la habitacion
            $sql2="SELECT * FROM clie_reserva_grupál WHERE folio_extra='$folioExtra'";
            $result2= mysqli_query($con,$sql2);
            if(!$result2) die("ERROR AL CONSULTAR DATOS DE CLIENTES". mysqli_error($con));

            if (mysqli_num_rows($result2)>0) {
                while ($row2 = mysqli_fetch_array($result2)) {
                    $fechallegada=$row2['fecha_llegada'];
                    $fechaFinal=$fechaActual;
                    if ($estadoReserva==3) {
                        $fechaFinal=$fechaSalida;
                    }
                    
                    if ($fechallegada!=null) {
                        $fecha_inicio = strtotime($fechallegada);
                        $fecha_final = strtotime($fechaFinal);
    
                        if($fecha_inicio <= $fecha_final){
                            $datetime1 = date_create($fechallegada);
                            $datetime2 = date_create($fechaFinal);
                            $contador = date_diff($datetime1, $datetime2);
                            $differenceFormat = '%a';
                            $dias= 1;
                            $dias+=intval($contador->format($differenceFormat));
                            /* echo "$folioExtra: ".$dias."<br>"; */
                            $alojamiento+= ($preciohab*$dias);
                        }
                    }
                }
            }
        }

        return $alojamiento;
    }

    function consultarcargosextras($folioMaestro)
    {
        global $con;
        $consumos=array();
        //Consultar folios extras
        $sql="SELECT * FROM `folios_extra` WHERE folio_maestro='$folioMaestro';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR FOLIOS EXTRAS". mysqli_error($con));
        while ($row = mysqli_fetch_array($result)) {
            $folioExtra=$row['folio_extra'];

            //Consultar comsumos de folios
            $sql2="SELECT * FROM `cargos_folios_habitacion` AS c INNER JOIN servicios AS s ON c.codServicio=s.codServicio WHERE folioextra='$folioExtra'";
            $result2= mysqli_query($con,$sql2);
            if(!$result2) die("ERROR AL CONSULTAR DATOS DE COMSUMOS". mysqli_error($con));

            while ($row = mysqli_fetch_array($result2)) {
                $nombreservicio=$row['nombres'];
                $preciototalcargo=$row['total'];
                $codServicio=$row['codServicio'];
                $verificacionMaestro=validarcargosmaestro($folioMaestro,$codServicio);

                if ($verificacionMaestro) {
                    if (array_key_exists($nombreservicio,$consumos)) {
                        $consumos[$nombreservicio]+=$preciototalcargo;
                    }else{
                        $consumos[$nombreservicio]=$preciototalcargo;
                    }
                }
            }

        }

        return $consumos;
    }


    function validarcargosmaestro($foliomaestro,$servicio)
    {
        global $con;

        $sql="SELECT * FROM `cargos_reserva_maestro` WHERE folio_maestro='$foliomaestro' AND codServicio='$servicio';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR VALIDACION CARGOS EMPRESA". mysqli_error($con));
        if (mysqli_num_rows($result)>0) {
            return true;
        }else{
            return false;
        }
    }

    function consultarfechaactual(){
        global $con;
        $sql="SELECT DATE(NOW());";
        $result=mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR FECHA". mysqli_error($con));

        return mysqli_fetch_array($result)['DATE(NOW())'];

    }

    function consultardatosReservaGruapl($folioMaestro)
    {
        //Consultar Estado de reserva
        global $con;
        $datos=array();

        $sql="SELECT * FROM reserva_grupal WHERE folio_maestro='$folioMaestro';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR RESERVA GRUPAL". mysqli_error($con));
        while ($row = mysqli_fetch_array($result)) {
            $datos=[$row['estado'],$row['fecha_salida']];
        }
        return $datos;
    }

    function consultarFolioMaestro($codigo){
        global $con;
        $sql="SELECT * FROM reserva_grupal WHERE codigo_reserva='$codigo';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR RESERVA GRUPAL". mysqli_error($con));
        $folioMaestro=mysqli_fetch_array($result)["folio_maestro"];
        return $folioMaestro;
    }

    function consultardatospersonales($folio){
        global $con;

        $datosReserva=array();

        $sql="SELECT * FROM `reserva_grupal` AS g INNER JOIN empresa AS e ON g.codigo_emp=e.codigo_emp WHERE folio_maestro='$folio';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR RESERVA GRUPAL". mysqli_error($con));
        
        while ($row = mysqli_fetch_array($result)) {
            $datosReserva=array(
                'nombre'=>$row['nombre'],
                "cc"=>$row['nit'],
                "habitacion"=>consultarnumeroHabitaciones($folio),
                "noches"=>calculardiasdeestadia($row['fecha_llegada'],$row['fecha_salida']),
                "direccion"=>$row['direccion_emp'],
                "ciudad"=>$row['ciudad_emp'],
                "fechain"=>$row['fecha_llegada'],
                "fechaout"=>$row['fecha_salida'],
                "caja"=>combinacionNumerica(3),
                "plan"=>"CORP",
                "huesped"=>$row['contacto'],
                "ident"=>$row['cargo'],
                "compañia"=>$row['nombre'],
                "personas"=>$row['num_personas']
            );
        }

        return $datosReserva;
    }

    function combinacionNumerica($ndigitos){
        $codigo="";
        for ($i=0; $i < $ndigitos; $i++) {
            $numero=rand(0,9);
            $codigo=$codigo."$numero";
        }
        return $codigo;
    };

    function consultarnumeroHabitaciones($folio){
        global $con;
        $sql="SELECT COUNT(*) FROM folios_extra WHERE folio_maestro='$folio';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR # FOLIOS EXTRA". mysqli_error($con));
        $habitaciones=mysqli_fetch_array($result)["COUNT(*)"];
        return $habitaciones;
    }

    function calculardiasdeestadia($fechainicio,$fechafin)
    {
        $datetime1 = date_create($fechainicio);
        $datetime2 = date_create($fechafin);
        $contador = date_diff($datetime1, $datetime2);
        $differenceFormat = '%a';        
        $dias=intval($contador->format($differenceFormat));

        return $dias;
    }

    //Reserva individual
    function consultarhabitacion($habitacion)
    {
        global $con;
        $sql="SELECT * FROM habitacion WHERE idHabitacion='$habitacion';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR HABITACION". mysqli_error($con));
        return mysqli_fetch_array($result)['numero_habitacion'];
    }

    function consultarClientes($cliente)
    {
        global $con;

        $sql="SELECT * FROM `clientes` AS c INNER JOIN datos_cliente AS dt ON c.cedula=dt.cedula WHERE c.cedula='$cliente';";
        $result= mysqli_query($con,$sql);
        if(!$result) die("ERROR AL CONSULTAR CLIENTES". mysqli_error($con));
        $datosclientes=array();
        while ($row = mysqli_fetch_array($result)) {
            $datosclientes=array(
                "nombres"=>$row['nombres'],
                "cedula"=>$row['cedula'],
                "direccion"=>$row['direccion'],
                "ciudad"=>$row['ciudad']
            );
        }
        return $datosclientes;
        /* return mysqli_fetch_array($result)['numero_habitacion']; */
    }

    

?>