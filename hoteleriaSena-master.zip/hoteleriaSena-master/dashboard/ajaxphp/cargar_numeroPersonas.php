<?php
    include('../../includes/conexion.php');
    session_start();

    $numPersona = $_POST['numeroAcompañantes'];
    $codigoReserva=$_SESSION['code'];
    
    $_SESSION['numeropersonasAcom'] = $numPersona;
    
    $sql= "UPDATE reserva SET numero_personas=$numPersona WHERE cod_reserva='$codigoReserva'";
    $result = mysqli_query($con,$sql);

    if (!$result) {
        die('ERROR AL ACTUALIZAR RESERVAS'.mysqli_error($con));
    }
?>