<?php
    include('../../includes/conexion.php');
    session_start();
    $id = $_SESSION['reservaCode'];

    $dias =$_SESSION['dias'];

    $sql="SELECT c.nombres, h.numero_habitacion, r.date_out, da.numero_movil FROM clientes as c 
    INNER JOIN reserva AS r ON c.cedula=r.cedula 
    INNER JOIN habitacion AS h on h.idHabitacion = r.idhabitacion 
    INNER JOIN datos_cliente as da on da.cedula=c.cedula WHERE r.cod_reserva='$id'";
    $query=mysqli_query($con,$sql);

    if(!$query){
        die("ERROR AL CONSULTAR EN EDITAR CHECKOUT".mysqli_error($con));
    }

    $out=array();

    while($row = mysqli_fetch_array($query)){
        $out=array(
            "nombres" => $row['nombres'],
            "numero_habitacion" => $row['numero_habitacion'],
            "fecha_out" => $row['date_out'],
            "numero_movil" => $row['numero_movil'],
            "dias" => $dias,
        );
    }
    
    echo json_encode($out);
?>