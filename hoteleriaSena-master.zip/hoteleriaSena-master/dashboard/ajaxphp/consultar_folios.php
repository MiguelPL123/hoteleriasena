<?php
include('../../includes/conexion.php');
session_start();

$id = $_POST['id'];
$_SESSION['idFolio']=$id;

$sql = "SELECT * FROM servicios WHERE codServicio='$id'";
$result = mysqli_query($con,$sql);
if(!$result){
    die("ERROR AL BUSCAR FOLIO".mysqli_error($con));
}

$folio=array();

while($row = mysqli_fetch_array($result)){
    $folio=array(
        "codServicio" => $row['codServicio'],
        "nombres" => $row['nombres'],
        "precio" => $row['valor']
    );
}   
echo json_encode($folio);

?>