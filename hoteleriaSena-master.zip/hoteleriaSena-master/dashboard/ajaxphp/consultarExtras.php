<?php
    include('../../includes/conexion.php');
    session_start();
    if(isset($_POST['opcion'])){
        $idHab=$_POST['opcion'];

        $sql="SELECT c.nombres, c.apellidos, clie.cedula, fe.folio_extra FROM folios_extra AS fe INNER JOIN clie_reserva_grupál
         AS clie ON fe.folio_extra=clie.folio_extra 
         INNER JOIN clientes as c ON clie.cedula=c.cedula 
         INNER JOIN habitacion as h ON h.idHabitacion=fe.idHabitacion WHERE h.idHabitacion=$idHab and clie.fecha_llegada is null;
        ";

        $resp=mysqli_query($con,$sql);

        if(!$resp)die("error".mysqli_error($con));

        $dats=array();

        while($row = mysqli_fetch_array($resp)){
            $dats[]=array(
                "nombre" => $row['nombres'],
                "apellido" => $row['apellidos'],
                "cedula" => $row['cedula'],
                "extra" => $row['folio_extra'],
            );
        }
    
        echo json_encode($dats);
    }

?>
