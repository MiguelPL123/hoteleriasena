<?php

    session_start();

    $codfolio = $_POST['cod'];
    $tipoReserva = $_POST['tipo'];

    $_SESSION['facturamaster']= array(
        0 => $codfolio,
        2 => $tipoReserva
    );


?>