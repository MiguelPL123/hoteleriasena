<?php
session_start();

if(isset($_POST['id'])){
    $idExtra=$_POST['id'];
    $_SESSION['idExtra']=$idExtra;

    echo $_SESSION['idExtra'];
}

?>