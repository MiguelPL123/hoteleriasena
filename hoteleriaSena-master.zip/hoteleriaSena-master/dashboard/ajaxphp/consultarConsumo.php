<?php
include('../../includes/conexion.php');
session_start();
$idProd=$_POST['id'];
$_SESSION['idProductoConsumo']=$idProd;

$sql="SELECT idConsumo FROM consumo WHERE idConsumo='$idProd'";
$result= mysqli_query($con,$sql);
if (!$result) {
    die('ERROR AL CONSULTAR CONSUMOS'.mysqli_error($con));
}
$consumos=null;
while ($row = mysqli_fetch_array($result)) {
    $consumos=$row['idConsumo'];
}
echo $consumos;


?>