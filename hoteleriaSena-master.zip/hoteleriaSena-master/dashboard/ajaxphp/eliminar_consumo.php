<?php
    include("../../includes/conexion.php");
    session_start();
    $id=$_SESSION['idProductoConsumo'];

    $result= mysqli_query($con,"DELETE FROM consumo WHERE idConsumo='$id'");
    if(!$result){
        die("ERROR AL ELIMINAR DATOS DEL CONSUMO".mysqli_error($con));
    }  
    
?>