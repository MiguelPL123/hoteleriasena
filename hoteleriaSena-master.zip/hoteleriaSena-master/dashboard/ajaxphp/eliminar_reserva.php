<?php
    include("../../includes/conexion.php");
    session_start();
    $codReserva= $_SESSION['reservaEdit'];
    
    $sql="SELECT * FROM reserva WHERE cod_reserva='$codReserva'";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR RESERVAS");
    }

    $idHab= mysqli_fetch_array($result)['idhabitacion'];
    $updateHab=mysqli_query($con,"UPDATE habitacion SET estado='disponible' WHERE idHabitacion=$idHab");
    if (!$updateHab) {
        die("ERROR AL ACTUALIZAR ESTADO DE HABITACION".mysqli_error($con));
    }

    $sqldeleteReser="DELETE FROM reserva WHERE cod_reserva='$codReserva'";
    $deleteReserva=mysqli_query($con,$sqldeleteReser);
    if (!$deleteReserva) {
        die("ERROR AL ELIMINAR RESERVA".mysqli_error($con));
    }

    echo true;

?>