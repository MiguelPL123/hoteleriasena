<?php
include("../../includes/conexion.php");
session_start();
$id=$_SESSION['idHabitacion'];

$sql="DELETE FROM `habitacion` WHERE `habitacion`.`idHabitacion` = $id";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL ELIMINAR HABITACION".mysqli_error($con));
}
?>