<?php

use LDAP\Result;

include('../../includes/conexion.php');
session_start();
if(isset($_SESSION['codReserva'])){
    $code=$_SESSION['codReserva'];
    
    $sql="UPDATE reserva_grupal SET estado=3 WHERE codigo_reserva='$code'";
    $result=mysqli_query($con,$sql);
    if(!$result)die("error".mysqli_error($con));
}
?>