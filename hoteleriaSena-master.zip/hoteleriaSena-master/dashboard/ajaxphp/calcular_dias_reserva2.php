<?php 
    include('../../includes/conexion.php');
    session_start();

    $code = $_SESSION['code'];
    $fechaOut= $_POST['fechain'];
    
    
    $consulta="SELECT date_in FROM reserva WHERE cod_reserva ='$code'";
    $result=mysqli_query($con, $consulta);
    if(!$result){
        die("ERROR AL CONSULTAR FECHA IN".mysqli_error($con));
    }

    $fechaIn=mysqli_fetch_array($result)['date_in'];

    
    $FechaInicio = $fechaIn;
    $FechaFinal = $fechaOut;

    $dias=0;

    $a=strtotime($FechaInicio);
    $b=strtotime($FechaFinal);
    if($a < $b){
        $firstDate = $FechaInicio;
        $secondDate = $FechaFinal;
        $dateDifference = abs(strtotime($secondDate) - strtotime($firstDate));
        
        $years  = floor($dateDifference / (365 * 60 * 60 * 24));
        $months = floor(($dateDifference - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
        $days   = floor(($dateDifference - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 *24) / (60 * 60 * 24));
        $dias=$days;
            
    }

    echo $dias;

?>