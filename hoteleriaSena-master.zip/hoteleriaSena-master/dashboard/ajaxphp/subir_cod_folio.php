<?php
    session_start();
    $codFolio= $_POST['id'];
    $_SESSION['CodeFolio']=$codFolio;

?>