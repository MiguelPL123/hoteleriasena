<?php
    include('../../includes/conexion.php');
    $codReserva= $_POST['id'];
    $sql="SELECT clie.cedula,clie.nombres,clie.apellidos,clie.correo,dt.numero_movil,h.numero_habitacion,h.piso,r.tipo_pago,
          r.nit,r.date_in,r.date_out,r.cod_reserva FROM `reserva` AS r 
          INNER JOIN clientes AS clie ON r.cedula=clie.cedula INNER JOIN datos_cliente AS dt ON r.cedula=dt.cedula 
          INNER JOIN habitacion AS h ON r.idhabitacion=h.idHabitacion
          WHERE r.cod_reserva='$codReserva';";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR DATOS DE RESERVA".mysqli_error($con));
    }
    $datosReserva=array();
    while ($row = mysqli_fetch_array($result)) {
        $datosReserva=array(
            "cedula"=>$row['cedula'],
            "nombres"=>$row['nombres'],
            "apellidos"=>$row['apellidos'],
            "correo"=>$row['correo'],
            "movil"=>$row['numero_movil'],
            "habitacion"=>"Habitacion ".$row['numero_habitacion']." - Piso ".$row['piso'],
            "pago"=>$row['tipo_pago'],
            "nit"=>$row['nit'],
            "datein"=>$row['date_in'],
            "dateout"=>$row['date_out'],
            "codreserva"=>$row['cod_reserva'],
        );
    }

    /* Consultar Acomapañantes */
    $sqlAcompa="SELECT a.documento,a.nombre,a.apellido FROM `acom_reserva` AS ar INNER JOIN acompañantes AS a ON ar.documento=a.documento WHERE ar.codReserva='$codReserva';";
    $result= mysqli_query($con,$sqlAcompa);
    if (!$result) {
        die("ERROR AL CONSULTAR ACOMPAÑANTES DE RESERVA".mysqli_error($con));
    }
    $acompa=array();
    while ($row = mysqli_fetch_array($result)) {
        $acompa[]= array(
            "documento"=>$row['documento'],
            "nombres"=>$row['nombre']."".$row['apellido']
        );
    }
    $datosReserva["acompas"]=$acompa;
    echo json_encode($datosReserva);
?>