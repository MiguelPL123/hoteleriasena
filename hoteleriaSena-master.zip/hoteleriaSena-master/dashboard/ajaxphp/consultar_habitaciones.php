<?php

include('../../includes/conexion.php');
session_start();

$id = $_POST['id'];
$_SESSION['idHabitacion']=$id;
$numero=$_POST['habitacion'];
$_SESSION['numeroHabitacion']=$numero;

$Nhabitacion=$_POST['habitacion'];
$_SESSION['Nhabitacion']=$Nhabitacion;

$sql = "SELECT * FROM habitacion WHERE idHabitacion=$id";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL CONSULTAR HABITACION" .mysqli_error($con));
}
$habitacion=array();
$categoriaHab=array();

while($row = mysqli_fetch_array($result)){
    $idCategoriaHab=$row['codHab'];
    $habitacion=array(
        "numeroHabitacion" => $row['numero_habitacion'],
        "piso" => $row['piso'],
        "precio" => $row['precio'],
        "estado" => $row['estado'],
        "descripcion" => $row['descripcion'],
        "categoria" => $row['codHab'],
    );

    $sql1="SELECT * FROM categorias_habitaciones WHERE codHab=$idCategoriaHab";
    $result2=mysqli_query($con, $sql1);


    if(!$result2){
        die("ERROR AL CONSULTAR CATEGORIA".mysqli_error($con));
    }

    while($row2=mysqli_fetch_array($result2)){
        $categoriaHab=array(
            "codHab" => $row2['codHab'],
            "categoria"=>$row2['categoria']
        );
    }
}

$arreglo=array($habitacion,$categoriaHab);
echo json_encode($arreglo);

?>