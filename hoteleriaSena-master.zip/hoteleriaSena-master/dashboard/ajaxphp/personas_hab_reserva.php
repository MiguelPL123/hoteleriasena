<?php
    include("../../includes/conexion.php");
    session_start();
    if (isset($_POST['consulta'])) {
        $personas=$_SESSION['registrosClientes'];
        $personasMostrar=array();
        foreach ($personas as $key => $value) {
            if ($value["habitacion-asignada"]==null) {
                $personasMostrar[]=$value;
            }
        }
        echo json_encode($personasMostrar);
    }

    if (isset($_POST['cliente'])) {
        $cliente=$_POST['cliente'];
        $hab=$_POST['codHab'];

        /* Con esta session controlamos la cantidad de personas en una habitacion */

        //Si no existe la session la creamos
        if (!isset($_SESSION['habclie'])) {
            $_SESSION['habclie']=array();
        }
        //Si no existe todavia nadie asignado a esa habitacion la inicializamos para agregar
        if (!isset($_SESSION['habclie'][$hab])) {
            $_SESSION['habclie'][$hab]=1;
        }

        //Validamos que se pueda agregar a la habitacion
        if ($_SESSION['habclie'][$hab]<=2) {
            $sql="UPDATE habitacion SET estado='reservado' WHERE idHabitacion='$hab'";
            
            $result=mysqli_query($con,$sql);
            if (!$result) {
                die("ERROR AL ACTUALIZAR HABITACION". mysqli_error($con));
            }

            $_SESSION['registrosClientes'][$cliente]["habitacion-asignada"]=$hab;
            $_SESSION['habclie'][$hab]+=1;
            
        }else{
            echo true;
        }

    }
?>