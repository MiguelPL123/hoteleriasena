<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_POST['opcion'])){
        $idServicio=$_POST['opcion'];

        $sql="SELECT valor FROM `servicios` WHERE codServicio=$idServicio;";
        $result=mysqli_query($con,$sql);

        if(!$result)die("error".mysqli_error($con));

        $valor=mysqli_fetch_array($result)["valor"];

        echo $valor;
    }
?>