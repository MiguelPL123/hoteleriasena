<?php 
    include('../../includes/conexion.php');
    session_start();
    $doc=$_POST['search'];
    $_SESSION['cedAcom']=$doc;

    $sql= "SELECT * FROM `acompañantes` WHERE documento=$doc;";
    $result= mysqli_query($con,$sql);

    if (!$result) {
        die('ERROR AL CONSULTAR DATOS DE ACOMPAÑANTE'.mysqli_error($con));
    }

    $acompa=array();
    
    while ($row = mysqli_fetch_array($result)) {
        $acompa=array(
            "tipo"=>$row['tipoDoc'],
            "nombre"=>$row['nombre'],
            "apellido"=>$row['apellido'],
        );
    }

    echo json_encode($acompa);

?>