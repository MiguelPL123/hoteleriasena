<?php
    include("../../includes/conexion.php");
    session_start();
    $id=$_SESSION['idUser'];

    $result= mysqli_query($con,"DELETE FROM usuarios WHERE id=$id");
    if(!$result){
        die("ERROR AL ELIMINAR USUARIOS".mysqli_error($con));
    }
?>