<?php
session_start();

$codHab=$_POST['idHab'];

$_SESSION['idHab']=$codHab;


?>