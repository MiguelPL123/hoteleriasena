<?php
    include('../../includes/conexion.php');
    session_start();
    $id=$_POST['id'];
    /* $_SESSION['idreservagrup']=$id; */

    $sql="SELECT em.codigo_emp,em.nombre,medioreserva,contacto,cargo,fecha_contizacion,fecha_llegada,fecha_salida,num_personas,folio_maestro,codigo_reserva FROM `reserva_grupal` AS rg INNER JOIN empresa AS em ON rg.codigo_emp=em.codigo_emp WHERE rg.codigo_reserva='$id';";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("error al consultar dettales de reservacion".mysqli_error($con));
    }

    $info=array();

    while ($row = mysqli_fetch_array($result)) {
        $info=array(
            "codigoemp"=>$row['codigo_emp'],
            "nombre"=>$row['nombre'],
            "medio"=>$row['medioreserva'],
            "contacto"=>$row['contacto'],
            "cargo"=>$row['cargo'],
            "fechacotizacion"=>$row['fecha_contizacion'],
            "fechain"=>$row['fecha_llegada'],
            "fechaout"=>$row['fecha_salida'],
            "personas"=>$row['num_personas'],
            "folio"=>$row['folio_maestro'],
            "codigoreserva"=>$row['codigo_reserva'],
        );    
    }


    $foliomaestro=$info['folio'];
    $cargos=array();

    $sql="SELECT s.nombres,s.valor,c.total FROM `cargos_reserva_maestro` AS c INNER JOIN servicios AS s ON c.codServicio=s.codServicio WHERE c.folio_maestro='$foliomaestro';";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("error al consultar dettales de cargios de la reservacion".mysqli_error($con));
    }

    while ($row = mysqli_fetch_array($result)) {
        $cargos[]=array(
            "nombres"=>$row['nombres'],
            "valor"=>$row['valor'],
            "total"=>$row['total']
        );
    }

    $info["cargos"]=$cargos;
    $_SESSION["foliomaestroGrup"]=$foliomaestro;
    
    
    echo json_encode($info);
?>