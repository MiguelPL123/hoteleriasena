<?php
include('../../includes/conexion.php');
session_start();

$codigoReserva=$_SESSION['code'];
$id = $_POST['id'];

$sql= "DELETE FROM acom_reserva WHERE documento=$id AND codReserva='$codigoReserva';";
$result= mysqli_query($con,$sql);

if (!$result) {
    die("ERROR AL ELIMINAR ACOMPAÑANTE DE RESERVA".mysqli_error($con));
}

?>