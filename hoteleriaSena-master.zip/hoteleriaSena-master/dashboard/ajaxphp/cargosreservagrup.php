<?php
    session_start();
    /* Registrar Cargos */
    if (isset($_POST['cargo'])) {
        $CARGO=$_POST['cargo'];
        $NOMBRECARGO=$_POST['nombrecargo'];
        $PERSONAS=$_POST['numpersonas'];
        $VALOR=$_POST['valor'];
        $TOTAL=$_POST['total'];
    
        if (!isset($_SESSION['cargosReserva'])) {
            $_SESSION['cargosReserva']=array();
        }
    
        $_SESSION['cargosReserva'][$CARGO]=array(
            "codServicio"=>$CARGO,
            "descripcion"=>$NOMBRECARGO,
            "personas"=>$PERSONAS,
            "valor"=>$VALOR,
            "total"=>$TOTAL,
        );

        var_dump($_SESSION['cargosReserva']);
    }
    /* Consultar Cargos */
    if (isset($_POST['consultar'])) {
        $cargos=array();
        if (isset($_SESSION['cargosReserva'])) {
            
            foreach ($_SESSION['cargosReserva'] as $key => $value) {
                $cargos[]=array(
                    "cod"=>$value["codServicio"],
                    "descripcion"=>$value["descripcion"],
                    "numpersonas"=>$value["personas"],
                    "valor"=>$value["valor"],
                    "total"=>$value["total"]
                );
            }
        }
        echo json_encode($cargos);
    }
    /* Eliminar Cargos */
    if (isset($_POST['eliminar'])){
        $id=$_POST['id'];
        unset($_SESSION['cargosReserva'][$id]);
    }
?>