<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_SESSION['reservaGrup'])&& isset($_SESSION['folioMaestro'])){
        $reservaGrup=$_SESSION['reservaGrup'];
        $foliMaestr=$_SESSION['folioMaestro'];
        $sql="UPDATE reserva_grupal SET estado=2 WHERE codigo_reserva='$reservaGrup'";
        $result=mysqli_query($con,$sql);
        if(!$result)die("error".mysqli_error($con));
        
        $sql="UPDATE folios_extra SET estado='checked' WHERE folio_maestro='$foliMaestr'";
        $result=mysqli_query($con,$sql);
        if(!$result)die("error".mysqli_error($con));
    }
?>