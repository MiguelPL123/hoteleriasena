<?php

    include('../../includes/conexion.php');

    if(isset($_POST['search'])){
        $nit= $_POST['search'];
    
        $sql="SELECT * FROM empresa WHERE nit='$nit'";
        $result= mysqli_query($con,$sql);
        if (!$result) {
            die("ERROR AL CONSULTAR EMPRESA".mysqli_error($con));
        }
        $empresa=array();
        while ($row = mysqli_fetch_array($result)) {
            $empresa= array(
                "nombre"=> $row['nombre'],
                "correo"=> $row['correo']
            );
        }
    
        echo json_encode($empresa);
    }

    if(isset($_POST['buscarEmp'])){
        $emp=$_POST['buscarEmp'];
       
        $result= mysqli_query($con,"SELECT * FROM empresa WHERE codigo_emp='$emp' OR nit='$emp'");
        
        if (!$result) die("ERROR AL CONSULTAR EMPRESA".mysqli_error($con));
        
        $empresa=array();
        while ($row = mysqli_fetch_array($result)) {
            $empresa= array(
                "codigo"=> $row['codigo_emp'],
                "nombre"=> $row['nombre'],
                "correo"=> $row['correo'],
                "nit"=> $row['nit'],
                "paisCod"=> $row['paisCod'],
                "ciudad_emp"=> $row['ciudad_emp'],
                "direccion_emp"=> $row['direccion_emp'],
                "contacto_emp"=> $row['contacto_emp'],
            );
        }

        if (count($empresa)>0) {
            $result=mysqli_query($con,"SELECT * FROM ciudades WHERE Paises_Codigo='".$empresa['paisCod']."'");
            if (!$result) die("ERROR AL CONSULTAR CIUDADES".mysqli_error($con));
    
            $ciudades=array();
    
            while ($row = mysqli_fetch_array($result)) {
                $ciudades[]= array(
                    "ciudad" => $row['Ciudad']
                );
            }
    
            $empresa["ciudades"]=$ciudades;
        }


        echo json_encode($empresa);
    }

    if(isset($_POST['opcion'])){
        $id=$_POST['opcion'];

        $result=mysqli_query($con,"SELECT * FROM ciudades WHERE Paises_Codigo='$id'");

        if (!$result) die("ERROR AL CONSULTAR CIUDADES".mysqli_error($con));

        $ciudades=array();

        while($row = mysqli_fetch_array($result)){
            $ciudades[]= array(
                "Paises_Codigo" => $row['Paises_Codigo'],
                "ciudad" => $row['Ciudad'],
            );
        }

        echo json_encode($ciudades);
    }

    if (isset($_POST['rellenado'])) {
        /* Consultar empresas registradas */
        $result=mysqli_query($con,"SELECT COUNT(*) FROM empresa;");
        if(!$result) die("ERROR AL CONTAR TABLA EMPRESA".mysqli_error($con));

        $numero=mysqli_fetch_array($result)['COUNT(*)'];
        /* -------------------------------- */
        
        //Funciones para generar codigos para la reserva
        function combinacionAutoreLlenado($numero){//Ejemplo: 00001
            $longitud=strlen($numero);
            $codigo="";
            for ($i=0; $i < (6-$longitud); $i++) { 
                $codigo=$codigo."0";
            }
            $codigo=$codigo.($numero+1);
            return $codigo;
        }

        echo combinacionAutoreLlenado($numero);

    }
?>