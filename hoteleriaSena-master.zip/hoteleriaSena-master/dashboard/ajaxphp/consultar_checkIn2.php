<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_POST['reservaGrup'])){
        $reservaGrup=$_POST['reservaGrup'];
        $folioMaestro=$_POST['folioMaestro'];
        $_SESSION['folioMaestro']=$folioMaestro;
        $_SESSION['reservaGrup']=$reservaGrup;

        $sql="SELECT r.folio_maestro, r.codigo_reserva, fe.folio_extra, fe.idHabitacion, h.numero_habitacion
        FROM reserva_grupal AS r 
        INNER JOIN folios_extra AS fe ON fe.folio_maestro=r.folio_maestro INNER JOIN habitacion as h ON h.idHabitacion=fe.idHabitacion WHERE r.codigo_reserva='$reservaGrup' and fe.estado='pendiente'";

        $resp=mysqli_query($con,$sql);

        if(!$resp)die("error".mysqli_error($con));

        $datos=array();
        while($row = mysqli_fetch_array($resp)){
            $datos[]=array(
                "folio_maestro" => $row['folio_maestro'],
                "idHabitacion" => $row['idHabitacion'],
                "numero_habitacion" => $row['numero_habitacion'],
            );

        }
        
        
        echo json_encode($datos);
    }
/* 
    SELECT r.folio_maestro, r.codigo_reserva, fe.folio_extra, fe.idHabitacion, h.numero_habitacion
        FROM reserva_grupal AS r 
        INNER JOIN folios_extra AS fe ON fe.folio_maestro=r.folio_maestro INNER JOIN habitacion as h ON h.codHab=fe.idHabitacion WHERE r.codigo_reserva='7p3p3k' and fe.estado='pendiente'; */
?>