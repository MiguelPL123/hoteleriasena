<?php
    include('../../includes/conexion.php');
    session_start();

    $id = $_POST['id'];
    $_SESSION['reservaCode']=$id;
    $_SESSION['code']=$id;
    $habit = $_POST['numHabi'];
    $_SESSION['numeroHabitacion']=$habit;
    
    $checked=array();
    $cheked=array();
    $FechaFinal=null;
    $FechaInicio=null;
    $monto=0;
    $days=null;
    $subtotal=0;
    $iva=0.19;
    $precio = 0;
    $personas=0;

    
    if(isset($_POST['id'])){
        $sql="SELECT ca.categoria, h.precio, r.nit, r.date_in, r.date_out, r.hora_in, r.hora_out, r.cod_reserva, r.estado, r.numero_personas FROM categorias_habitaciones AS ca 
        INNER JOIN habitacion AS h ON ca.codHab=h.codHab 
        INNER JOIN reserva AS r ON r.idhabitacion=h.idHabitacion 
        WHERE r.cod_reserva='$id'";
        $resultad = mysqli_query($con, $sql);
    
    
        if(!$resultad){
            die("ERROR AL CONSULTAR CHECK OUT" .mysqli_error($con));
        }
        while($row=mysqli_fetch_array($resultad)){
            $checked=array(
                "categoria" => $row['categoria'],
                "precio" => $row['precio'],
                "referencia" => $row['nit'],
                "cod_reserva" => $row['cod_reserva'],
                "fecha_in" => $row['date_in'],
                "fecha_out" => $row['date_out'],
                "hora_in" => $row['hora_in'],
                "hora_out" => $row['hora_out'],
                "estado" => $row['estado'],
                "dias" => $days,
                "monto" => $monto,
            );
            $FechaFinal=$row['date_out'];
            $FechaInicio=$row['date_in'];
            $personas=$row['numero_personas'];
            $precio=$row['precio'];


        }
    }

    if(isset($_POST['id'])){
        $a=strtotime($FechaInicio);
        $b=strtotime($FechaFinal);
        if($a < $b){
            $firstDate = $FechaInicio;
            $secondDate = $FechaFinal;
            $dateDifference = abs(strtotime($secondDate) - strtotime($firstDate));
        
            $years  = floor($dateDifference / (365 * 60 * 60 * 24));
            $months = floor(($dateDifference - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
            $days   = floor(($dateDifference - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 *24) / (60 * 60 * 24));
            $_SESSION['dias']=$days;
            
        }
        
    }
    $sql2="SELECT * FROM detalles_reserva WHERE cod_reserva='$id'";
    $result = mysqli_query($con, $sql2);
    if(!$result){
        die("ERROR AL CONSULTAR DETALLES RESERVA" .mysqli_error($con));
    }
    $garantia=0;
    $adelanto=0;
    if(mysqli_num_rows($result)>0){
        while($row1 = mysqli_fetch_array($result)){
            $garantia=$row1['garantia'];
            $adelanto=$row1['deposito'];
        }
        $subtotal=$precio*$days*$personas;
        $iva=$subtotal*0.19;
        $subtotal=$subtotal+$iva;
        $subtotal=$subtotal-$adelanto;
        $monto=$subtotal;

    }else{
        $subtotal= $precio * $personas * $days;
        $iva=$subtotal*0.19;
        $monto = $subtotal+$iva;
    }

    if(isset($monto)){
        $sql="SELECT ca.categoria, h.precio, r.nit, r.date_in, r.date_out, r.hora_in, r.hora_out, r.cod_reserva, r.estado, r.numero_personas FROM categorias_habitaciones AS ca 
        INNER JOIN habitacion AS h ON ca.codHab=h.codHab 
        INNER JOIN reserva AS r ON r.idhabitacion=h.idHabitacion 
        WHERE r.cod_reserva='$id'";
        $result = mysqli_query($con, $sql);
    
    
        if(!$result){
            die("ERROR AL CONSULTAR CHECK OUT" .mysqli_error($con));
        }
        $check=array();
        while($row = mysqli_fetch_array($result)){
            $check=array(
                "categoria" => $row['categoria'],
                "precio" => $row['precio'],
                "referencia" => $row['nit'],
                "cod_reserva" => $row['cod_reserva'],
                "fecha_in" => $row['date_in'],
                "fecha_out" => $row['date_out'],
                "hora_in" => $row['hora_in'],
                "hora_out" => $row['hora_out'],
                "estado" => $row['estado'],
                "dias" => $days,
                "monto" => $monto,
    
            );
        }
        echo json_encode($check);
    }
    
?>