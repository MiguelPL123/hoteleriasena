<?php
session_start();

$id=$_POST['id'];
$_SESSION['codigoReserva2']=$id;

?>