<?php
include('../../includes/conexion.php');
$opcion=$_POST['opcion'];

$sql2 = "SELECT * FROM servicios WHERE codServicio='$opcion'";
$result = mysqli_query($con, $sql2);
if(!$result){
    die("ERROR AL CONSULTAR SERVICIOS".mysqli_error($con));
}
$precio = 0;

while ($row = mysqli_fetch_array($result)) {
    $precio = $row['valor'];
}
echo $precio;

?>