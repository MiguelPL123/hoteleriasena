<?php
    include('../../includes/conexion.php');
    session_start();
    $id=$_POST['id'];
    $_SESSION['cedClie']= $id;

    $sql="SELECT * FROM `clientes` AS c INNER JOIN datos_cliente AS da ON c.cedula=da.cedula WHERE c.cedula=$id";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR INFORMACION DEL CLIENTE ".mysqli_error($con));
    }
    $cliente=array();

    while ($row = mysqli_fetch_array($result)) {
        $cliente= array(
            "tipo"=>$row['tipo'],
            "cedula"=>$row['cedula'],
            "nombres"=>$row['nombres'],
            "apellidos"=>$row['apellidos'],
            "correo"=>$row['correo'],
            "pais"=>$row['pais'],
            "fechanacimiento"=>$row['fecha_nacimiento'],
            "lugarnacimiento"=>$row['lugar_nacimiento'],
            "ciudad"=>$row['ciudad'],
            "direccion"=>$row['direccion'],
            "genero"=>$row['genero'],
            "correocorporativo"=>$row['correo_corporativo'],
            "numerofijo"=>$row['numero_fijo'],
            "numeromovil"=>$row['numero_movil'],
            "numeroauxiliar"=>$row['numero_auxiliar']
        );
    }

    echo json_encode($cliente);
?>