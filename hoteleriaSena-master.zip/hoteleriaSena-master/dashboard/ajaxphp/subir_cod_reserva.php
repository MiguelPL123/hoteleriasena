<?php
    session_start();
    $codReserva= $_POST['id'];
    $_SESSION['reservaEdit']=$codReserva;
?>