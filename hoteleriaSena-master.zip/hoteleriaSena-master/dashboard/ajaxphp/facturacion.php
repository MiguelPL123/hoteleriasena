<?php
session_start();

$id=$_POST['id'];
$estado=$_POST['estado'];
$tipo=$_POST['tipo'];


$_SESSION['facturamaster']=array($id,$estado,$tipo);

?>