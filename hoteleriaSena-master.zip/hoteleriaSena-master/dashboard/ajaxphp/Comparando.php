<?php
session_start();

$idHab=$_SESSION['idHab'];
$id=$_POST['opcion'];

$arreglob[]=array("idHab"=>$idHab, "id"=>$id);

$_SESSION['arreglob'][]=$arreglob;

unset($_SESSION['registropersonas'][$id]);

var_dump($_SESSION['arreglob']);

?>