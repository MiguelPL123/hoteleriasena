<?php

include('../../includes/conexion.php');

if(isset($_POST['npersonas'])){
    $personas=$_POST['npersonas'];
    $_SESSION['personas']=$personas;
}
if(isset($_POST['opcion'])){
    $servicio=$_POST['opcion'];

    $sql=mysqli_query($con, "SELECT valor FROM `servicios` WHERE codServicio=$servicio");
    if(!$sql)die("ERROR".mysqli_error($con));

    $valor=mysqli_fetch_array($sql);

    $valor=array("valor"=>$valor['valor']);
    echo json_encode($valor);

}
?>