<?php
    include('../../includes/conexion.php');
    session_start();

    $id = $_SESSION['reservaCode'];
    $habitacion = $_SESSION['numeroHabitacion'];

    $sql="UPDATE reserva SET estado=3 WHERE cod_reserva='$id'";
    $resultado = mysqli_query($con, $sql);

    if(!$resultado){
        die("ERROR AL ACTUALIZAR ESTADO CHECK OUT".mysqli_error($con));
    }

    $consult= mysqli_query($con,"SELECT * FROM habitacion WHERE numero_habitacion='$habitacion'");
    if(!$consult){
        die("ERROR AL CONSULTAR HABITACION".mysqli_error($con));
    }
    $habitaciondesocupada=array();
    while ($row = mysqli_fetch_array($consult)) {
        $habitaciondesocupada= array(
            "habi"=>$row['numero_habitacion'],
            "piso"=>$row['piso']
        );
    }

    $sql2="UPDATE habitacion SET estado='vacia sucia' WHERE numero_habitacion='$habitacion'";
    $resul = mysqli_query($con, $sql2);

    if(!$resul){
        die("ERROR AL ACTUALIZAR ESTADO HABITACION CHECK OUT".mysqli_error($con));
    }

    echo json_encode($habitaciondesocupada);
?>