<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_POST['id'])){
        $folioMaestro=$_POST['id'];
        $_SESSION['idFolioMaestro']=$folioMaestro;

        echo $_SESSION['idFolioMaestro'];
    }

?>