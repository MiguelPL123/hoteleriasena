<?php
include("../../includes/conexion.php");
session_start();
$id=$_SESSION['idFolio'];

$sql="DELETE FROM servicios WHERE codServicio = '$id'";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL ELIMINAR SERVICIO".mysqli_error($con));
}

?>