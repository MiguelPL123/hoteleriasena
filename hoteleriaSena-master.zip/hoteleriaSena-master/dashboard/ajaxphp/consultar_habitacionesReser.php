<?php

include('../../includes/conexion.php');
$idCategoria=$_POST['opcion'];

$sql="SELECT * FROM habitacion WHERE codHab=$idCategoria AND estado='disponible' ORDER BY `piso` ASC";
$result= mysqli_query($con,$sql);
if (!$result) {
    die('ERROR AL CONSULTAR HABITACIONES'.mysqli_error($con));
}
$habitaciones=array();
while ($row = mysqli_fetch_array($result)) {
    $habitaciones[]= array(
        "id"=>$row['idHabitacion'],
        "habitacion"=>"Habitacion ".$row['numero_habitacion']." - Piso ".$row['piso']
    );
}

echo json_encode($habitaciones);

?>