<?php

include('../../includes/conexion.php');
session_start();

$id = $_POST['id'];
$_SESSION['idCategoria']=$id;
$url = $_POST['url'];
$_SESSION['ruta']=$url;
$categoria=$_POST['categoria'];
$_SESSION['NombreCategoria']=$categoria;

$sql = "SELECT * FROM categorias_habitaciones WHERE codHab=$id";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL CONSULTAR CATEGORIA HABITACION" .mysqli_error($con));
}
$categoria=array();

while($row = mysqli_fetch_array($result)){
    $categoria=array(
        "categoria" => $row['categoria'],
        "imagen" => $row['imagen'],
    );
}


echo json_encode($categoria);

?>