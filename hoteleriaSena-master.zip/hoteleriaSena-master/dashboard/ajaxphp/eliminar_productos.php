<?php
include("../../includes/conexion.php");
session_start();
$id=$_SESSION['idProducto'];

$sql="DELETE FROM `producto` WHERE `producto`.`idProducto` = '$id'";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL ELIMINAR PRODUCTOS".mysqli_error($con));
}
?>