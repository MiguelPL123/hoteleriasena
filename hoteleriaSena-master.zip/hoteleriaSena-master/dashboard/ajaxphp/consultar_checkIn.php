<?php
    include('../../includes/conexion.php');
    session_start();

    $id = $_POST['id'];
    $_SESSION['code']=$id;
 
       

    $sql="SELECT c.nombres, d_c.numero_movil, r.date_in, r.hora_in, c.cedula, r.cod_reserva, r.date_out,r.numero_personas
          FROM reserva AS r 
          INNER JOIN clientes AS c ON r.cedula=c.cedula
          INNER JOIN datos_cliente AS d_c ON c.cedula= d_c.cedula WHERE r.cod_reserva='$id'";
    $result = mysqli_query($con, $sql);

    if(!$result){
        die("ERROR AL CONSULTAR CHECK IN" .mysqli_error($con));
    }
    $check=array();

    $FechaInicio=null;
    $FechaFinal=null;
    while($row = mysqli_fetch_array($result)){
        
        $FechaInicio=$row['date_in'];
        $FechaFinal=$row['date_out'];
        
        $FechaInicio = date('Y-m-d');
        $FechaFinal = date('Y-m-d');
    
        $days=null;
    
        $a=strtotime($FechaInicio);
        $b=strtotime($FechaFinal);
        if($a < $b){
            $firstDate = $FechaInicio;
            $secondDate = $FechaFinal;
            $dateDifference = abs(strtotime($secondDate) - strtotime($firstDate));
            
            $years  = floor($dateDifference / (365 * 60 * 60 * 24));
            $months = floor(($dateDifference - $years * 365 * 60 * 60 * 24) / (30 * 60 * 60 * 24));
            $days   = floor(($dateDifference - $years * 365 * 60 * 60 * 24 - $months * 30 * 60 * 60 *24) / (60 * 60 * 24));
        
        }

        $check=array(
            "cod_reserva" => $row['cod_reserva'],
            "nombres" => $row['nombres'],
            "cedula" => $row['cedula'],
            "numero" => $row['numero_movil'],
            "fecha_in" => $row['date_in'],
            "fecha_out" => $row['date_out'],
            "hora_in" => $row['hora_in'],
            "dias" => $days,
            "personas" => $row['numero_personas']
        );
    }


        

    echo json_encode($check);

?>