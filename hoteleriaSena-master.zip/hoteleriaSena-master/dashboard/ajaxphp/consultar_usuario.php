<?php
include('../../includes/conexion.php');
session_start();

$idUser= $_POST['id'];
$_SESSION['idUser']=$idUser;

$result = mysqli_query($con,"SELECT * FROM usuarios WHERE id=$idUser");
if (!$result) {
    die('ERROR AL CONSULTAR DATOS DEL USUARIO'.mysqli_error($con));
}

$usuario=array();

while ($row = mysqli_fetch_array($result)) {
    $usuario= array(
        "nombres"=>$row['nombres'],
        "usuario"=>$row['usuario'],
        "contra"=>$row['contrasena'],
        "tipo"=>$row['tipo'],
    );
}

echo json_encode($usuario);

?>