<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_POST['id'])){
        $cod=$_POST['id'];
        $_SESSION['folioExtra']=$cod;

        $sql="SELECT c.descripcion, c.total, c.fechacargo, c.folioextra, c.idcargoextras, s.nombres, s.valor FROM `cargos_folios_habitacion` as c INNER JOIN servicios as s ON s.codServicio=c.codServicio WHERE c.folioextra='$cod';";
        $consult=mysqli_query($con,$sql);
        if(!$consult)die("error".mysqli_error($con));
    
        $array=array();

        while($row = mysqli_fetch_array($consult)){
            $array[]=array(
                "descripcion"=>$row['descripcion'],
                "total"=>$row['total'],
                "valor"=>$row['total']-($row['total']*0.08),
                "fechacargo"=>$row['fechacargo'],
                "folioextra"=>$row['folioextra'],
                "idcargoextras"=>$row['idcargoextras'],
                "nombres"=>$row['nombres']
            );
        }
        echo json_encode($array);
    }

?>