<?php
include("../../includes/conexion.php");
session_start();
$id=$_SESSION['idCategoria'];

$sql="DELETE FROM `categorias_habitaciones` WHERE `categorias_habitaciones`.`codHab` = $id";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL ELIMINAR CATEGORIA".mysqli_error($con));
}
?>