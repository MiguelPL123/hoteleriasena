<?php
    include("../../includes/conexion.php");
    session_start();
    $id=$_SESSION['cedClie'];

    $result= mysqli_query($con,"DELETE FROM datos_cliente WHERE cedula=$id");
    if(!$result){
        die("ERROR AL ELIMINAR DATOS DEL CLIENTE".mysqli_error($con));
    }else{
        $result2= mysqli_query($con,"DELETE FROM clientes WHERE cedula=$id");
        if(!$result2){
            die("ERROR AL ELIMINAR CLIENTE".mysqli_error($con));
        }   
    }
?>