<?php
include('../../includes/conexion.php');
session_start();

$id = $_POST['id'];
$_SESSION['idProducto']=$id;

$sql = "SELECT * FROM producto WHERE idProducto='$id'";
$result = mysqli_query($con,$sql);
if(!$result){
    die("ERROR AL BUSCAR PRODUCTOS".mysqli_error($con));
}

$productos=array();

while($row = mysqli_fetch_array($result)){
    $productos=array(
        "nombre" => $row['nombre'],
        "precio" => $row['precio'],
        "descripcion" => $row['descripcion'],
        "codeProd" => $row['idProducto'],

    );
}   

echo json_encode($productos);

?>