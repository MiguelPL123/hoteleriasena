<?php 
    include('../../includes/conexion.php');
    $ced=$_POST['search'];

    $sql= "SELECT c.tipo,c.nombres,c.apellidos,da.fecha_nacimiento,da.lugar_nacimiento,da.pais,da.ciudad,da.direccion,da.genero,c.correo,da.correo_corporativo,da.numero_movil,da.numero_auxiliar FROM `clientes` AS C INNER JOIN datos_cliente AS da ON c.cedula=da.cedula WHERE c.cedula=$ced;";
    $result= mysqli_query($con,$sql);

    if (!$result) {
        die('ERROR AL CONSULTAR DATOS DE CLIENTE'.mysqli_error($con));
    }

    $clientes=array();
    
    while ($row = mysqli_fetch_array($result)) {
        $clientes=array(
            "tipo"=>$row['tipo'],
            "nombre"=>$row['nombres'],
            "apellido"=>$row['apellidos'],
            "fecha"=>$row['fecha_nacimiento'],
            "lugar"=>$row['lugar_nacimiento'],
            "pais"=>$row['pais'],
            "ciudad"=>$row['ciudad'],
            "direccion"=>$row['direccion'],
            "genero"=>$row['genero'],
            "correo"=>$row['correo'],
            "correoCor"=>$row['correo_corporativo'],
            "telefono"=>$row['numero_movil'],
            "numeroauxiliar"=>$row['numero_auxiliar'],
        );
    }

    echo json_encode($clientes);

?>