<?php

    include('../../includes/conexion.php');
    session_start();
    
    $id = $_SESSION['code'];
    $Nhabitacion=$_SESSION['Nhabitacion'];

    $sql="UPDATE reserva SET estado=4 WHERE cod_reserva='$id'";
    $resultado = mysqli_query($con, $sql);

    if(!$resultado){
        die("ERROR AL ACTUALIZAR ESTADO RESERVA EN CANCELADO".mysqli_error($con));
    }

    $sql2="UPDATE habitacion SET estado='disponible' WHERE numero_habitacion=$Nhabitacion";
    $result = mysqli_query($con, $sql2);

    if(!$result){
        die("ERROR AL ACTUALIZAR ESTADO HABITACION EN DISPONIBLE".mysqli_error($con));
    }

?>