<?php

session_start();

$ide=$_POST['ide'];
unset($_SESSION['registropersonas'][$ide]);

?>