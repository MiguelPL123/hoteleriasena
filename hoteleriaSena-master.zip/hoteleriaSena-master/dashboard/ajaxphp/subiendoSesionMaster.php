<?php
session_start();

if(isset($_POST['id'])){
    $master=$_POST['id'];
    $_SESSION['idMaster']=$master;

    $estado=$_POST['estado'];
    $_SESSION['estado']=$estado;


    echo $_SESSION['idMaster'];
    echo $_SESSION['estado'];

}

?>