<?php
include('../../includes/conexion.php');
session_start();

if(isset($_POST['id'])){
    $codReserva= $_POST['id'];
    $_SESSION['codReserva']=$codReserva;
    $sql="SELECT e.nombre, e.nit, e.correo, p.Pais, r.contacto, r.cargo, r.num_personas, r.folio_maestro, r.medioreserva, r.estado, r.fecha_salida FROM `reserva_grupal` as r 
    INNER JOIN empresa as e ON r.codigo_emp=e.codigo_emp INNER JOIN paises as p ON p.Codigo=e.paisCod WHERE r.codigo_reserva='$codReserva';";
    $result=mysqli_query($con,$sql);
    if(!$result)die("error".mysqli_error($con));

    $arreglo=array();
    
    while($row = mysqli_fetch_array($result)){
        $arreglo=array(
            "nombre" => $row['nombre'],
            "nit" => $row['nit'],
            "correo" => $row['correo'],
            "Pais" => $row['Pais'],
            "contacto" => $row['contacto'],
            "cargo" => $row['cargo'],
            "num_personas" => $row['num_personas'],
            "folio_maestro" => $row['folio_maestro'],
            "medioreserva" => $row['medioreserva'],
            "estado" => $row['estado'],
            "fecha_salida" => $row['fecha_salida'],


        );
    }
    echo json_encode($arreglo);
}
?>