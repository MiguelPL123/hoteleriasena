<?php
include('../../includes/conexion.php');
$idProducto=$_POST['opcion'];

$sql="SELECT precio FROM producto WHERE idProducto='$idProducto'";
$result= mysqli_query($con,$sql);
if (!$result) {
    die('ERROR AL CONSULTAR PRECIO PRODUCTOS'.mysqli_error($con));
}
$precio=null;
while ($row = mysqli_fetch_array($result)) {
    $precio=$row['precio'];
}
echo $precio;

?>