<?php
    include('../../includes/conexion.php');
    session_start();

    if(isset($_SESSION['idExtra'])){
        $id=$_SESSION['idExtra'];
        $sql=mysqli_query($con,"DELETE FROM cargos_folios_habitacion WHERE idcargoextras=$id");

        if(!$sql)die("error".mysqli_error($con));
    }

?>