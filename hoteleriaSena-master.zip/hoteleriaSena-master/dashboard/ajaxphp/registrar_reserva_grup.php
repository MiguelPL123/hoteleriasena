<?php
    include("../../includes/conexion.php");
    session_start();
    $cargos=$_SESSION["cargosReserva"];
    $datosEmpre=$_SESSION['datosempresa'];
    $datosReser=$_SESSION['datosreseva'];
    $clientes=$_SESSION['registrosClientes'];

    echo json_encode($datosEmpre);

    /* Registro de empresa */
    $result= mysqli_query($con,"SELECT * FROM empresa WHERE codigo_emp='".$datosEmpre['codigo']."'");
    if (!$result) {
        die("ERROR AL CONSULTAR EXISTENCIA DE EMPRESA". mysqli_error($con));
    }
    if (mysqli_num_rows($result)==0) {
        $sql="INSERT INTO empresa 
              VALUES(null,
                '".$datosEmpre['codigo']."',
                '".$datosEmpre['nit']."',
                '".$datosEmpre['nombre']."',
                '".$datosEmpre['correoCorp']."',
                '".$datosEmpre['pais']."',
                '".$datosEmpre['ciudad']."',
                '".$datosEmpre['direccion']."',
                '".$datosEmpre['telefono']."'
              )";
        $result2= mysqli_query($con,$sql);
        if (!$result2) {
            die("ERROR AL REGISTRAR EMPRESA". mysqli_error($con));    
        }
    }else{
        $sql="UPDATE empresa SET nombre= '".$datosEmpre['nombre']."',correo= '".$datosEmpre['correoCorp']."',
                paisCod= '".$datosEmpre['pais']."',ciudad_emp= '".$datosEmpre['ciudad']."',direccion_emp= '".$datosEmpre['direccion']."',
                contacto_emp= '".$datosEmpre['telefono']."' WHERE nit='".$datosEmpre['nit']."';
            ";
        $result2= mysqli_query($con,$sql);
        if (!$result2) {
            die("ERROR AL REGISTRAR EMPRESA". mysqli_error($con));    
        }

    }

    /* Registro de reserva grupal */
    $folioMaestro=$datosReser['folioMaestro'];

    $sql="INSERT INTO reserva_grupal VALUES(
        '".$datosReser['codreserva']."',
        '".$datosEmpre['codigo']."',
        '".$datosEmpre['medio']."',
        '".$datosEmpre['contacto']."',
        '".$datosEmpre['cargo']."',
        '".$datosReser['fechaCotizacion']."',
        '".$datosReser['fechaLlegada']."',
        '".$datosReser['fechaSalida']."',
        '".$datosReser['numeroPersonas']."',
        1,
        NOW(),
        '$folioMaestro'
        )";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL REGISTRAR RESERVA GRUPAL". mysqli_error($con));    
    }

    /* Registrar Cargos del folio maestro */
    foreach ($cargos as $key => $value) {
        $sql="INSERT INTO cargos_reserva_maestro values(null,'$folioMaestro','".$value['total']."','".$value['codServicio']."')";
        $result= mysqli_query($con,$sql);
        if (!$result) {
            die("ERROR AL REGISTRAR RESERVA GRUPAL". mysqli_error($con));    
        }   
    }

    /* Registrar folios extras */
    /* $clientes */
    function combinacionNumerica($ndigitos){
        $codigo="";
        for ($i=0; $i < $ndigitos; $i++) {
            $numero=rand(0,9);
            $codigo=$codigo."$numero";
        }
        return $codigo;
    };

    foreach ($clientes as $key => $value) {
        if ($value['habitacion-asignada']!=null) {
            $folioExtra= combinacionNumerica(7);
            $habitacion=$value['habitacion-asignada'];
            //Consultar si ya existe la habitacion con ese folio maestro,si no abrirle folio extra
            $sql="SELECT * FROM folios_extra WHERE idHabitacion='$habitacion' AND folio_maestro='$folioMaestro'";
            $result= mysqli_query($con,$sql);
            if (!$result) {die("ERROR AL CONSULTAR FOLIOS EXTRAS". mysqli_error($con));}   
            if (mysqli_num_rows($result)==0) {
                $sql2="INSERT INTO folios_extra VALUES($folioExtra,'$habitacion','$folioMaestro','pendiente')";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {die("ERROR AL REGISTRAR FOLIOS EXTRA". mysqli_error($con));}   
            }else{
                $folioExtra=mysqli_fetch_array($result)["folio_extra"];
            }

            //Registrar Clientes
            //VerificaR SI existe el cliente y SI NO registramos el cliente

            $sql="SELECT * FROM clientes WHERE cedula='".$value['cedula']."'";
            $result=mysqli_query($con,$sql); 
            if (!$result) {die("ERROR AL CONSULTAR VERIFICACION DE CLIENTES". mysqli_error($con));}
            if (mysqli_num_rows($result)==0) {
                //Registrar cliente
                $sql2="INSERT INTO clientes VALUES(null,'".$value['tipo']."','".$value['cedula']."','".$value['nombre']."','".$value['apellido']."','".$value['correoPersonal']."')";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {die("ERROR AL REGISTRAR CLIENTE". mysqli_error($con));}

                //Registrar detalles
                $sql2="INSERT INTO datos_cliente VALUES(null,'".$value['pais']."','".$value['fechanaci']."','".$value['lugarNacimiento']."','".$value['ciudadR']."','".$value['direccion']."','".$value['genero']."',null,null,'".$value['telefonoMovil']."','".$value['telefonoAux']."','".$value['cedula']."')";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {die("ERROR AL REGISTRAR DETALLES DEL CLIENTE". mysqli_error($con));}
            }

            $cedula=$value['cedula'];
            $sql3="INSERT INTO clie_reserva_grupál VALUES(null,'$cedula','$folioExtra',null,null);";
            $result3= mysqli_query($con,$sql3);
            if (!$result3) {die("ERROR AL REGISTRAR CLIENTES EN LOS FOLIOS EXTRAS". mysqli_error($con));}
        }
    }

?>