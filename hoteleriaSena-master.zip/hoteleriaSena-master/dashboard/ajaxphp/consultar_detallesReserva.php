<?php
    include('../../includes/conexion.php');
    session_start();

    $id=$_SESSION['code'];
    
    $sql="SELECT * FROM detalles_reserva WHERE cod_reserva='$id'";
    $result = mysqli_query($con, $sql);

    if(!$result){
        die("ERROR AL CONSULTAR DETALLES RESERVA" .mysqli_error($con));
    }
    $detalles=array();

    while($row = mysqli_fetch_array($result)){
        $detalles=array(
            "motivo" => $row['motivo'],
            "garantia" => $row['garantia'],
            "pago" => $row['pago'],
            "deposito" => $row['deposito'],
        );
    }
    
    echo json_encode($detalles);

?>