var servicio = document.getElementById("servicio");

servicio.addEventListener("change", function () {
  var selectedOption = this.options[servicio.selectedIndex];
  var opcion=selectedOption.value;
  if (opcion!="select") {
    $.ajax({
        url:'../ajaxphp/consultarConsumoReserva.php',
        type: 'POST',
        data:{opcion},
        success: function(resp){
          $("#precio").val(resp);
          $("#total").val(resp);
        }
    });
  }
});

$("#cantidad").keyup(function(e){
  let cantidad= $("#cantidad").val()
  if (cantidad=="") {
    cantidad=0;
  }
  cantidad = parseInt(cantidad);
  let precio=$("#precio").val();
  let total=cantidad*precio;
  $("#total").val(total);
})

$(document).on('click', '#eliminarConsumo', function(){
  let element = $(this)[0].parentElement;
  let id =$(element).attr('idProd');
  console.log(id);
  $.ajax({
    url: '../ajaxphp/consultarConsumo.php',
    type: 'POST',
    data: {id},
    success: function(resp){
    }
  })
  
});

// Eliminar cliente
$(document).on('click', '#EliminarRegistro', function(){
  $.ajax({url: '../ajaxphp/eliminar_consumo.php',type: 'POST',
      success: function(resp){
        location.reload();
      }
  })
});