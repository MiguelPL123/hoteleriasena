$('.ingresarhab').on('click',function(){
    const element=$(this)[0].parentElement.parentElement;
    const id= $(element).attr("idhab");
    const habitacion= "Habitacion "+$(element).attr("nombre");    
    $("#habitaPer").val(habitacion);
    $("#codHab").val(id);
    consultarPersonasDisponibles();
    iniModal(1);
});

function consultarPersonasDisponibles() {
    /* consultar_personas_hab.php */   
    $.ajax({
        url:'../ajaxphp/personas_hab_reserva.php',
        type: 'POST',
        data: {consulta: true},
        success: function(resp){
            try {
                var json=JSON.parse(resp);
                var templateHTML=`<option value="select">Seleccione...</option>`;
                json.forEach(element => {
                    templateHTML+=`
                        <option value="${element['cedula']}">${element['nombre']} ${element['apellido']}</option>
                    `;
                });
                $('#clienthab').html(templateHTML);
            } catch (error) {
                console.log(resp);
            }
        }
    })
}
$('#registrarhabclie').on('click',function(){
    const cliente=$('#clienthab').val();
    const codHab=$('#codHab').val();
    if (cliente!="select") {
        $.ajax({
            url:'../ajaxphp/personas_hab_reserva.php',
            type: 'POST',
            data: {cliente,codHab},
            success: function(resp){
                if (resp==true) {
                    alert('la habitacion se encuentra llena,el maximo de personas fue alcanzado!!');
                } else {
                    console.log(resp);
                }
                limpiarCampos();
            }
        })
    }else{
        alert("Debe seleccionar una persona para asignarle esta habitacion!");
    }
})
function limpiarCampos() {
    $('#clienthab').val("select");
    consultarPersonasDisponibles();
}
/* Finalizar reservacion */
$("#finalizacion").on('click',function(){
    $.ajax({
        url:'../ajaxphp/registrar_reserva_grup.php',
        type: 'POST',
        success: function(resp){
            location.href="../reservaGrupal.php";
        }
    })
})
