//VER CHECKOUT
$(document).on('click', '#VerCheckout', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codigoReserva');
    let estado = $(element).attr('estado');
    let numHabi = $(element).attr('NumHabitacion');
    let tipo = $(element).attr('tipo');




    if (estado=="Check-Out") {
        document.querySelector("#checkout").style.display="none";
        document.querySelector("#editar").style.display="none";
    }else{
        document.querySelector("#checkout").style.display="block";
        document.querySelector("#editar").style.display="block";
    }

    if(tipo=='Individual'){
        $.ajax({url:'ajaxphp/consultar_checkOut.php', type:'POST',data:{id,numHabi},
            success: function(resp){
                try {
                    const check=JSON.parse(resp);
                    $('#categoria1').html(check.categoria);
                    $('#precio').html(check.precio);
                    $('#referencia').html(check.referencia);
                    $('#contrato').html(check.cod_reserva);
                    $('#fechaIn').html(check.fecha_in);
                    $('#horaIn').html(check.hora_in);
                    $('#fechaOut').html(check.fecha_out);
                    $('#horaOut').html(check.hora_out);
                    $('#dias').html(check.dias);
                    $('#monto').html(check.monto);
                } catch (error) {
                    console.log(error);
                }
            }
        })
    }else{
        $.ajax({url:'ajaxphp/infoCheckOut.php', type:'POST',data:{id},
        success: function(resp){
            try {
                const arreglo=JSON.parse(resp);
                let estado=arreglo.estado;
                $('#empresaInfo').html(arreglo.nombre);
                $('#nitInfo').html(arreglo.nit);
                $('#correoInfo').html(arreglo.correo);
                $('#paisInfo').html(arreglo.Pais);
                $('#contactoInfo').html(arreglo.contacto);
                $('#cargoInfo').html(arreglo.cargo);
                $('#CPersonasInfo').html(arreglo.num_personas);
                $('#FMaestroInfo').html(arreglo.folio_maestro);
                $('#MedioInfo').html(arreglo.medioreserva);
                $('#fechaSalidaInfo').html(arreglo.fecha_salida);
                if(estado==3){
                    document.getElementById('checkOutGrupal').style.display='none';
                }
            } catch (error) {
                console.log(resp);
            }
        }
    })
    }
});

$(document).on('click', '#checkOutGrupal', function(){
    $.ajax({url: 'ajaxphp/checkOutGrupal.php',type:'POST',
        success: function(resp){ 
            location.reload();
        }
    })
});

$(document).on('click', '#facturar', function(){
    let element = $(this)[0].parentElement;
    let tipo = $(element).attr('tipo');
    let cod = $(element).attr('codigoFolio');
    /* onclick="window.location.href='factura.php'" */


    $.ajax({url: 'ajaxphp/cargarfoliomaestrofactura.php',type:'POST',data: {tipo,cod},
        success: function(resp){ 
            console.log(resp);
            window.location.href='factura.php';
        }
    })
});

$(document).on('click', '#consumo', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codigoReserva');
    $.ajax({url: 'ajaxphp/hacerSession.php',type:'POST', data:{id},
        success: function(resp){   }
    })
});

$(document).on('click', '#checkout', function(){
    $.ajax({url: 'ajaxphp/updateCheck.php',type:'POST',
        success: function(resp){
            try {
                const hab=JSON.parse(resp);
                setTimeout(() => {
                    location.reload();
                }, 3000);
                Swal.fire({
                    position: 'top-end',
                    icon: 'success',
                    title: 'La Habitacion '+hab.habi+' Desocupada',
                    text: 'La Habitacion '+hab.habi+" en el piso "+hab.piso+" a cambiado su estado a desocupada sucia!",
                    showConfirmButton: false,
                    timer: 3000
                })
            } catch (error) {
                console.log(resp);
            }
        }
    })
});

$(document).on('click', '#editar', function(){ 
    $.ajax({url: 'ajaxphp/ConsultarDetallesCheckOut.php',type:'POST',
        success: function(resp){
            try {
                const out=JSON.parse(resp);
                $('#nombreOut').val(out.nombres);
                $('#habitaOut').val(out.numero_habitacion);
                $('#fechasalida').val(out.fecha_out);
                $('#tellOut').val(out.numero_movil);
                $('#nochesOut').val(out.dias);

            } catch (error) {
                console.log(resp);
            }
        }
    })
});

$(document).ready(function(){
    $("#fechasalida").change(function(){
        let fechain=$('#fechasalida').val();
        $.ajax({url: 'ajaxphp/calcular_dias_reserva2.php',type:'POST',data:{fechain},
            success: function(resp){
                $("#nochesOut").val(resp)
            }
        })
        /* $_SESSION['code'] */
    })
});

$(document).on('click', '#facturar', function(){ 
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codigoReserva');
    let tipo = $(element).attr('tipo');
    let estado = $(element).attr('estado');

    $.ajax({url: 'ajaxphp/facturacion.php',type:'POST',data:{id,estado,tipo},
        success: function(resp){
        }
    }) 
});


$(document).on('click', '#FExtra', function(){ 
    let element = $(this)[0];
    let id = $(element).attr('codigoFolio');
    
    $.ajax({url: 'ajaxphp/consultarFolioExtaIn.php',type:'POST',data:{id},
        success: function(resp){
            window.location.href='forms/foliosGrup.php'
        }

    }) 
});


$(document).on('click', '#personasCheck', function(){ 
    let element = $(this)[0].parentElement;
    let id = $(element).attr('NumHabitacion');
    let estado = $(element).attr('estado');
    $.ajax({url: 'ajaxphp/subiendoSesionMaster.php',type:'POST',data:{id,estado},
        success: function(resp){
            window.location.href='forms/verRegistro__personas-grupal_check.php';
        }

    }) 
});

