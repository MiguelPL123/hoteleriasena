//Mostrar Datos del cliente
$(document).on('click', '#mostrarClie', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('clie');
    $.ajax({
        url: 'ajaxphp/consultar_cliente.php',
        type: 'POST',
        data: {id},
        success: function(resp){
            try {
                const json= JSON.parse(resp);
                $("#tipo").html(json.tipo);
                $("#cedula").html(json.cedula);
                $("#nombres").html(json.nombres);
                $("#apellidos").html(json.apellidos);
                $("#genero").html(json.genero);
                $("#fechanac").html(json.fechanacimiento);
                $("#lugarnac").html(json.lugarnacimiento);
                $("#ciudadres").html(json.ciudad);
                $("#pais").html(json.pais);
                $("#direccion").html(json.direccion);
                $("#correoper").html(json.correo);
                $("#correocor").html(json.correocorporativo);
                $("#numerofijo").html(json.numerofijo);
                $("#numeromovil").html(json.numeromovil);
                $("#numeroaux").html(json.numeroauxiliar);
            } catch (error) {
                console.log(resp);
            }
        }
    })
});

//Editar Registros
$(document).on('click', '#editarClie', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('clie');
    $.ajax({
        url: 'ajaxphp/consultar_cliente.php',
        type: 'POST',
        data: {id},
        success: function(resp){
            location.href="./forms/editClien.php";
        }
    })
});
// Cargar id cliente
$(document).on('click', '#deleteClie', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('clie');
    $.ajax({
        url: 'ajaxphp/consultar_cliente.php',
        type: 'POST',
        data: {id},
        success: function(resp){}
    })
});

// Eliminar cliente
$(document).on('click', '#EliminarRegistro', function(){
    $.ajax({
        url: 'ajaxphp/eliminar_cliente.php',
        type: 'POST',
        success: function(resp){
            location.reload();
        }
    })
});