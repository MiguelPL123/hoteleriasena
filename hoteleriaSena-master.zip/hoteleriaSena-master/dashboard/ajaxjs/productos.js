//EDITAR PRODUCTOS
$(document).on('click', '#EditarProducto', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('idProducto');
    console.log(id);
    $.ajax({url: '../ajaxphp/consultar_productos.php', type: 'POST', data:{id},
        success: function(resp){
            try {
                const productos=JSON.parse(resp);
                $('#nombreProd').val(productos.nombre);
                $('#precioProd').val(productos.precio);
                $('#descProd').val(productos.descripcion);
                $('#codeProd').val(productos.codeProd);

            } catch (error) {
                console.log(resp);
            }
        }
    })
});

//ELIMINAR PRODUCTOS
$(document).on('click', '#EliminarProducto', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('idProducto');
    $.ajax({url:'../ajaxphp/consultar_productos.php',type:'POST',data:{id},
        success: function(resp){
        }
    })
});

$(document).on('click','#EliminarRegistro',function(){
    $.ajax({url: '../ajaxphp/eliminar_productos.php',type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});
