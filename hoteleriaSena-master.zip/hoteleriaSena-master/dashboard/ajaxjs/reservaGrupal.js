function validarAccesoCargos() {
    if ($('#numpersonas').val()!='') {
        if ($('#numpersonas').val()>0) {
            iniModal(1);
            $('#numpersonas').attr("readonly",true);
        }else{
            alert('Debe ingresar el numero de personas a registrar!');    
        }
    }else{
        alert('Faltan detalles de reserva por completar!');
    }
}
/* Aurellenado de una empresa existente codigo*/
$("#codigo").keyup(function(e){
let buscarEmp=$("#codigo").val();
let ncaracteres=buscarEmp.length;
if(ncaracteres<=6){
    if (buscarEmp=="000000") {
        $("#nombre").val(null);
        $("#correoCor").val(null);
        $("#nit").val(null);                    
        $("#ciudad").val(null);
        $("#direccion").val(null);
        $("#telefono").val(null);
        $("#telefono").val(null);
        $("#pais").val("select");
        $("#ciudad").html(null);
        $("#contacto").val(null);
        $("#cargo").val(null);
        $("#medio").val("select");
        $.ajax({
            url:'../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{rellenado: true},
            success: function(resp){
                $("#codigo").val(resp);
            }
        })
    }else{
        $.ajax({
            url:'../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{buscarEmp},
            success: function(resp){
                try {
                    if (resp!="[]") {
                        let empresa=JSON.parse(resp);
                        $("#nombre").val(empresa.nombre);
                        $("#correoCor").val(empresa.correo);
                        $("#nit").val(empresa.nit);                    
                        $("#ciudad").val(empresa.ciudad_emp);
                        $("#direccion").val(empresa.direccion_emp);
                        $("#telefono").val(empresa.contacto_emp);
                        $("#telefono").val(empresa.contacto_emp);
                        $("#pais").val(empresa.paisCod);
                        let template=`<option value='select'>Seleccione..</option>`;
                        empresa.ciudades.forEach(element => {
                            template+=`<option value="${element.ciudad}" >${element.ciudad}</option>`;
                        });
                        $("#ciudad").html(template);
                        $("#ciudad").val(empresa.ciudad_emp);
                    }
                } catch (error) {
                    console.log(resp);   
                }
            }
        });
    }
}
})

/* Aurellenado de una empresa existente por nit*/
$("#nit").keyup(function(e){
let buscarEmp=$("#nit").val();
let ncaracteres=buscarEmp.length;
if(ncaracteres>=4){
    /* console.log(buscarEmp); */
    if (buscarEmp=="000000") {
        $("#nombre").val(null);
        $("#correoCor").val(null);
        $("#nit").val(null);                    
        $("#ciudad").val(null);
        $("#direccion").val(null);
        $("#telefono").val(null);
        $("#telefono").val(null);
        $("#pais").val("select");
        $("#ciudad").html(null);
        $("#contacto").val(null);
        $("#cargo").val(null);
        $("#medio").val("select");
        $.ajax({
            url:'../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{rellenado: true},
            success: function(resp){
                $("#codigo").val(resp);
            }
        })
    }else{
        $.ajax({
            url:'../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{buscarEmp},
            success: function(resp){
                try {
                    if (resp!="[]") {
                        let empresa=JSON.parse(resp);
                        $("#codigo").val(empresa.codigo);
                        $("#nombre").val(empresa.nombre);
                        $("#correoCor").val(empresa.correo);
                        $("#nit").val(empresa.nit);                    
                        $("#ciudad").val(empresa.ciudad_emp);
                        $("#direccion").val(empresa.direccion_emp);
                        $("#telefono").val(empresa.contacto_emp);
                        $("#telefono").val(empresa.contacto_emp);
                        $("#pais").val(empresa.paisCod);
                        let template=`<option value='select'>Seleccione..</option>`;
                        empresa.ciudades.forEach(element => {
                            template+=`<option value="${element.ciudad}" >${element.ciudad}</option>`;
                        });
                        $("#ciudad").html(template);
                        $("#ciudad").val(empresa.ciudad_emp);
                    }
                } catch (error) {
                    console.log(resp);   
                }
            }
        });
    }
}
})
/* Consulta de las ciudades segun el pais de seleccion */
var pais= document.getElementById("pais");
pais.addEventListener("change", function(){
    var selectedOption = this.options[pais.selectedIndex];
    var opcion=selectedOption.id;
    if(opcion!="select"){
        $.ajax({
            url: '../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{opcion},
            success: function(resp){
                try {
                    let json= JSON.parse(resp);
                    let template = `<option value="select">Seleccione</option>`;
                    json.forEach(element => {
                        template+="<option value='"+element.ciudad+"'>"+element.ciudad+"</option>";
                    });
                    $("#ciudad").html(template);   
                } catch (error) {
                    console.log(resp);
                }
            }
        })
    }
});
/* Modal de agregar cargos */
//Combo cargos
$('#servicio').on('change',function(){
    var numpersonas=$('#numpersonas').val();
    var cargo=$('#servicio').val();
    $.ajax({
        url:'../ajaxphp/consultar_folios.php',
        type: 'POST',
        data: {id : cargo},
        success: function(resp) {
            try {
                const json= JSON.parse(resp);
                const preciocargo=json.precio;
                $('#valor').val(preciocargo);//Precio de servicio
                var total=preciocargo*numpersonas;
                var iva=total*0.19;
                total+=iva;
                $('#total').val(total);
            } catch (error) {
                console.log(resp);
            }
        }
    })
});
// Boton de registrar cargo
$('#registrarCargo').on('click',function(){
    var cargo=$('#servicio').val();
    var valor=$('#valor').val();
    var total=$('#total').val();
    var numpersonas=$('#numpersonas').val();
    $.ajax({
        url:'../ajaxphp/consultar_folios.php',
        type: 'POST',
        data: {id : cargo},
        success: function(resp) {
            try {
                const json= JSON.parse(resp);
                var nombrecargo=json.nombres;
                $.ajax({
                    url:'../ajaxphp/cargosreservagrup.php',
                    type: 'POST',
                    data: {cargo,nombrecargo,numpersonas,valor,total},
                    success: function(resp) {
                        limpiarcamposmodal();
                    }
                })
            } catch (error) {
                console.log(resp);
            }
        }
    })
})
function limpiarcamposmodal() {
    $("#servicio").val('select');
    $("#valor").val('');
    $("#total").val('');
}
$('#finalizarprocesocargos').on('click',function(){
    limpiarcamposmodal();
    consultarcargos();
    closeModals(1);
});
//Consultar tabla de cargos
function consultarcargos() {
    $.ajax({
        url:'../ajaxphp/cargosreservagrup.php',
        type: 'POST',
        data: {consultar: true},
        success: function(resp) {
            try {
                const json= JSON.parse(resp);
                var templateHtml=`
                    <tr id="cargoAlojamiento">
                        <td>Alojamiento</td>
                        <td>${$("#numpersonas").val()}</td>
                        <td>0</td>
                        <td>19%</td>
                        <td>0</td>
                        <td class="tbOpt">
                            <!-- <input type="button" class="bttn btn2" value="Eliminar"> -->
                        </td>
                    </tr>
                `;
                json.forEach(element => {
                    templateHtml+=`
                        <tr id-cargo='${element.cod}'>
                            <td>${element.descripcion}</td>
                            <td>${element.numpersonas}</td>
                            <td>${element.valor}</td>
                            <td>19%</td>
                            <td>${element.total}</td>
                            <td class="tbOpt">
                                <input type="button" class="bttn btn2 DeleteCategoria" value="Eliminar" onclick="eliminarcargo(this)">
                            </td>
                        </tr>
                    `;
                });
                $("#cuerpotablacargo").html(templateHtml);
                
            } catch (error) {
                console.log(resp);
            }
        }
    })
}
//Eliminar cargos
function eliminarcargo(object) {
    let element = $(object)[0].parentElement.parentElement;
    let id = $(element).attr('id-cargo');
    $.ajax({
        url:'../ajaxphp/cargosreservagrup.php',
        type: 'POST',
        data: {eliminar: true,id},
        success: function(resp) {
            consultarcargos();
        }
    })
}
/* ----------------------- */

//Cambio de personas en alojamiento
$("#numpersonas").keyup(function(e){
    var numPersonas=$("#numpersonas").val();
    
    var template=`
        <td>Alojamiento</td>
        <td>${numPersonas!="" ? numPersonas : "0"}</td>
        <td>0</td>
        <td>19%</td>
        <td>0</td>
        <td class="tbOpt">
            <!-- <input type="button" class="bttn btn2" value="Eliminar"> -->
        </td>
    `;
    
    $("#cargoAlojamiento").html(template);
})