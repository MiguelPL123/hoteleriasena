function limpiarCombo(elemet,selectView){
    
    $(function(){
        //Limpiar el combo box
        let valor= selectView.children;
        for (let i = 0; i < valor.length; i++) {
            let element = valor[i];
            let id= $(element).attr('selected');
            if (id=='selected') {
                $(element).attr("selected",false);
            }
        }
        if (elemet!=null) {
            $("#"+elemet).attr('selected',true);
        }else{
            $(valor[0]).attr('selected',true);
        }
    })

}

$("#numero").keyup(function(e){
    let search= $("#numero").val();
    let ncaracteres=search.length;
    if (ncaracteres>=5) {
        $.ajax({
        url:'../ajaxphp/consultarAcompa_ref.php',
        type: 'POST',
        data:{search},
        success: function(resp){
            try {
                if (resp!="[]") {
                    let json= JSON.parse(resp);
                    limpiarCombo(json.tipo,document.querySelector("#tipoDoc"));
                    $("#nombre").val(json.nombre);
                    $("#apellido").val(json.apellido);
                }else{
                    limpiarCombo(null,document.querySelector("#tipoDoc"));
                }
            } catch (error) {
                console.log(resp);
            }
        }
    });
    }
})

$(document).on('click', '#editAcompa', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('doc');
    $.ajax({
        url:'../ajaxphp/consultarAcompa_ref.php',
        type:'POST',
        data: {search: id},
        success: function(resp){
            try {
                let json= JSON.parse(resp);
                $("#"+json.tipo+"2").attr('selected',true);
                $("#nombreEdit").val(json.nombre);
                $("#apellidoEdit").val(json.apellido);
                $("#numeroEdit").val(id);
                iniModal(1);

                /* $("#tipoEdit2").attr('selected',true); */
            } catch (error) {
                console.log(resp);
            }
        }
    })
});

$(document).on('click', '#deleteAcompa', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('doc');
    $.ajax({
        url:'../ajaxphp/eliminar_registro_acompa.php',
        type:'POST',
        data: {id},
        success: function(resp){
            window.location.reload()
        }
    })
});