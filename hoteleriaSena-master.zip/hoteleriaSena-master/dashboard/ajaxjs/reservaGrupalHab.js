$(document).on('click', '#eliminarClient', function(){
    let element = $(this)[0].parentElement;
    let ide = $(element).attr('id');

    $.ajax({url:'../ajaxphp/eliminarClientList.php',type:'POST',data:{ide},
        success: function(resp){
            location.reload();
        }
    })
});

$(document).on('click', '#ingresar', function(){
    let element = $(this)[0].parentElement;
    let idHab = $(element).attr('idHab');

    $.ajax({url:'../ajaxphp/SubiendoIDHabit.php',type:'POST',data:{idHab},
        success: function(resp){
        }
    })
});


$(document).on('click', '#GuardarCambios', function(){
    let opcion=document.getElementById('asignacion').value;

    $.ajax({url:'../ajaxphp/Comparando.php',type:'POST',data:{opcion},
        success: function(resp){
            location.reload(resp)
        }
    })
});
