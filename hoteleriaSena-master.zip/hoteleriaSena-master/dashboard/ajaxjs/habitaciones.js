//HABITACIONES

//EDITAR HABITACIONES
$(document).on('click', '#editarHabitacion', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('idHabitacion');
    let habitacion = $(element).attr('numeroHabitacion');

    $.ajax({url:'ajaxphp/consultar_habitaciones.php', type:'POST',data:{id,habitacion},
        success: function(resp){
            try {
                const habitacion=JSON.parse(resp);
                $('#habitacion1').val(habitacion[0].numeroHabitacion);
                $('#piso1').val(habitacion[0].piso);
                $('#precio1').val(habitacion[0].precio);
                let estado=habitacion[0].estado;
                if(estado=="disponible"){
                    $('#disp').attr('selected','true');
                }else if (estado=="ocupado"){
                    $('#ocupado').attr('selected','true');
                }else if (estado=="reservado"){
                    $('#reservado').attr('selected','true');
                }
                else if (estado=="vacia sucia"){
                    $('#vaciasucia').attr('selected','true');
                }
                else if (estado=="mantenimieto"){
                    $('#mantenimieto').attr('selected','true');
                }
                $('#descripcion1').val(habitacion[0].descripcion);
                document.getElementById(habitacion[1].codHab).setAttribute('selected',true);

            } catch (error) {
                console.log(resp);
            }
        }
    })
}); 

//ELIMINAR HABITACIONES
$(document).on('click', '#EliminarHabitacion', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('idHabitacion');

    $.ajax({url:'ajaxphp/consultar_habitaciones.php',type:'POST',data:{id},
        success: function(resp){
            console.log();
        }
    })
});

$(document).on('click','#EliminarRegistro',function(){
    $.ajax({url: 'ajaxphp/eliminar_habitaciones.php',type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});








