$(document).on('click', '#editarReser', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('reser');

    $.ajax({
        url:'./ajaxphp/subir_cod_reserva.php',
        type:'POST',
        data: {id},
        success: function(resp){
            location.href="./forms/editReserva.php";
        }
    })
});

$(document).on('click', '#eliminarReservaBtn', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('reser');
    $.ajax({
        url:'./ajaxphp/subir_cod_reserva.php',
        type:'POST',
        data: {id},
        success: function(resp){}
    })
});

$(document).on('click', '#EliminarRegistro', function(){
    $.ajax({
        url:'./ajaxphp/eliminar_reserva.php',
        type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});

$(document).on('click', '#infoReserva', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('reser');
    $.ajax({
        url:'./ajaxphp/consultar_detalles_reservas.php',
        type:'POST',
        data:{id},
        success: function(resp){
            try {
                const datos= JSON.parse(resp);
                $("#cedula").html(datos.cedula);
                $("#nombres").html(datos.nombres);
                $("#apellidos").html(datos.apellidos);
                $("#correo").html(datos.correo);
                $("#celular").html(datos.movil);
                $("#habitacion").html(datos.habitacion);
                $("#pago").html(datos.pago);
                $("#empresa").html(datos.nit);
                $("#checkin").html(datos.datein);
                $("#checkout").html(datos.dateout);
                $("#codigo").html(datos.codreserva);
                let personas= datos.acompas;
                let template=``;
                if (personas.length>0) {
                    personas.forEach(element => {
                        template+=`<label for=""><b><span>${element.documento}</span></b>&nbsp; -${element.nombres}</label>`;
                    });
                }
                $("#acompas").html(template);
            } catch (error) {
                console.log(resp);
            }
        }
    })
});