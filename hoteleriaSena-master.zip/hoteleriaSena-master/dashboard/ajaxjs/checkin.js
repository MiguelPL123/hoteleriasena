//EDITAR CATEGORIA
$(document).on('click', '#check', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codigo');
    let opcion=$(element).attr('tipo');
    let folioMaestro=$(element).attr('folioMaestro');
    let reservaGrup=$(element).attr('reservaGrup');


    if(opcion=='Individual'){
        $.ajax({url:'ajaxphp/consultar_checkIn.php', type:'POST',data:{id},
        success: function(resp){
            try {
                const check=JSON.parse(resp);
                $('#nombre').val(check.nombres);
                $('#cedula').val(check.cedula);
                $('#telefono').val(check.numero);
                $('#fecha_in').val(check.fecha_in);
                $('#hora_in').val(check.hora_in);
                $('#dias').val(check.dias);
                $('#numpersonas').val(check.personas);
                if (parseInt(check.personas)>0){
                    document.querySelector("#btnacompañante").style.display="flex";
                }else{
                    document.querySelector("#btnacompañante").style.display="none";
                }

            } catch (error) {
                console.log(resp);
            }
        }
        })
    }else{
        $.ajax({
            url:'ajaxphp/consultar_checkIn2.php',
            type:'POST',
            data:{folioMaestro,reservaGrup},
            success: function(resp){
                try {
                    let datos=JSON.parse(resp);
                    $('#maestro1').val(datos[0].folio_maestro);

                    let template = `<option value="select">Seleccione...</option>`;
                   datos.forEach(element => {
                        template+="<option value='"+element.idHabitacion+"'>Habitación: "+element.numero_habitacion+"</option>";


                    });
                    $("#habitacion1").html(template);   
                    document.getElementById('textExtra').style.display='none';
                    document.getElementById('extra').style.display='none';
                } catch (error) {
                    console.log(resp);
                }
            }
        })
    }
    
});

var habitacion=document.getElementById("habitacion1");
habitacion.addEventListener("change", function(){
    var selectedOption = this.options[habitacion.selectedIndex];
    var opcion = selectedOption.value;

    if(opcion!="select"){
        $.ajax({
            url: 'ajaxphp/consultarExtras.php',
            type: 'POST',
            data:{opcion},
            success: function(resp){
                
                try {
                    let json=JSON.parse(resp);
                    let template = `<option value="select">Seleccione...</option>`;
                    json.forEach(element => {
                        template+="<option value='"+element.cedula+"'>"+element.nombre, element.apellido+"</option>";
                    });
                    $("#extra").val(json[0].extra);
                    $("#personasExtra").html(template);


                } catch (error) {
                    console.log(error);
                }
            }
        }) 
    }else{
        let template = `<option value="select">Seleccione...</option>`;
        
        $("#personasExtra").html(template);
        $("#extra").val(null);
    }

});

//INFO
$(document).on('click', '#info', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codigo');
    let opcion=$(element).attr('tipo');
    let folioMaestro=$(element).attr('folioMaestro');
    let reservaGrup=$(element).attr('reservaGrup');


    if(opcion=='Individual'){
        $.ajax({url:'ajaxphp/consultar_checkIn.php', type:'POST',data:{id},
            success: function(resp){
                try {
                    const check=JSON.parse(resp);
                    $('#codigo').val(check.cod_reserva);
                    $('#inicio').val(check.fecha_in);
                    $('#final').val(check.fecha_out);
                    $('#codigo2').val(check.cod_reserva);
                    $('#dias2').val(check.dias);

                } catch (error) {
                    console.log(resp);
                }
            }
        })   
    }else{
       $.ajax({
        url:'ajaxphp/consultarCheckInInfo.php',
        type: 'POST',
        data: {reservaGrup},
        success: function(resp){
            try {
                const info=JSON.parse(resp);
                $('#empresaInfo').html(info.nombre);
                $('#nitInfo').html(info.nit);
                $('#correoInfo').html(info.correo);
                $('#paisInfo').html(info.Pais);
                $('#contactoInfo').html(info.contacto);
                $('#cargoInfo').html(info.cargo);
                $('#cotizaInfo').html(info.fecha_contizacion);
                $('#llegadaInfo').html(info.fecha_llegada);
                $('#salidaInfo').html(info.fecha_salida);
                $('#CPersonasInfo').html(info.num_personas);
                $('#FMaestroInfo').html(info.folio_maestro);
                $('#MedioInfo').html(info.medioreserva);             
            } catch (error) {
                console.log(resp); 
            }
        }
       }) 
    }
});
$(document).on('click','#checkinFinal',function(){
    $.ajax({url: 'ajaxphp/checkInFinal.php',type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});
//DETALLES
$(document).on('click','#detalles',function(){
    $.ajax({url: 'ajaxphp/consultar_detallesReserva.php',type:'POST',
        success: function(resp){
            try {
                const reservadetalle=JSON.parse(resp);
                $('#motivo').val(reservadetalle.motivo);
                $('#garantia').val(reservadetalle.garantia);
                $('#deposito').val(reservadetalle.deposito);
            } catch (error) {
                console.log(resp);
            }
        }
    })
}); 

$(document).on('click','#cancelar',function(){
    let element = $(this)[0].parentElement;
    let habitacion = $(element).attr('habitacion');
    $.ajax({url: 'ajaxphp/consultar_habitaciones.php',type:'POST', data:{habitacion},
        success: function(resp){

        }
    })
});

$(document).on('click','#EliminarRegistro',function(){
    $.ajax({url: 'ajaxphp/cancelar_reserva.php',type:'POST',
        success: function(resp){
            
        }
    })
});

$(document).ready(function(){
    $("#fecha_in").change(function(){
        let fechain=$('#fecha_in').val();
        $.ajax({url: 'ajaxphp/calcular_dias_reserva.php',type:'POST',data:{fechain},
            success: function(resp){
                $("#dias").val(resp)
            }
        })
    })
});

$(document).on('click','#btnacompañante',function(){
    var numeroAcompañantes=$("#numpersonas").val();
    $.ajax({
        url:'ajaxphp/cargar_numeroPersonas.php',
        type:'POST',
        data:{numeroAcompañantes},
        success: function(resp){
            var left = (screen.width - 1200) / 2;
            var top = (screen.height - 650) / 4;
            window.open("forms/acompa.php" , "ventana1" , "width=1200,height=700,scrollbars=NO,Toolbar=NO,top="+ top + ", left="+ left+"");
        }
    })
});

