//Consultar datos del usuario
$(document).on('click', '#editUserBtn', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('num');

    $.ajax({url:'ajaxphp/consultar_usuario.php', 
            type:'POST',
            data:{id},
            success: function(resp){
                try {
                    let json= JSON.parse(resp);
                    $("#nombreEdit").val(json.nombres);
                    $("#userEdit").val(json.usuario);
                    $("#contraEdit").val(json.contra);
                    var tipo=json.tipo;
                    if (tipo=='0') {
                        $("#admin").attr("selected","true");
                    } else if (tipo=='1'){
                        $("#aprendiz").attr("selected","true");
                    }else{
                        $("#select").attr("selected","true");
                    }
                    iniModal(2);
                } catch (error) {
                    console.log(resp);
                }
            }
    })
});

//subir id usuario
$(document).on('click', '#deleteUserBtn', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('num');

    $.ajax({url:'ajaxphp/consultar_usuario.php', 
            type:'POST',
            data:{id},
            success: function(resp){
                iniModal(3);
            }
    })
});

//Eliminar usuario
$(document).on('click', '#EliminarRegistro', function(){
    $.ajax({url:'ajaxphp/eliminar_usuario.php', 
            type:'POST',
            success: function(resp){
                location.reload();
            }
    })
});