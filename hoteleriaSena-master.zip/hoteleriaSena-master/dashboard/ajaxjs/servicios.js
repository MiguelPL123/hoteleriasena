//EDITAR FOLIOS
$(document).on('click', '#EditarFolio', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('codFolio');    
    $.ajax({url:'ajaxphp/consultar_folios.php', type:'POST',data:{id},
        success: function(resp){
            try {
                const folio=JSON.parse(resp);
                $('#folio').val(folio.codServicio);
                $('#nombreFolio').val(folio.nombres);
                $('#precio1').val(folio.precio);
            } catch (error) {
                console.log(resp);
            }
        }
    })
});


//ELIMINAR FOLIOS
$(document).on('click', '#EliminarFolio', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('codFolio');

    $.ajax({url:'ajaxphp/consultar_folios.php',type:'POST',data:{id},
        success: function(resp){
        }
    })
});

$(document).on('click','#EliminarRegistro',function(){
    $.ajax({url: 'ajaxphp/eliminar_folios.php',type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});
