-//CATEGORIA

//EDITAR CATEGORIA
$(document).on('click', '#EditCategoria', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('categoria');
    let url = $(element).attr('ruta');
    let categoria = $(element).attr('categoriaNombre');


    $.ajax({url:'ajaxphp/consultar_categoria.php', type:'POST',data:{id,url,categoria},
        success: function(resp){
            try {
                const categoria=JSON.parse(resp);
                $('#categoria1').val(categoria.categoria);
                $('#foto1').attr('src',categoria.imagen);
            } catch (error) {
                console.log(resp);
            }
        }
    })
});

//ELIMINAR CATEGORIA
$(document).on('click', '#DeleteCategoria', function(){
    let element = $(this)[0].parentElement;
    let id =$(element).attr('categoria');

    $.ajax({url:'ajaxphp/consultar_categoria.php',type:'POST',data:{id},
        success: function(resp){
            console.log(resp);
        }
    })
});

$(document).on('click','#EliminarRegistro',function(){
    $.ajax({url: 'ajaxphp/eliminar_categoria.php',type:'POST',
        success: function(resp){
            location.reload();
        }
    })
});








