function limpiarRadios(valor){
    const valores= [
        "masculino",
        "femenino",
        "otros"
    ];
    for (let i = 0; i < valores.length; i++) {
        $("#"+valores[i]).attr('checked',false);
    }
    if (valor!="clear") {
        $("#"+valor).attr('checked',true);
    }
}

$("#cedula").keyup(function(e){
    let search= $("#cedula").val();
    let ncaracteres=search.length;
    if (ncaracteres>=5) {
        if (search=="000000") {
            $("#tipoDoc").val("select");
            $("#cedula").val(null);
            $("#nombre").val(null);
            $("#apellido").val(null);
            $("#fecha").val(null);
            $("#lugar").val(null);
            $("#pais").val(null);
            $("#ciudad").val(null);
            $("#direccion").val(null);
            limpiarRadios("clear");
            $("#correo").val(null);
            $("#telefonoMovil").val(null);
            $("#TelefonoAux").val(null); 
        } else {
            $.ajax({
                url:'../ajaxphp/consultar_cliente_ref.php',
                type: 'POST',
                data:{search},
                success: function(resp){
                    try {
                        if (resp!="[]") {
                            let json= JSON.parse(resp);
                            console.log(json);
                            $("#tipoDoc").val(json.tipo);
                            $("#nombre").val(json.nombre);
                            $("#apellido").val(json.apellido);
                            $("#fecha").val(json.fecha);
                            $("#lugar").val(json.lugar);
                            $("#pais").val(json.pais);
                            $("#ciudad").val(json.ciudad);
                            $("#direccion").val(json.direccion);
                            limpiarRadios(json.genero);
                            $("#correo").val(json.correo);
                            $("#telefonoMovil").val(json.telefono);
                            $("#TelefonoAux").val(json.numeroauxiliar); 
                        }
                    } catch (error) {
                        console.log(resp);
                    }
                }
            });
        }
    }
})