function limpiarRadios(valor){
    const valores= [
        "masculino",
        "femenino",
        "otros"
    ];
    for (let i = 0; i < valores.length; i++) {
        $("#"+valores[i]).attr('checked',false);
    }

    if (valor!="clear") {
        $("#"+valor).attr('checked',true);
    }
}

$("#cedula").keyup(function(e){
    let search= $("#cedula").val();
    let ncaracteres=search.length;
    if (ncaracteres>=5) {
        if (search=="000000") {
            $("#tipoDoc").val("select");
            $("#cedula").val(null);
            $("#nombre").val(null);
            $("#apellido").val(null);
            $("#fecha").val(null);
            $("#lugar").val(null);
            $("#pais").val(null);
            limpiarRadios("clear");
            $("#correoPer").val(null);
            $("#correoCor").val(null);
            $("#telefonoMovil").val(null);
            $("#TelefonoAux").val(null);
        }else{
            $.ajax({
                url:'../ajaxphp/consultar_cliente_ref.php',
                type: 'POST',
                data:{search},
                success: function(resp){
                    try {
                        if (resp!="[]") {
                            let json= JSON.parse(resp);
                            $("#tipoDoc").val(json.tipo);
                            $("#nombre").val(json.nombre);
                            $("#apellido").val(json.apellido);
                            $("#fecha").val(json.fecha);
                            $("#lugar").val(json.lugar);
                            $("#pais").val(json.pais);
                            limpiarRadios(json.genero);
                            $("#correoPer").val(json.correo);
                            $("#correoCor").val(json.correoCor);
                            $("#telefonoMovil").val(json.telefono);
                            $("#TelefonoAux").val(json.numeroauxiliar);
                            //
                        }else{
                            limpiarCombo(null);
                        }
                    } catch (error) {
                        console.log(resp);
                    }
                }
            });
        }
    }
})

$("#nit").keyup(function(e){
    let search= $("#nit").val();
    let ncaracteres=search.length;
    if (ncaracteres>=6) {
        if (search=="000000") {
            $("#nit").val(null);
            $("#nombreEmpres").val(null);
            $("#correoEmpresa").val(null);
        }
        $.ajax({
            url:'../ajaxphp/consultar_empresa_ref.php',
            type: 'POST',
            data:{search},
            success: function(resp){
                try {
                    if (resp!="[]") {
                        let empresa=JSON.parse(resp);
                        $("#nombreEmpres").val(empresa.nombre);
                        $("#correoEmpresa").val(empresa.correo);
                    }
                } catch (error) {
                    console.log(resp);   
                }
            }
        });
    }
})

//Combo de categoria
var cate = document.getElementById("categorias");
cate.addEventListener("change", function () {
  var selectedOption = this.options[cate.selectedIndex];
  var opcion=selectedOption.value;
  if (opcion!="select") {
    $.ajax({
        url:'../ajaxphp/consultar_habitacionesReser.php',
        type: 'POST',
        data:{opcion},
        success: function(resp){
            try {
                let json= JSON.parse(resp);
                let template = `<option value="select">Seleccione</option>`;
                json.forEach(element => {
                    template+="<option value='"+element.id+"'>"+element.habitacion+"</option>";
                });
                $("#habitaciones").html(template);
            } catch (error) {
                console.log(resp);
            }
        }
    });
  }else{
    $("#productos").html(`<option value="select">Seleccione...</option>`);
  }
});


//Combo Si es una empresa
var resp = document.getElementById("desicionEmpresa");
resp.addEventListener("change", function () {
  var selectedOption = this.options[resp.selectedIndex];
  var opcion=selectedOption.value;
  
  if (opcion=="si") {
      document.querySelector(".empresaContainer1").style.display="flex";
      document.querySelector(".empresaContainer2").style.display="flex";
      document.querySelector(".empresaContainer3").style.display="flex";
  } else{
    document.querySelector(".empresaContainer1").style.display="none";
    document.querySelector(".empresaContainer2").style.display="none";
    document.querySelector(".empresaContainer3").style.display="none";
  }
});