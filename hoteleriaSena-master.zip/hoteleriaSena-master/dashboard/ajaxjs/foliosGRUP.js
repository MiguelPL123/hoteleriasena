$(document).on('click', '#ingresar', function(){ 
    let element = $(this)[0].parentElement;
    let id = $(element).attr('extra');

    $.ajax({url: '../ajaxphp/consultarCargosExtrasOut.php',type:'POST',data:{id},
        success: function(resp){
            const json= JSON.parse(resp);
            let template = ``;
            json.forEach(element => {
                template+=`
                <tr>                                   
                    <td>${element.nombres}</td>
                    <td>${element.descripcion}</td>
                    <td>${element.fechacargo}</td>
                    <td>0.8%</td>
                    <td>${element.valor}</td>
                    <td>${element.total}</td>
                    <td class="tbOpt" idCargoExtra=${element.idcargoextras}>
                        <input type="button" class="bttn btn2" value="Eliminar" id="eliminar" onclick="iniModal(3)">
                    </td>
                </tr>
                `;
            });
            $("#tbodyCargo").html(template);
        }
    }) 
});

$(document).on('click', '#eliminar', function(){
    let element = $(this)[0].parentElement;
    let id = $(element).attr('idCargoExtra');
    console.log(id);
    $.ajax({
        url: '../ajaxphp/eliminarExtraCargo.php',
        type: 'POST',
        data: {id},
        success: function(resp){
        }
    })
});
$(document).on('click', '#EliminarRegistro', function(){
    $.ajax({
        url: '../ajaxphp/eliminarExtraCargo2.php',
        type: 'POST',
        success: function(resp){
            location.reload();
        }
    })
});



$("#valorServicioSinIco").keyup(function(e){
let precioConstante=$('#valorServicioSinIco').val();
let ico=$('#ico').val();
let IcoTotal=precioConstante*ico;

$("#valorServicioMasIco").val(parseInt(IcoTotal)+parseInt(precioConstante));

})
/* servicios.addEventListener("change", function(){
    var selectedOption = this.options[servicios.selectedIndex];
    var opcion = selectedOption.value;

    if(opcion!="select"){
        $.ajax({
            url: '../ajaxphp/consultarServiciosGRUP.php',
            type: 'POST',
            data:{opcion},
            success: function(resp){
                try {
                    let valor=resp;
                    $("#valorServicio").val(valor);

                } catch (error) {
                    console.log(error);
                }
            }
        }) 
    }else{
        
        $("#valorServicio").val(null); 
    }
