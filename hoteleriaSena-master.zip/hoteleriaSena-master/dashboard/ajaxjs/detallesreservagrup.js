$(".infoReserva").on('click',function(){
    var element = $(this)[0].parentElement;
    var id= $(element).attr('data-code');
    $.ajax({
        url:'ajaxphp/consultar_detalles_reservagrup.php',
        type:'POST',
        data:{id},
        success: function(resp) {
            try {
                let json= JSON.parse(resp);
                $("#codigoemp").html(json.codigoemp);
                $("#nombresemp").html(json.nombre);
                $("#medio").html(json.medio);
                $("#medio").html(json.medio);
                $("#contacto").html(json.contacto);
                $("#cargo").html(json.cargo);
                $("#fechacotizacion").html(json.fechacotizacion);
                $("#fechain").html(json.fechain);
                $("#fechaout").html(json.fechaout);
                $("#numpersonas").html(json.personas);
                $("#foliomaestro").html(json.folio);
                $("#codigoreserva").html(json.codigoreserva);

                const cargosreservacion=json.cargos;
                /* Cargos de reserva */
                var temp=`
                    <tr>
                        <td>Alojamiento</td>
                        <td>$0.0</td>
                        <td>19%</td>
                        <td>$0.0</td>
                    </tr>
                `;
                cargosreservacion.forEach(element => {
                    temp+=`
                        <tr>
                            <td>${element.nombres}</td>
                            <td>${element.valor}</td>
                            <td>19%</td>
                            <td>${element.total}</td>
                        </tr>
                    `;
                });
                $("#cargosreservagrup").html(temp);

                iniModal(2)
            } catch (error) {
                console.log(resp);
            }
        }
    })
})