<?php
    include("../includes/validacionAccesoDash.php");
    include("../includes/conexion.php");


    /* Agregar Imagenes */

    if (isset($_POST["guardar"])) {
        /* Primer Banner */
        $titulo1=$_POST["titlebann1"];
        $descripcion1=$_POST["decripbann1"];
        
        $nombreArchivo1 = $_FILES['imagen']['name'];
        $nombreTemporal1 = $_FILES['imagen']['tmp_name'];
        $ruta1 = null;
        if(!empty($nombreArchivo1)){
            $ruta1 = "./images/bannerhome/". $nombreArchivo1;
            move_uploaded_file($nombreTemporal1,"../images/bannerhome/". $nombreArchivo1);
        }

        if(isset($ruta1)){
            //Editar la imagen de banner 1
            $sql= "UPDATE configuracion SET imagen='$ruta1' WHERE idsetting=1";
            $result= mysqli_query($con,$sql);
            if (!$result) {
                die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
            }
        }
        //Editar la informacion de banner 1
        $sql= "UPDATE configuracion SET titulo='$titulo1',descripcion='$descripcion1' WHERE idsetting=1";
        $result= mysqli_query($con,$sql);
        if (!$result) {
            die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
        }

        /* Segundo Banner */
        $titulo2=$_POST["titlebann2"];
        $descripcion2=$_POST["decripbann2"];
        
        $nombreArchivo2 = $_FILES['imagen2']['name'];
        $nombreTemporal2 = $_FILES['imagen2']['tmp_name'];
        $ruta2 = null;
        if(!empty($nombreArchivo2)){
            $ruta2 = "./images/bannerhome/". $nombreArchivo2;
            move_uploaded_file($nombreTemporal2,"../images/bannerhome/". $nombreArchivo2);
        }

        if(isset($ruta2)){
            //Editar la imagen de banner 1
            $sql= "UPDATE configuracion SET imagen='$ruta2' WHERE idsetting=2";
            $result= mysqli_query($con,$sql);
            if (!$result) {
                die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
            }
        }
        //Editar la informacion de banner 1
        $sql= "UPDATE configuracion SET titulo='$titulo2',descripcion='$descripcion2' WHERE idsetting=2";
        $result= mysqli_query($con,$sql);
        if (!$result) {
            die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
        }

        /* Tercer Banner */
        $titulo3=$_POST["titlebann3"];
        $descripcion3=$_POST["decripbann3"];
        
        $nombreArchivo3 = $_FILES['imagen3']['name'];
        $nombreTemporal3 = $_FILES['imagen3']['tmp_name'];
        $ruta3 = null;
        if(!empty($nombreArchivo3)){
            $ruta3 = "./images/bannerhome/". $nombreArchivo3;
            move_uploaded_file($nombreTemporal3,"../images/bannerhome/". $nombreArchivo3);
        }

        if(isset($ruta3)){
            //Editar la imagen de banner 1
            $sql= "UPDATE configuracion SET imagen='$ruta3' WHERE idsetting=3";
            $result= mysqli_query($con,$sql);
            if (!$result) {
                die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
            }
        }
        //Editar la informacion de banner 1
        $sql= "UPDATE configuracion SET titulo='$titulo3',descripcion='$descripcion3' WHERE idsetting=3";
        $result= mysqli_query($con,$sql);
        if (!$result) {
            die("ERROR AL ACTUALIZAR LA IMAGEN".mysqli_error($con));
        }

    }


    /* Consultar configuraciones */

    $sql="SELECT * FROM configuracion;";
    $result= mysqli_query($con,$sql);
    if(!$result) die("ERROR AL CONSULTAR CONFIGURACIONES".mysqli_error($con));
    $banners=array();
    while ($row = mysqli_fetch_array($result)) {
        $banners[]= array(
            "titulo"=>$row['titulo'],
            "descripcion"=>$row['descripcion'],
            "imagen"=>$row['imagen']
        );
    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content ">
                
                <form method="post" class="config__form" enctype="multipart/form-data">
                    <div class="form__main">

                        <!-- Agregar primer banner -->
                        <div class="img__container">
                            <img src="<?php if($banners[0]["imagen"]!=null){ echo ".".$banners[0]["imagen"];}else{echo '../images/bannerhome/default.jpg';}?>" alt="" id="cimg">
                            
                            
                            <div class="img__container-input">
                                <input type="file" name="imagen" onchange="displayImg(this,$(this),'cimg')">
                                <input type="text" name="titlebann1" placeholder="Título" value="<?php if($banners[0]["titulo"]!=null) echo $banners[0]["titulo"]?>">

                                <textarea name="decripbann1" id="decripbann1" cols="30" rows="10" placeholder="Descripción"><?php if($banners[0]["descripcion"]!=null) echo $banners[0]["descripcion"];?></textarea>
                            </div>
                        </div>

                        <!-- Agregar segundo banner -->
                        <div class="img__container">
                            <img src="<?php if($banners[1]["imagen"]!=null){ echo ".".$banners[1]["imagen"];}else{echo '../images/bannerhome/default.jpg';}?>" alt="" id="cimg2">
                            
                            
                            <div class="img__container-input">
                                <input type="file" name="imagen2" onchange="displayImg(this,$(this),'cimg2')">
                                <input type="text" name="titlebann2" placeholder="Título" value="<?php if($banners[1]["titulo"]!=null) echo $banners[1]["titulo"]?>">

                                <textarea name="decripbann2" id="decripbann2" cols="30" rows="10" placeholder="Descripción"><?php if($banners[1]["descripcion"]!=null) echo $banners[1]["descripcion"];?></textarea>
                            </div>
                           
                        </div>

                        <!-- Agregar tercer banner -->
                        <div class="img__container">
                            <img src="<?php if($banners[2]["imagen"]!=null){ echo ".".$banners[2]["imagen"];}else{echo '../images/bannerhome/default.jpg';}?>" alt="" id="cimg3">
                            
                            
                            <div class="img__container-input">
                                <input type="file" name="imagen3" onchange="displayImg(this,$(this),'cimg3')">
                                <input type="text" name="titlebann3" placeholder="Título" value="<?php if($banners[2]["titulo"]!=null) echo $banners[2]["titulo"]?>">

                                <textarea name="decripbann3" id="decripbann3" cols="30" rows="10" placeholder="Descripción"  ><?php if($banners[2]["descripcion"]!=null) echo $banners[2]["descripcion"];?></textarea>
                            </div>
                           
                        </div>

                    </div>
                    <div class="formFooter">
                        <input type="submit" value="Guardar cambios" class="bttn btn" name="guardar">
                        <input type="reset" value="Restablecer " class="bttn2 btn2" onclick="location.reload()">
                    </div>
                </form>
            </div>
        </div>
                
        <div class="modalContainer " id="v2"></div>
        <div class="modalContainer " id="v3"></div>
        <?php include("../includes/modales/checkOut.php") ?>
        <?php include("../includes/modales/checkOut4.php") ?>



    </main>
</body>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>


    <!-- Script para previsualizar imagenes -->
    <script>
        function displayImg(input,_this,idimg) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#'+idimg).attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }

	}
    </script>
    
    <script src="ajaxjs/checkout.js"></script>
    <script src="../js/table.js"></script>
    <script src="../js/modal.js"></script>
</html>