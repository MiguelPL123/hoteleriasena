<?php
    include('../includes/conexion.php');
    include('facturacion/consultas.php');
    include('facturacion/consultas2.php');
    session_start();

    /* Inicializar valores */
    $datos=array(
        "nombre"=>null,
        "cc"=>null,
        "habitacion"=>null,
        "noches"=>null,
        "direccion"=>null,
        "ciudad"=>null,
        "fechain"=>null,
        "fechaout"=>null,
        "caja"=>null,
        "plan"=>null,
        "huesped"=>null,
        "ident"=>null,
        "compañia"=>null,
        "personas"=>null,

    );

    $alojamiento=array();
    $alojamientosiniva=array();
    $cargosextras=array();
    $codigoFactura=0;
    //----------------------

    if (isset($_SESSION['facturamaster'])) {

        if ($valores[2]=="Grupal") {
            $foliomaestro= consultarFolioMaestro($valores[0]);
            $datos=consultardatospersonales($foliomaestro);
            $alojamiento=consultarcargoAlojamiento($foliomaestro);

            //Calcular iva
            $iva=$alojamiento*0.19;
            $alojamientosiniva=$alojamiento-$iva;

            $cargosextras=consultarcargosextras($foliomaestro);

        }else if($valores[2]=="Individual"){
            $sql="SELECT * FROM `reserva` AS r INNER JOIN empresa AS e ON r.nit=e.nit WHERE cod_reserva='$valores[0]';";
            $result=mysqli_query($con,$sql);
            if(!$result) die("ERROR AL CONSULTAR RESERVA INDIVIDUAL". mysqli_error($con));
            while ($row = mysqli_fetch_array($result)) {
                $clientes=consultarClientes($row['cedula']);
                $datos=array(
                    'nombre'=>$clientes['nombres'],
                    "cc"=>$clientes['cedula'],
                    "habitacion"=>'Habitacion '.consultarhabitacion($row['idhabitacion']),
                    "noches"=>calculardiasdeestadia($row['date_in'],$row['date_out']),
                    "direccion"=>$clientes['direccion'],
                    "ciudad"=>$clientes['ciudad'],
                    "fechain"=>$row['date_in'],
                    "fechaout"=>$row['date_out'],
                    "caja"=>combinacionNumerica(3),
                    "plan"=>"CORP",
                    "huesped"=>$clientes['nombres'],
                    "ident"=>$row['nit'],
                    "compañia"=>$row['nombre'],
                    "personas"=>$row['numero_personas']
                );
                if ($row['total']!=null) {
                    $alojamiento=$row['total'];

                    $iva=$alojamiento*0.19;
                    $alojamientosiniva=$alojamiento-$iva;
                }
            }

            //Cargos
            $sql="SELECT nombres,precios FROM `consumo` AS c INNER JOIN servicios AS s ON c.codServicio=s.codServicio WHERE codReserva='$valores[0]';";
            $result=mysqli_query($con,$sql);
            if(!$result) die("ERROR AL CONSULTAR CARGOS RESERVA INDIVIDUAL". mysqli_error($con));
            while ($row = mysqli_fetch_array($result)) {
                $nombreservicio=$row['nombres'];
                $preciototalcargo=$row['precios'];
                if (array_key_exists($nombreservicio,$cargosextras)) {
                    $cargosextras[$nombreservicio]+=$preciototalcargo;
                }else{
                    $cargosextras[$nombreservicio]=$preciototalcargo;
                }
            }

            var_dump($cargosextras);
        }
    }else if (isset($_SESSION['factufolioextra'])){
        $folioextra=$_SESSION['factufolioextra'];
        $foliomaestro=consultafoliomaestro($folioextra);
        $datos=consultardatospersonales($foliomaestro);
        
        $alojamiento=consultarcargoAlojamientoFolioExtra($folioextra);


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="../css/factura.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">

    <script src="/js/html2pdf.bundle.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js" integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <title>Document</title>
</head>
<body>
    <header class="flex">
       <div class="logo">
            <img src="../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main>
        <!-- <?php include("includes/dashNav.php") ?> -->
        <div class="container">
            <div class="content">
                <div class="facCont">
               
                    <div class="factura" id="PDF">
                        <div class="row row1">
                            <div class="col">
                                <img src="../images/senanaranja.png" alt="">
                                <h2>SENA</h2>
                                <span>01467</span>
                                <span>01467</span>

                            </div>
                            <div class="col">
                                <h2>SENA HOTELERIA Y TURISMO</h2>
                                <h2>SENA</h2>
                                <span>NIT  899999034-1</span>
                                <span>Cl. 40b #21-142</span>
                                <span>CTG</span>
                                <span>GRANDES CONTRUBUYENTES</span>
                            </div>
                            <div class="col">
                                <h2>FACTURA CAMBIARIA</h2>
                                <h2>DE COMPRAVENTA</h2>
                                <p>NO: </p>
                                <h2>Fecha Factura</h2>
                                <span></span>
                                <h2>Fecha Vencimiento</h2>
                                <span>2010.12.31</span>
                            </div>
                        </div>
                        <div class="row row2">
                            <div class="col">
                                <h2>Nombre:</h2>
                                <span> <?php echo $datos['nombre'];?> </span>
                            </div>
                            <div class="col">
                                <h2>CC / Nit</h2>
                                <span><?php echo $datos['cc'];?> </span>
                            </div>
                            <div class="col">
                                <h2> Habitación</h2>
                                <span><?php echo $datos['habitacion'];?></span>
                            </div>
                            <div class="col">
                                <h2>Noches:</h2>
                                <span><?php echo $datos['noches'];?></span>
                            </div>
                        </div>
                        <div class="row row3">
                            <div class="col">
                                <h2>Dirección:</h2>
                                <span><?php echo $datos['direccion'];?></span>
                            </div>
                            <div class="col">
                                <h2>Ciudad:</h2>
                                <span><?php echo $datos['ciudad'];?></span>

                            </div>
                            <div class="col">
                                <h2>Fecha llegada:</h2>
                                <span><?php echo $datos['fechain'];?></span>
                            </div>
                            <div class="col">
                                <h2>Fecha salida:</h2>
                                <span><?php echo $datos['fechaout'];?></span>
                            </div>
                            <div class="col">
                                <h2>Caja:</h2>
                                <span><?php echo $datos['caja'];?></span>
                            </div>
                            <div class="col">
                                <h2>Plan:</h2>
                                <span><?php echo $datos['plan'];?></span>
                            </div>

                        </div>
                        <div class="row row4">
                            <div class="col">
                                <h2>Huésped:</h2>
                                <span><?php echo $datos['huesped'];?></span>
                            </div>
                            <div class="col">
                                <h2>Ident:</h2>
                                <span><?php echo $datos['ident'];?></span>
                            </div>
                            <div class="col">
                                <h2>Compañía:</h2>
                                <span><?php echo $datos['compañia'];?></span>
                            </div>
                            <div class="col">
                                <h2>Número de personas:</h2>
                                <span><?php echo $datos['personas'];?></span>
                            </div>

                        </div>
                        <div class="row minrow">
                            <div class="col">Concepto</div>
                            <div class="col">Tiquete</div>
                            <div class="col">Valor</div>
                            <div class="col">IVA</div>
                            <div class="col">Servicio</div>
                            <div class="col">Total</div>
                            <div class="col">Abonos</div>
                            <div class="col">Saldo</div>
                        </div>
                        <div class="row row5">
                            <div class="maincol">
                                <div class="col ">
                                    <div class="col ">
                                        <span>ALOJAMIENTO</span>
                                    </div>
                                    <div class="col ">
                                        <span>Noches: <?php echo $datos['noches'];?></span>
                                    </div>
                                    <div class="col ">
                                        <span>$ <?php if($alojamientosiniva!=null) echo $alojamientosiniva;?></span>
                                    </div>
                                    <div class="col ">
                                        <span>19%</span>
                                    </div>
                                    <div class="col ">
                                        <span>ALOJAMIENTO</span>
                                    </div>
                                    <div class="col ">
                                        <span>$ <?php if($alojamiento!=null) echo $alojamiento;?></span>
                                    </div>
                                    <div class="col ">
                                        <span>$ 0.00</span>
                                    </div>
                                    <div class="col ">
                                        <span>$ 0.00</span>
                                    </div>
                                    <!-- Consultar cargos -->
                                    <?php foreach ($cargosextras as $key => $value): ?>
                                    <!-- //Foreach -->
                                    <div class="col ">
                                        <span><?php echo $key;?></span>
                                    </div>
                                    <div class="col ">
                                        <span></span>
                                    </div>
                                    <div class="col ">
                                        <span>$ 
                                            <?php echo $value-($value*0.19);?>
                                        </span>
                                    </div>
                                    <div class="col ">
                                        <span>19%</span>
                                    </div>
                                    <div class="col ">
                                        <span><?php echo $key;?></span>
                                    </div>
                                    <div class="col ">
                                        <span>$ <?php echo $value;?></span>
                                    </div>
                                    <div class="col ">
                                        <span>$ 0.00</span>
                                    </div>
                                    <div class="col ">
                                        <span>$ 0.00</span>
                                    </div>
                                    <?php endforeach;?>
                                <!-- //endforeach -->
                                </div>
                            <div class="col lastCol">
                                    <div class="col ">
                                        <span> Subtotales </span>
                                    </div>
                                    <div class="col ">
                                        <span> $  </span>
                                    </div>
                                    <div class="col ">
                                        <span></span>
                                    </div>
                                    <div class="col ">
                                        <span> $  </span>
                                    </div>
                                    <div class="col ">
                                        <span></span>
                                    </div>
                                    <div class="col ">
                                        <span> $  </span>
                                    </div>
                                    <div class="col ">
                                        <span> $  </span>
                                    </div>
                                    <div class="col ">
                                        <span> 0 </span>
                                    </div>
                                </div>
                            </div>

                        </div>
                        <div class="row minrow2">
                            <div class="col">Resumen cargos</div>
                            <div class="col">Resumen Impuestos</div>
                        </div>
                        <div class="row row6">
                            <div class="maincol2">
                                <div class="colRow">
                                    <div class="col">
                                        <span></span>
                                    </div>
                                    <div class="col">
                                        <span></span>
                                    </div>
                                </div>
                                <div class="colRow">
                                    <div class="col">
                                        <?php echo "Total:"?>
                                    </div>
                                    <div class="col">
                                    </div>
                                </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span></span>
                                    </div>
                                    <div class="col">
                                        <span></span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span></span>
                                    </div>
                                    <div class="col">
                                        <span></span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span></span>
                                    </div>
                                    <div class="col">
                                        <span></span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span></span>
                                    </div>
                                    <div class="col">
                                        <span></span>
                                    </div>
                               </div>
                            </div>
                        
                            <div class="maincol2">
                                <div class="colRow">
                                    <div class="col">
                                        <span>Total Cargos No Gravados</span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total Cargos Gravados</span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total Cargos Gravados 10.00%: </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total Cargos Gravados 16.00%: </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total IVA 10.00%: </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total IVA 16.00%: </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total SERVICIO </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total Abonos y Pagos </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>

                               <div class="colRow">
                                    <div class="col">
                                        <span>Cxc </span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Retención</span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                               <div class="colRow">
                                    <div class="col">
                                        <span>Total</span>
                                    </div>
                                    <div class="col">
                                        <span>0.00</span>
                                    </div>
                               </div>
                            </div>
                        </div>

                        <div class="row row7">
                            <div class="col">
                                <span>Favor consignar a la Cta de ahorro #XXX-XXXXXX-X </span>
                                <span>del banco XXXXXXXXXX a nombre de XXXXXXXXXXXXXXXXXXXXXXXXXXXXX</span>
                            </div>
                            <div class="col">
                                <h2>Total de cargos</h2>
                                <span>$ </span>
                            </div>
                            <div class="col">
                                <span>Total</span>
                                <h2>$ </h2>
                            </div>
                            <div class="col">
                                <span>Total Abonos</span>
                                <h2>$ </h2>
                            </div>
                            <div class="col">
                                <span>CxC</span>
                                <h2>$ </h2>
                            </div>
                        </div>
                        <div class="row row8">
                            <div class="col firma">
                                <div class="col minrow2">Transpao de particulares</div>
                                <div class="firmaCont">
                                    <div class=" firma__content">
                                        <div class="object">
                                            <p>Nombre</p>
                                            <span></span>
                                        </div>
                                        <div class="object">
                                            <p>Firma</p>
                                            <span></span>
                                       
                                        </div>
                                    </div>
                                    <div class="col firma__desc"><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam voluptate quae, voluptatem atque nisi porro quas sapiente, voluptas vel reprehenderit laudantium molestiae nesciunt minus doloribus repellat dicta? Dolore velit culpa,
                                        tempore dolor, maiores vel at nesciunt culpa error? Laudantium, quidem</p>.</div>
                                </div>
                            </div>
                            <div class="col bigCol"><p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Reprehenderit nam aliquam iusto veritatis. Aperiam odio pariatur iusto facilis hic velit.</p></div>
                        </div>


                    </div>
                </div>
                <header class="bg1">
                    <div class="row fot">
                        <input type="button" class="bttn btn" value="Descargar factura" onclick="generarPDF()">
                        <a href="checkOut.php" class=" bttn btn2">Volver</a>
                    </div>
                </header>

            </div>
        </div>
    </main>
</body>-
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="ajaxjs/checkout.js"></script>
<script src="../js/table.js"></script>

<script src="/js/html2canvas.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js" integrity="sha512-BNaRQnYJYiPSqHHDb58B0yaPfCu+Wgds8Gp/gU33kqBtgNS4tSPHuGibyoeqMV/TJlSKda6FXzoEyYGjTe+vXA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.js" integrity="sha512-sn/GHTj+FCxK5wam7k9w4gPPm6zss4Zwl/X9wgrvGMFbnedR8lTUSLdsolDRBRzsX6N+YgG6OWyvn9qaFVXH9w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.bundle.min.js" integrity="sha512-w3u9q/DeneCSwUDjhiMNibTRh/1i/gScBVp2imNVAMCt6cUHIw6xzhzcPFIaL3Q1EbI2l+nu17q2aLJJLo4ZYg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.bundle.js" integrity="sha512-VqCeCECsaE2fYTxvPQk+OJ7+SQxzI1xZ6IqxuWd0GPKaJoeSFqeakVqNpMbx1AArieciBF71poL0dYTMiNgVxA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.js" integrity="sha512-liPvfWpzKp7bXBAK05m+Uqrv5ATN4kCeUh64IygMoo98oEcTELOrymzU8omW2mEZszHHJ+qPOSkEzJLs2QqwQg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.8.0/html2pdf.min.js" integrity="sha512-2ziYH4Qk1Cs0McWDB9jfPYzvRgxC8Cj62BUC2fhwrP/sUBkkfjYk3142xTKyuCyGWL4ooW8wWOzMTX86X1xe3Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="../js/generarPDF.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>