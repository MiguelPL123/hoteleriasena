<?php
    include('../../includes/conexion.php');
    session_start();
    
    $datosempresa=array();
    $datosReserva=array();
    //Registrar Reserva temporal
    //
    if(isset($_POST['personas'])){
        //Datos de Empresa
        $codigoempre=$_POST['codigo'];
        $empresa=$_POST['nombre'];
        $nit=$_POST['nit'];
        $pais=$_POST['pais'];
        $ciudad=$_POST['ciudad'];
        $direccion=$_POST['direccion'];
        $telefono=$_POST['telefono'];
        $contacto=$_POST['contacto'];
        $cargo=$_POST['cargo'];
        $medio=$_POST['medio'];
        $correoCorp=$_POST['correoCor'];
        //Datos de Reserva
        $FechaCotiza=$_POST['FechaCotiza'];
        $FechaLlegada=$_POST['fechaLlegada'];
        $FechaSalida=$_POST['fechaSalida'];
        $personas=$_POST['personas'];
        $Reserva=$_POST['Reserva'];
        $foliomaestro=$_POST['maestro'];

        //Almacenamiento los valores temporales
        $datosempresa=array(
            "codigo"=> $codigoempre,
            "nombre"=> $empresa,
            "nit"=> $nit,
            "pais"=> $pais,
            "ciudad"=> $ciudad,
            "direccion"=> $direccion,
            "telefono"=> $telefono,
            "contacto"=> $contacto,
            "cargo"=> $cargo,
            "medio"=> $medio,
            "correoCorp"=> $correoCorp
        );

        $datosReserva=array(
            "fechaCotizacion"=>$FechaCotiza,
            "fechaLlegada"=>$FechaLlegada,
            "fechaSalida"=>$FechaSalida,
            "numeroPersonas"=>$personas,
            "codreserva"=>$Reserva,
            "folioMaestro"=>$foliomaestro
        );

        $_SESSION['datosempresa']=$datosempresa;
        $_SESSION['datosreseva']=$datosReserva;
        $_SESSION['personas']=$personas;

        header("Location: newClienGrupal.php");
    }


    /* Consultar empresas registradas */
    $result=mysqli_query($con,"SELECT COUNT(*) FROM empresa;");
    if(!$result) die("ERROR AL CONTAR TABLA EMPRESA".mysqli_error($con));

    $numero=mysqli_fetch_array($result)['COUNT(*)'];
    /* -------------------------------- */
    
    //Funciones para generar codigos para la reserva
    function combinacionAutoreLlenado($numero){//Ejemplo: 00001
        $longitud=strlen($numero);
        $codigo="";
        for ($i=0; $i < (6-$longitud); $i++) { 
            $codigo=$codigo."0";
        }
        $codigo=$codigo.($numero+1);
        return $codigo;
    }

    function combinacionAlfaNumerico($ndigitos){
        $alf="abcdefghijklmnopqrstuvwxyz";
        $codigo="";
        $numero=true;
        for ($i=0; $i < $ndigitos; $i++) { 
            if ($numero){
                $digito=rand(0,9);
                $codigo=$codigo.$digito;
                $numero=false;
            } else {
                $posicion=rand(0,strlen($alf)-1);
                $codigo=$codigo.strtolower($alf[$posicion]);
                $numero=true;
            }
        }
        return $codigo;
    };

    function combinacionNumerica($ndigitos){
        $codigo="";
        for ($i=0; $i < $ndigitos; $i++) {
            $numero=rand(0,9);
            $codigo=$codigo."$numero";
        }
        return $codigo;
    };

    //Comsultar paises
    $result=mysqli_query($con,"SELECT * FROM paises ORDER BY Pais ASC");
    if(!$result)die("ERROR AL CONSULTAR PAISES".mysqli_error($con));

    $paises=array();
    while($row = mysqli_fetch_array($result)){
        $paises[]=array($row['Codigo'],$row['Pais']);
    }


    //Consultar Servicios Disponibles
    $result=mysqli_query($con,"SELECT * FROM servicios");
    if(!$result) die("ERROR AL CONSULTAR LOS SERVICIOS".mysqli_error($con));
    $servicios=array();
    while ($row = mysqli_fetch_array($result)) {
        $servicios[]=array(
            "codServicio"=>$row['codServicio'],
            "nombres"=>$row['nombres']
        );
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <style>.dataTables_filter {display: none;}#example_wrapper{width:100%;}</style>

    <title>Document</title>
</head>

<body> 
    <header class="flex">
       <div class="logo">
            <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
            </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <i><span class="material-symbols-outlined">
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
            <div class="content">
                <div class="forms">
                    <form method="POST">
                        <!-- Datos de la empresa -->
                        <span>Nueva reserva grupal </span>
                        <h2>Información empresa</h2>

                        <?php if(isset($alert)):?>
                        <div class="alert">
                            <?php echo $alert;?>
                        </div>
                        <?php endif;?>

                        <div class="side">
                            <div class="inputC">
                                <label for="">Código</label>
                                <input type="text" placeholder="  " id="codigo" name="codigo" value="<?php if(count($datosempresa)>0){echo $datosempresa["codigo"];}else{echo combinacionAutoreLlenado($numero);}?>" required>
                            </div>

                            <div class="inputC">
                                <label for="">Nombre Empresa</label>
                                <input type="text" placeholder="  " id="nombre" name="nombre" value="<?php if(count($datosempresa)>0){echo $datosempresa["nombre"];}?>" required>
                            </div>

                            <div class="inputC">
                                <label for="">NIT</label>
                                <input type="text" placeholder="  " name="nit" id="nit" value="<?php if(count($datosempresa)>0){echo $datosempresa["nit"];}?>" required>
                            </div>
                            <div class="inputC">
                                <label for="">País</label>
                                <select id="pais" name="pais">
                                    <option value="select" >Seleccione</option>
                                    <?php foreach($paises as $value):?>
                                    <option value="<?php echo $value[0]?>" id="<?php echo $value[0]?>" <?php if(count($datosempresa)>0){if($datosempresa["pais"]==$value[0]) echo 'selected';}?>><?php echo $value[1]?></option>
                                    <?php endforeach;?>
                                </select>
                            </div>

                            <!-- En caso de a ver un pais seleccionado consultar las ciudades de este -->
                            <?php
                                $ciudades=array();
                                if(count($datosempresa)>0){
                                    $id=$datosempresa["pais"];
                                    $result=mysqli_query($con,"SELECT * FROM ciudades WHERE Paises_Codigo='$id'");
                                    if (!$result) die("ERROR AL CONSULTAR CIUDADES".mysqli_error($con));
                                    
                            
                                    while($row = mysqli_fetch_array($result)){
                                        $ciudades[]= array(
                                            "ciudad" => utf8_encode($row['Ciudad']),
                                        );
                                    }       
                                }
                            ?>
                            <!-- ------------------------------------------------ -->

                            <div class="inputC">
                                <label for="">Ciudad</label>
                                <select name="ciudad" id="ciudad">
                                    <option >Seleccione..</option>
                                    <?php if(count($ciudades)>0):
                                            foreach ($ciudades as $key => $value):
                                    ?>
                                        <option value="<?php echo $value['ciudad'];?>" <?php if($datosempresa["ciudad"]==$value['ciudad']) echo 'selected';?>><?php echo $value['ciudad'];?></option>
                                    <?php   endforeach;
                                         endif;?>
                                </select>
                            </div>
                         
                            <div class="inputC">
                                <label for="">Dirección</label>
                                <input type="text" placeholder="  " name="direccion" id="direccion" value="<?php if(count($datosempresa)>0){echo $datosempresa["direccion"];}?>" required>
                            </div>
                            <div class="inputC">
                                <label for="">Teléfono</label>
                                <input type="text" placeholder="  " name="telefono" id="telefono" required value="<?php if(count($datosempresa)>0){echo $datosempresa["telefono"];}?>">
                            </div>

                            <div class="inputC">
                                <label for="">Correo corporativo</label>
                                <input type="text" placeholder="  " id="correoCor" name="correoCor" value="<?php if(count($datosempresa)>0){echo $datosempresa["correoCorp"];}?>">
                            </div>
                      
                            <div class="inputC">
                                <label for="">Contacto</label>
                                <input type="text" placeholder="  " name="contacto" id="contacto" required value="<?php if(count($datosempresa)>0){echo $datosempresa["contacto"];}?>">
                            </div>
                            <div class="inputC">
                                <label for="">Cargo</label>
                                <input type="text" placeholder="  " name="cargo" id="cargo" required value="<?php if(count($datosempresa)>0){echo $datosempresa["cargo"];}?>">
                            </div>
                            <div class="inputC">
                                <label for="">Medio</label>
                                <select name="medio" id="medio">
                                    <option value="select" id="medio" >Seleccione...</option>
                                    <option value="carta" id="carta" <?php if(count($datosempresa)>0){if($datosempresa["medio"]=="carta") echo 'selected';}?>>Carta</option>
                                    <option value="correo" id="correo" <?php if(count($datosempresa)>0){if($datosempresa["medio"]=="correo") echo 'selected';}?>>Correo</option>
                                    <option value="llamada" id="llamada" <?php if(count($datosempresa)>0){if($datosempresa["medio"]=="llamada") echo 'selected';}?>>Llamada</option>

                                </select>
                            </div>
                            
                        </div>
                        <!-- Datos para la reserva -->
                        <h2>Información reserva</h2>
                        <div class="side">
                            <div class="inputC">
                                <label>Fecha de cotización</label>
                                <input type="date" name="FechaCotiza" placeholder="  " value="<?php if(count($datosReserva)>0){echo $datosReserva['fechaCotizacion'];}?>" required>
                            </div>
                            <div class="inputC">
                                <label>Fecha de llegada</label>
                                <input type="date" name="fechaLlegada" placeholder="  "   value="<?php if(count($datosReserva)>0){echo $datosReserva['fechaLlegada'];}?>" required>
                            </div>
                            <div class="inputC">
                                <label>Fecha de salida</label>
                                <input type="date" name="fechaSalida" placeholder="  "  value="<?php if(count($datosReserva)>0){echo $datosReserva['fechaSalida'];}?>" required>
                            </div>
                            <div class="inputC">
                                <label>Personas</label>
                                <input type="number" name="personas" min="1" placeholder="  "   value="<?php if(count($datosReserva)>0){echo $datosReserva['numeroPersonas'];}?>" id="numpersonas" required>
                            </div>
                            <div class="inputC">
                                <label>Reserva</label>
                                <input type="text" name="Reserva" placeholder="  "  style="text-transform: uppercase;" value="<?php if(count($datosReserva)>0){ echo $datosReserva['codreserva'];}else{echo combinacionAlfaNumerico(6);}?>" required readonly>
                            </div>
                            <div class="inputC">
                                <label>Folio maestro</label>
                                <input type="text"  name="maestro" placeholder="  " style="text-transform: uppercase;" value="<?php if(count($datosReserva)>0){ echo $datosReserva['folioMaestro'];}else{echo combinacionNumerica(6);}?>" required readonly>
                            </div>
                        </div>
                            <!-- Informacion de reserva -->
                        <h2>Registro cargos</h2>
                        <div class="side">
                            <table id="example" class="display"  style="width: 100%">
                                <thead>
                                    <tr>
                                        <th>Descripción</th>
                                        <th>Personas</th>
                                        <th>Valor</th>
                                        <th>IVA</th>
                                        <th>Total+IVA</th>
                                        <th class="opt">Acción</th>
                                    </tr>
                                </thead>
                                <tbody id="cuerpotablacargo">
                                        <tr id="cargoAlojamiento">
                                            <td>Alojamiento</td>
                                            <td>0</td>
                                            <td>0</td>
                                            <td>19%</td>
                                            <td>0</td>
                                            <td class="tbOpt">
                                                <!-- <input type="button" class="bttn btn2" value="Eliminar"> -->
                                            </td>
                                        </tr>
                                    <?php
                                        if(isset($_SESSION["cargosReserva"])):
                                            foreach ($_SESSION["cargosReserva"] as $key => $value):
                                    ?>
                                        <tr id-cargo='<?php echo $value["codServicio"];?>'>
                                            <td><?php echo $value["descripcion"];?></td>
                                            <td><?php echo $value["personas"];?></td>
                                            <td><?php echo $value["valor"];?></td>
                                            <td>19%</td>
                                            <td><?php echo $value["total"];?></td>
                                            <td class="tbOpt">
                                                <input type="button" class="bttn btn2 DeleteCategoria" value="Eliminar" onclick="eliminarcargo(this)">
                                            </td>
                                        </tr>
                                    <?php   endforeach;
                                        endif;?>
                                </tbody>
                            </table>
                            <h2><input type="button" class="bttn btn" value="Añadir Cargos extras" onclick="validarAccesoCargos()"></h2>
                            <!-- location.reload() -->

                        </div>
                  
                        
                        <div class="formFooter">
                            <input  type="submit" class="bttn btn" value="Registrar reserva">
                            <a href="../reservaGrupal.php" class="bttn2 btn2">Cancelar</a>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    <?php include("../../includes/modales/gastoGrup.php") ?>
    <div class="modalContainer " id="v2"></div>
    <?php include("../../includes/modales/deleteModal.php") ?>
    <div class="modalContainer " id="v4"></div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="../js/table.js"></script>
<script src="../ajaxjs/reservaGrupal.js"></script>

<script src="../../js/modal.js"></script>

<script  src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script>$(document).ready(function () {$('#example').DataTable({responsive: true,scrollCollapse: true,paging: false,search:false,});});</script>
</html>