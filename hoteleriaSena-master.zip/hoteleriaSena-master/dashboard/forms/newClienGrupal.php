<?php

  include('../../includes/conexion.php');
  session_start();
  if (!isset($_SESSION['tipo'])) {
    header("Location: ../clien.php");
  }

  $alert=null;
  /* Datos de clientes */
  $tipo=null;
  $cedula=null;
  $nombre=null;
  $apellido=null;
  $correo=null;
  $pais=null;/* Detalles de cliente */
  $fecha=null;
  $lugar=null;
  $genero=null;
  $correo_corporativo=null;
  $telefono=null;
  $telefono_auxiliar=null;
  /* Datos de reserva */
  //Datos de empresa
  //----------------

  if(isset($_POST['cedula'])){
      $_SESSION['personas']-=1;

      $tipoDoc=$_POST['tipoDoc'];
      $cedula=$_POST['cedula'];
      $nombre=$_POST['nombre'];
      $apellido=$_POST['apellido'];
      $fechanaci=$_POST['fechanaci'];
      $lugarNacimiento=$_POST['lugarNacimiento'];
      $pais=$_POST['pais'];
      $ciudadR=$_POST['ciudadR'];
      $direccion=$_POST['direccion'];
      $genero=$_POST['genero'];
      $correoPersonal=$_POST['correoPersonal'];
      $telefonoMovil=$_POST['telefonoMovil'];
      $telefonoAux=$_POST['telefonoAux'];

      $_SESSION['registrosClientes'][$cedula]=array(
        "tipo"=>$tipoDoc,
        "cedula"=>$cedula,
        "nombre"=>$nombre,
        "apellido"=>$apellido,
        "fechanaci"=>$fechanaci,
        "lugarNacimiento"=>$lugarNacimiento,
        "pais"=>$pais,
        "ciudadR"=>$ciudadR,
        "direccion"=>$direccion,
        "genero"=>$genero,
        "correoPersonal"=>$correoPersonal,
        "telefonoMovil"=>$telefonoMovil,
        "telefonoAux"=>$telefonoAux,
        "habitacion-asignada"=>null
      );
      
      if ($_SESSION['personas']==0) {
        header("Location: newReservaGrupalHab.php");
      }
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Registro de Cliente</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
           <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
           </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
            <div class="content">
                <div class="forms">
                    <form action="" method="POST">
                            <span>Registro de cliente : <?php echo $_SESSION["personas"]?></span>

                            <?php if(isset($alert)):?>
                            <div class="alert">
                                <?php echo $alert;?>
                            </div>
                            <?php endif;?>
                            
                            <?php if(!isset($alert)):?>
                            <div style="color: #000; margin-top: 13px; background-color: #e2e3e5; padding: 8px; border-radius: 5px;">
                                Recuerde que debe llenar los campos obligatorios(*)
                            </div>
                            <?php endif;?>
                            <div class="side">
                                
                                <div class="inputC">
                                    <label for="">Tipo de documento&nbsp;<p class="required">*</p></label>
                                    <select name="tipoDoc" id="tipoDoc"><!-- Obligatorio -->
                                        <option value="select">Tipo de Identificación</option>
                                        <option value="TI" <?php if(isset($tipo)){if($tipo=="TI"){echo 'selected';}}?>>Tarjeta de identidad</option>
                                        <option value="CC" <?php if(isset($tipo)){if($tipo=="CC"){echo 'selected';}}?>>Cédula de ciudadania</option>
                                        <option value="CE" <?php if(isset($tipo)){if($tipo=="CE"){echo 'selected';}}?>>Cedula Extranjera</option>
                                    </select>
                                </div>

                                <div class="inputC">
                                    <label for="">Identificación&nbsp;<p class="required">*</p></label>
                                    <input type="number" placeholder="  " name="cedula" required id="cedula"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Nombres&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="nombre" id="nombre" required><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Apellidos&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="apellido" id="apellido" required ><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Fecha de nacimiento&nbsp;<p class="required">*</p></label>
                                    <input type="date" name="fechanaci" id="fecha" required ><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Lugar de nacimiento&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " id="lugar" name="lugarNacimiento" required ><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">País&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="pais" id="pais" required ><!-- Obligatorio -->
                                </div>
                              
                                <div class="inputC">
                                    <label for="">Ciudad de residencia</label>
                                    <input type="text" placeholder="  " name="ciudadR" id="ciudad">
                                </div>

                                <div class="inputC">
                                    <label for="">Dirección de residencia</label>
                                    <input type="text" placeholder="  " name="direccion" id="direccion">
                                </div>

                                <div class="inputC">
                                    <label for="">Género&nbsp;<p class="required">*</p></label>
                                    <label for=""><!-- Obligatorio -->
                                        <input type="radio" name="genero" id="masculino" value="masculino">Masculino
                                        <input type="radio" name="genero" id="femenino" value="femenino">Femenino
                                        <input type="radio" name="genero" id="otros" value="otro">Otro
                                    </label>
                                </div>
                                <div class="inputC">
                                    <label for="">Correo personal&nbsp;<p class="required">*</p></label>
                                    <input type="email" placeholder="  " name="correoPersonal" id="correo" required><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono móvil&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="telefonoMovil" id="telefonoMovil" required><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono auxiliar</label>
                                    <input type="text" placeholder="  " name="telefonoAux" id="telefonoAux">
                                </div>
                            </div>

                            <div class="formFooter">
                                <!-- <input type="submit" value="Añadir cliente" class="bttn btn"> -->
                            <input type="submit" class="bttn btn" value="Añadir cliente">
                                <a href="newReservaGrupal.php" class="bttn2 btn2">Cancelar</a>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>
<script src="../ajaxjs/newClienGrupal.js"></script>

<script src="../js/table.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>