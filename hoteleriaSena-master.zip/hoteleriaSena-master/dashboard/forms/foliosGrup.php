<?php

    include('../../includes/conexion.php');
    session_start();

    unset($_SESSION['factufolioextra']);
    $idMaestro=null;
    if(isset($_SESSION['idFolioMaestro'])){
        $idMaestro=$_SESSION['idFolioMaestro'];

    }

    $estado=null;
    $verReserva="SELECT estado FROM `reserva_grupal` WHERE folio_maestro='$idMaestro'";
    $resuld=mysqli_query($con,$verReserva);
    if(!$resuld)die("error".mysqli_error($con));

    $estado=mysqli_fetch_array($resuld)['estado'];

    $sql="SELECT fe.folio_extra, h.piso, h.numero_habitacion FROM `folios_extra` as fe INNER JOIN habitacion as h ON fe.idHabitacion=h.idHabitacion INNER JOIN clie_reserva_grupál as clie ON clie.folio_extra=fe.folio_extra WHERE fe.folio_maestro='$idMaestro' and clie.fecha_llegada is not null";
    $result=mysqli_query($con,$sql);
    if(!$result)die("error".mysqli_error($con));

    $fol=array();
    while($row = mysqli_fetch_array($result)){
        $sql2="SELECT COUNT(*) FROM `clie_reserva_grupál` WHERE folio_extra='".$row["folio_extra"]."' ";
        $result2=mysqli_query($con,$sql2);
        $fol[$row["folio_extra"]]=array($row["folio_extra"],$row['piso'],$row['numero_habitacion'],mysqli_fetch_array($result2)["COUNT(*)"]);
        
    }


    $consultaExtra=mysqli_query($con, 'SELECT * FROM `cargos_folios_habitacion` as carg INNER JOIN servicios as s ON carg.codServicio=s.codServicio;');
    if(!$consultaExtra)die("error".mysqli_error($con,$consultaExtra));
    $extras=array();
    while($row=mysqli_fetch_array($consultaExtra)){
        $extras[]=array($row['idcargoextras'],$row['nombres'],$row['descripcion'],$row['fechacargo'],$row['ico'],$row['totalsinico'],$row['total']);
    }

    $sql=mysqli_query($con,"SELECT * FROM `servicios`");
    if(!$sql)die("error".mysqli_error($con,$sql));

    $servicios=array();
    while($row=mysqli_fetch_array($sql)){
        $servicios[]=array(
            $row['idServicio'],$row['codServicio'],$row['nombres'],$row['valor'],
        );
    }
    

    if(isset($_POST['fechaServicio'])){
        if(isset($_SESSION['folioExtra'])){
            $extra=$_SESSION['folioExtra'];
            $fechaServicio=$_POST['fechaServicio'];
            $descripcionServicio=$_POST['descripcionServicio'];

            $resultado=mysqli_query($con,$sql);
            if(!$resultado)die("error".mysqli_error($con));
        }
        header('Location: foliosGrup.php');
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <style>.dataTables_filter {display: none;}#example_wrapper{width:100%;}</style>

    <title>Document</title>
</head>

<body> 
    <header class="flex">
       <div class="logo">
            <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
            </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
    <div class="container flex">
            <div class="content">
                <div class="" style="display: flex; flex-direction: column; justify-content: space-evenly; height: 100% ">
                    <div style=" height: 100%; padding: 10px;   overflow-y: auto;">
                        <h2 class="form-h2">
                            Folio maestro
                            <input type="text" readonly value="<?php echo $idMaestro?>" id="folioMaestro">
                        </h2>
                        <h2 style="width: 100%; display: flex;justify-content: center;  padding: 25px;">Folios Extras </h2>
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th>N° folio Extra</th>
                                    <th>Habitación</th>
                                    <th>Piso</th>
                                    <th>Personas</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($fol as $value):?>
                                <tr>                                   
                                    <td><?php echo $value[0]?></td>
                                    <td>Habitación: <?php echo $value[1]?></td>
                                    <td><?php echo $value[2]?></td>
                                    <td><?php echo $value[3]?></td>
                                    <td class="tbOpt" extra=<?php echo $value[0]?>>
                                        <?php if($estado!=3):?>
                                        <input type="button" class="bttn btn" value="Ingresar" id="ingresar" onclick="iniModal(1)">
                                        <?php endif;?>
                                        <input type="button" class="bttn btn3" value="Factura" id="factura">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php include("../../includes/modales/folioExtra.php") ?>
    <div class="modalContainer " id="v2"></div>
    <?php include("../../includes/modales/deleteModal.php") ?>
    <?php include("../../includes/modales/nuevoCargo.php") ?>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="../js/table.js"></script>
<script src="../ajaxjs/foliosGRUP.js"></script>
<script src="../../js/modal.js"></script>

<script  src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

<script>$(document).ready(function () {$('#modalTable').DataTable({responsive: true,scrollCollapse: true,paging: false,search:false,});});</script>

<script>$(document).ready(function () {$('#example').DataTable({responsive: true,scrollCollapse: true,paging: false,search:false,});});</script>
</html>