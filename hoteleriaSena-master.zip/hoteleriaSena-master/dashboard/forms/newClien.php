<?php
  include('../../includes/conexion.php');
  session_start();
  if (!isset($_SESSION['tipo'])) {
    header("Location: ../clien.php");
  }
  unset($_SESSION['idCliente']);
  $alert=null;

  $tipo=null;
  $cedula=null;
  $nombres=null;
  $apellidos=null;
  $fechanaci=null;
  $lugar=null;
  $pais=null;
  $ciudad=null;
  $direccion=null;
  $genero=null;
  $correoPer=null;
  $correoCor=null;
  $telefonoFijo=null;
  $telefonoMovil=null;
  $telefonoAuxiliar=null;
  if (isset($_POST['cedula']) && isset($_POST['nombre']) && isset($_POST['apellido'])
    && isset($_POST['fechanaci']) && isset($_POST['lugarNacimiento']) && isset($_POST['pais'])
    && isset($_POST['correoPersonal']) && isset($_POST['telefonoMovil']) 
    && isset($_POST['genero'])) {
        /* Obteniendo valores del formulario */
        $tipo=$_POST['tipoDoc'];
        $cedula=$_POST['cedula'];
        $nombres=$_POST['nombre'];
        $apellidos=$_POST['apellido'];
        $fechanaci=$_POST['fechanaci'];
        $lugar=$_POST['lugarNacimiento'];
        $pais=$_POST['pais'];
        $ciudad=$_POST['ciudadR'];
        $direccion=$_POST['direccion'];
        $genero=$_POST['genero'];
        $correoPer=$_POST['correoPersonal'];
        $correoCor=$_POST['correoCorporativo'];
        $telefonoFijo=$_POST['telefonoFijo'];
        $telefonoMovil=$_POST['telefonoMovil'];
        $telefonoAuxiliar=$_POST['telefonoAux'];

        /* Validacion del tipo de documento */
        if ($tipo!="select") {
            $consulta=mysqli_query($con,"SELECT * FROM clientes WHERE cedula=$cedula");
            if (!$consulta) {
                die("ERROR AL VALIDAR CLIENTE ".mysqli_error($con));
            }
            if (mysqli_num_rows($consulta)>0) {
                $alert="Ya existe un usuario con este numero <i>$cedula</i>";
            } else {
                $sql= "INSERT INTO clientes(tipo,cedula,nombres,apellidos,correo) VALUES('$tipo',$cedula,'$nombres','$apellidos','$correoPer');";
                $result= mysqli_query($con,$sql);
                if (!$result) {
                    die("ERROR AL GUARDAR CLIENTE ".mysqli_error($con));
                }else{
                    $sql2="INSERT INTO `datos_cliente` (`pais`, `fecha_nacimiento`, `lugar_nacimiento`, `ciudad`, `direccion`, `genero`, 
                    `correo_corporativo`, `numero_fijo`, `numero_movil`, `numero_auxiliar`, `cedula`) VALUES 
                    ('$pais', '$fechanaci', '$lugar', '$ciudad', '$direccion', '$genero', '$correoCor', '$telefonoFijo','$telefonoMovil', 
                    '$telefonoAuxiliar', $cedula) ";
                    $result2= mysqli_query($con,$sql2);
                    if (!$result2) {
                        die("ERROR AL GUARDAR DATOS DEL CLIENTE ".mysqli_error($con));
                    }
                    header("Location: ../clien.php");
                }
            }
        }else{
            $alert="Debe seleccionar el tipo de documento";
        }
  }else{

  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Registro de Cliente</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
           <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
           </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
            <div class="content">
                <div class="forms">
                    <form action="" method="POST">
                            <span>Registro de clientes</span>

                            <?php if(isset($alert)):?>
                            <div class="alert">
                                <?php echo $alert;?>
                            </div>
                            <?php endif;?>
                            
                            <?php if(!isset($alert)):?>
                            <div style="color: #000; margin-top: 13px; background-color: #e2e3e5; padding: 8px; border-radius: 5px;">
                                Recuerde que debe llenar los campos obligatorios(*)
                            </div>
                            <?php endif;?>
                            <div class="side">
                                
                                <div class="inputC">
                                    <label for="">Tipo de documento&nbsp;<p class="required">*</p></label>
                                    <select name="tipoDoc" id=""><!-- Obligatorio -->
                                        <option value="select">Tipo de Identificación</option>
                                        <option value="TI" <?php if(isset($tipo)){if($tipo=="TI"){echo 'selected';}}?>>Tarjeta de identidad</option>
                                        <option value="CC" <?php if(isset($tipo)){if($tipo=="CC"){echo 'selected';}}?>>Cédula de ciudadania</option>
                                        <option value="CE" <?php if(isset($tipo)){if($tipo=="CE"){echo 'selected';}}?>>Cedula Extranjera</option>
                                    </select>
                                </div>

                                <div class="inputC">
                                    <label for="">Identificación&nbsp;<p class="required">*</p></label>
                                    <input type="number" placeholder="  " name="cedula" required value="<?php if(isset($cedula)){echo $cedula;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Nombres&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="nombre" required value="<?php if(isset($nombres)){echo $nombres;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Apellidos&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="apellido" required value="<?php if(isset($apellidos)){echo $apellidos;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Fecha de nacimiento&nbsp;<p class="required">*</p></label>
                                    <input type="date" name="fechanaci" required value="<?php if(isset($fechanaci)){echo $fechanaci;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Lugar de nacimiento&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="lugarNacimiento" required value="<?php if(isset($lugar)){echo $lugar;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">País&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="pais" required value="<?php if(isset($pais)){echo $pais;}?>"><!-- Obligatorio -->
                                </div>
                              
                                <div class="inputC">
                                    <label for="">Ciudad de residencia</label>
                                    <input type="text" placeholder="  " name="ciudadR" value="<?php if(isset($ciudad)){echo $ciudad;}?>">
                                </div>

                                <div class="inputC">
                                    <label for="">Dirección de residencia</label>
                                    <input type="text" placeholder="  " name="direccion" value="<?php if(isset($direccion)){echo $direccion;}?>">
                                </div>

                                <div class="inputC">
                                    <label for="">Género&nbsp;<p class="required">*</p></label>
                                    <label for=""><!-- Obligatorio -->
                                        <input type="radio" name="genero" value="masculino" <?php if(isset($genero)){if($genero=="masculino"){echo 'checked';}}?>>Masculino
                                        <input type="radio" name="genero" value="femenino" <?php if(isset($genero)){if($genero=="femenino"){echo 'checked';}}?>>Femenino
                                        <input type="radio" name="genero" value="otro" <?php if(isset($genero)){if($genero=="otro"){echo 'checked';}}?>>Otro
                                    </label>
                                </div>
                                <div class="inputC">
                                    <label for="">Correo personal&nbsp;<p class="required">*</p></label>
                                    <input type="email" placeholder="  " name="correoPersonal" required value="<?php if(isset($correoPer)){echo $correoPer;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Correo corporativo</label>
                                    <input type="email" placeholder="  " name="correoCorporativo" value="<?php if(isset($correoCor)){echo $correoCor;}?>">
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono fijo</label>
                                    <input type="number" placeholder="  " name="telefonoFijo" value="<?php if(isset($telefonoFijo)){echo $telefonoFijo;}?>">
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono móvil&nbsp;<p class="required">*</p></label>
                                    <input type="text" placeholder="  " name="telefonoMovil" required value="<?php if(isset($telefonoMovil)){echo $telefonoMovil;}?>"><!-- Obligatorio -->
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono auxiliar</label>
                                    <input type="text" placeholder="  " name="telefonoAux" value="<?php if(isset($telefonoAuxiliar)){echo $telefonoAuxiliar;}?>">
                                </div>
                            </div>

                            <div class="formFooter">
                                <input type="submit" value="Añadir cliente" class="bttn btn">
                                <a href="../clien.php" class="bttn2 btn2">Cancelar</a>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>