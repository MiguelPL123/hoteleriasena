<?php
    include("../../includes/validacionAccesoDash.php");
    include("../../includes/conexion.php");

    $alerta=null;
    $nombre=null;
    $precio=null;
    $descripcion=null;
    $codigoFolio=$_SESSION['CodeFolio'];

    if(isset($_POST['nombre'])){
        if(isset($_SESSION['CodeFolio'])){
            $codigoFolio=$_SESSION['CodeFolio'];
            $nombre=$_POST['nombre'];
            $precio=$_POST['precio'];
            $descripcion=$_POST['descripcion'];
            
            $sql="INSERT INTO producto(nombre,precio,descripcion,codFolio) VALUES('$nombre','$precio','$descripcion','$codigoFolio')";
            $resultado=mysqli_query($con,$sql);
            if(!$resultado){
                die("ERROR AL INSERTAR NUEVO PRODUCTO".mysqli_error($con));
            }
            header('location: productos.php');           
        }
    }

    //ACTUALIZAR PRODUCTOS
    if(isset($_REQUEST['nombreProd'])){
        $nombreProd=$_POST['nombreProd'];
        $precioProd=$_POST['precioProd'];
        $descProd=$_POST['descProd'];
        $codeProd=$_POST['codeProd'];


        $sql="UPDATE producto SET nombre='$nombreProd', precio='$precioProd', descripcion='$descProd' WHERE idProducto='$codeProd'";
        $result = mysqli_query($con, $sql);
        if(!$result){
            die("ERROR AL ACTUALIZAR PRODUCTOS".mysqli_error($con));
        } 
        header("Location: productos.php");
    }

    //CONSULTAR PRODUCTOS
    $consultaProductos="SELECT * FROM producto WHERE codFolio='$codigoFolio'";
    $result=mysqli_query($con,$consultaProductos);
    if(!$result){
        die("ERROR AL CONSULTA A LA TABLA PRODUCTOS".mysqli_error($con));
    }
    $productos=array();
    while($row = mysqli_fetch_array($result)){
        $productos[]=array($row['nombre'],$row['precio'],$row['descripcion'],$row['idProducto']);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <img src="../../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">

        <div class="container flex">
            <div class="content">
                    <div class="head">
                        <a href="../servicios.php" class="bttn btn3"><span class="material-symbols-outlined">
                        arrow_back
                        </span>Volver</a>
                        <br>

                        <!-- <a href="#" class="bttn">+ Nuevo producto</a> -->
                     

                    </div>
                    <div class="dual">
                    <div class="left minForm">
                 
                            <span>Añadir producto</span>
                       
                       <form method="POST">
                            <label for="">Nombre  </label>
                            <input type="text" name="nombre" placeholder="Nombre  " 
                            value="" required>
                            <label for="">Precio  </label>
                            <input type="number" name="precio" placeholder="Precio  " 
                            value="" required>
                            <label for="">Descripción  </label>
                            <input type="text" name="descripcion" placeholder="Descripción  " 
                            value="" required>


                            <div class="formFooter">
                                <input type="submit" value="+ Añadir " class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2" onclick="quitarImg()">
                            </div>
                        </form>

                    </div>
                    <div class="right">
                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Nombres</th>
                                    <th>Precio</th>
                                    <th>Descripción</th>


                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($productos as $value):?>
                                <tr>
                                    <td><?php echo $value[0]?></td>
                                    <td><?php echo $value[1]?></td>
                                    <td><?php echo $value[2]?></td>
                                    <td class="tbOpt" idProducto="<?php echo $value[3]?>">
                                        <input type="button" class="bttn btn3" value="Editar" id="EditarProducto" onclick="iniModal(1)">
                                        <input type="button" class="bttn btn2" value="Eliminar" id="EliminarProducto" onclick="iniModal(3);">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
        <?php include("../../includes/modales/prod.php") ?>
        <?php include("../../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v3"></div>
        <div class="modalContainer " id="v4"></div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../../js/table.js"></script>
<script src="../ajaxjs/productos.js"></script>
<script src="../../js/modal.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>