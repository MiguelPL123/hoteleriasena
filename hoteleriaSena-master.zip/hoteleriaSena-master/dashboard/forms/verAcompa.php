<?php 
    include('../../includes/conexion.php');

    session_start();

    //Editar Acompañante
    if (isset($_POST['nombreEdit']) && isset($_POST['apellidoEdit']) && isset($_POST['numeroEdit'])) {

        $numero2=$_POST['numeroEdit'];
        $tipoDocumento2=$_POST['tipoEdit2'];
        $nombre2=$_POST['nombreEdit'];
        $apellido2=$_POST['apellidoEdit'];
        if ($tipoDocumento2!="select") {
            $bandera=true;
            if ($_SESSION['cedAcom']!=$numero2) {
                $sql2="SELECT * FROM acompañantes WHERE documento=$numero2";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {
                    die("ERROR AL CONSULTAR ACOM RESERVA".mysqli_error($con));
                }
                if (mysqli_num_rows($result2)>0) {
                    $bandera=false;
                }
            }

            if ($bandera) {
                $insert="UPDATE acompañantes SET `nombre`='$nombre2', `apellido`='$apellido2', `tipoDoc`='$tipoDocumento2', `documento`=$numero2 WHERE documento=".$_SESSION['cedAcom'].";";
                $result2= mysqli_query($con,$insert);
                if (!$result2) {
                    die('ERROR AL ACTUALIZAR ACOMPAÑANTES!'.mysqli_error($con));
                }
                unset($_SESSION['cedAcom']);
            }else{
                $alerta="Lo siento ya existe un numero de registro con ese numero!";    
            }
        }else{
            $alerta="Recuerde que debe seleccionar un tipo de documento!";    
        }
    }

    /* Consultar acompañantes */

    $sql="SELECT * FROM `acompañantes`";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULAT DETALLES DE ACOMPAÑANTES ".mysqli_error($con));
    }
    $acompas=array();

    while ($row = mysqli_fetch_array($result)) {
        $acompas[]=array(
            "tipo"=>$row['tipoDoc'],
            "documento"=>$row['documento'],
            "nombre"=>$row['nombre'],
            "apellido"=>$row['apellido']
        );
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <img src="../../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">

        <div class="container flex">
            <div class="content">
                    <div class="head">
                        <a href="../clien.php" class="bttn btn3"><span class="material-symbols-outlined">
                        arrow_back
                        </span>Volver</a>
                        <br>

                        <!-- <a href="#" class="bttn">+ Nuevo producto</a> -->
                     

                    </div>
                 
                 

                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Tipo Doc</th>
                                    <th>Documento</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($acompas as $key => $value):?>
                                    <tr>
                                        <td><?php echo $value['tipo']?></td>
                                        <td><?php echo $value['documento']?></td>
                                        <td><?php echo $value['nombre']?></td>
                                        <td><?php echo $value['apellido']?></td>
                                        <td class="tbOpt" doc="<?php echo $value['documento']?>">
                                            <input type="button" class="bttn btn3" value="Editar" id="editarAcompa">
                                            <!-- <input type="button" class="bttn btn" value="Detalles" id="mostrarClie" onclick="iniModal(2)"> -->
                                        </td>
                                    </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
            </div>
        </div>
        <?php include("../../includes/modales/acompa.php") ?>
        <?php include("../../includes/modales/deleteModal.php") ?>
        <?php include("../../includes/modales/acompaVer.php") ?>
        <div class="modalContainer " id="v4"></div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../../js/table.js"></script>
<script src="../../js/table.js"></script>
<script src="../../js/modal.js"></script>

<script>
    function limpiarCombo(elemet,selectView){
    
        $(function(){
            //Limpiar el combo box
            let valor= selectView.children;
            for (let i = 0; i < valor.length; i++) {
                let element = valor[i];
                let id= $(element).attr('selected');
                if (id=='selected') {
                    $(element).attr("selected",false);
                }
            }
            if (elemet!=null) {
                $("#"+elemet).attr('selected',true);
            }else{
                $(valor[0]).attr('selected',true);
            }
        })

    }

    $(document).on('click', '#editarAcompa', function(){
        let element = $(this)[0].parentElement;
        let id = $(element).attr('doc');
        $.ajax({
            url:'../ajaxphp/consultarAcompa_ref.php',
            type:'POST',
            data: {search: id},
            success: function(resp){
                try {
                    let json= JSON.parse(resp);
                    $("#"+json.tipo+"2").attr('selected',true);
                    $("#nombreEdit").val(json.nombre);
                    $("#apellidoEdit").val(json.apellido);
                    $("#numeroEdit").val(id);
                    iniModal(1);
                } catch (error) {
                    console.log(resp);
                }
            }
        })
    });

</script>

<!-- <script src="js/modal.js"></script> -->
</html>