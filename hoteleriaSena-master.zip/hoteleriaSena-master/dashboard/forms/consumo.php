<?php
    include("../../includes/validacionAccesoDash.php");
    include("../../includes/conexion.php");

    //INSERT 
    $alerta=null;
    $codReserva=$_SESSION['codigoReserva2'];
    if(isset($_POST['total'])){
        if(isset($_SESSION['codigoReserva2'])){
            $servicio=$_POST['servicio'];
            $cantidad=$_POST['cantidad'];
            $total=$_POST['total'];
    
            if($servicio!="select"){
                $sql3="INSERT INTO consumo(codServicio,	cantidad,precios,codReserva) VALUES('$servicio','$cantidad','$total','$codReserva')";
                $insert=mysqli_query($con,$sql3);
            
                if(!$insert){
                    die("ERROR AL INSERTAR CONSUMO".mysqli_error($con));
                }

                header("Location: consumo.php");
            }else{
                $alerta="FALTARON CAMPOS LLENAR!";
            }
        }
    }
    
    //CONSULTASSS

    /*Consultar Servicios */
    $sql2 = "SELECT * FROM servicios";
    $result2 = mysqli_query($con, $sql2);
    if(!$result2){
        die("ERROR AL CONSULTAR SERVICIOS".mysqli_error($con));
    }
    $servicios=array();
    
    while($row = mysqli_fetch_array($result2)){
        $servicios[]=array($row['codServicio'],$row['nombres']);
    }
    /*Consultar Consumos */
    $sql2 = "SELECT * FROM `consumo` AS c INNER JOIN servicios AS s ON c.codServicio=s.codServicio WHERE codReserva='$codReserva';";
    $result2 = mysqli_query($con, $sql2);
    if(!$result2){
        die("ERROR AL CONSULTAR SERVICIOS".mysqli_error($con));
    }
    $consumos=array();
    
    while($row = mysqli_fetch_array($result2)){
        $consumos[]=array($row['idConsumo'],$row['nombres'],$row['cantidad'],$row['precios']);
    }



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <img src="../../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">

        <div class="container flex">
            <div class="content">
                    <div class="head">
                        <input type="button" class="bttn btn3" value="Volver" onclick="window.location.href='../checkOut.php'">
                        <br>
                    </div>
                    <div class="dual">
                    <div class="left minForm">
                 
                            <span>Registrar consumo</span>
                       
                       <form method="POST">
                            <label for="">Servicios</label>
                            <select name="servicio" id="servicio">
                                <option value="select" id="">Seleccione...</option>
                                <?php foreach($servicios as $value):?>
                                    <option value="<?php echo $value[0]?>" ><?php echo $value[1]?></option>
                                <?php endforeach;?>
                            </select>


                            <label for="">Cantidad</label>
                            <input type="number" placeholder="  " name="cantidad" id="cantidad"
                            value="1" required min=1>

                            <label for="">Precio</label>
                            <input type="number" placeholder="  " name="precio" id="precio"
                            value="1" disabled="disabled">

                            <label for="">Total</label>
                            <input type="number" placeholder="0" name="total" id="total" readonly>

                            <?php if($alerta):?>
                                <div class="alert">
                                    <?php echo $alerta?>
                                </div>
                            <?php endif;?>

                            <div class="formFooter">
                                <input type="submit" value="+ Añadir " class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2">
                            </div>
                        </form>

                    </div>
                    <div class="right">
                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Nombre</th>
                                    <th>Cantidad</th>
                                    <th>Precio</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($consumos as $value):?>
                                <tr>
                                    <td><?php echo $value[1]?></td>
                                    <td><?php echo $value[2]?></td>
                                    <td><?php echo $value[3]?></td>
                                    <td class="tbOpt" idProd="<?php echo $value[0]?>">
                                        <input type="button" class="bttn btn2" value="Eliminar" id="eliminarConsumo" onclick="iniModal(3);">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
        <?php include("../../includes/modales/prod.php") ?>
        <?php include("../../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v3"></div>
        <div class="modalContainer " id="v4"></div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../../js/table.js"></script>
<script src="../ajaxjs/consumo.js"></script>
<script src="../../js/modal.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>