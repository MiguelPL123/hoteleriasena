<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <img src="../../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
            <div class="content">
                <div class="forms">
                    <form action="">
                            <span>Nueva reserva </span>
                            <h2>Información personal</h2>

                            <div class="side">
                                <div class="inputC">
                                    <label for="">Nombres</label>
                                    <input type="text" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">Apellidos</label>
                                    <input type="text" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">País</label>
                                    <input type="text" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">Correo personal</label>
                                    <input type="email" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">Tipo de documento</label>
                                    <select name="" id="" form="">
                                        <option value="Estandar">Cédula de ciudadania</option>
                                        <option value="Suite">Cédula de extranjeria</option>
                                        <option value="Empresarial">Tarjeta de identidad</option>
                                    </select>
                                </div>
                              
                                <div class="inputC">
                                    <label for="">Identificación</label>
                                    <input type="text" placeholder="  ">
                                </div>
                     
                            </div>

                            <h2>Información reserva</h2>
                            <div class="side">
                                <div class="inputC">
                                    <label for="">Tipo de habitación</label>
                                    <select name="" id="" form="">
                                        <option value="Estandar">Superior room</option>
                                        <option value="Suite">Deluxe room</option>
                                        <option value="Empresarial">Guest  house</option>
                                        <option value="Empresarial">Single  room</option>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">Tipo de cama</label>
                                    <select name="" id="" form="">
                                        <option value="Estandar">Single </option>
                                        <option value="Suite">Double</option>
                                        <option value="Empresarial">Triple  </option>
                                        <option value="Empresarial">Quad  </option>
                                        <option value="Empresarial">None  </option>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">Tipo de pago</label>
                                    <select name="" id="" form="">
                                        <option value="Estandar">Efectivo </option>
                                        <option value="Suite">Tarjeta</option>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">¿Es una empresa?  </label>
                                    <select name="" id="" form="">
                                        <option value="Estandar">Si </option>
                                        <option value="Suite">No</option>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">Número de habitaciones</label>
                                    <select name="" id="" form="">
                                        <option value="Empresarial">1  </option>
                                    </select>
                                </div>
                            
                                <div class="inputC">
                                    <label for="">Número de personas</label>
                                    <input type="number">
                                </div>
                                <div class="inputC">
                                    <label for="">Check-in</label>
                                    <input type="date" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">Check-out</label>
                                    <input type="date" placeholder="  ">
                                </div>
                                <div class="inputC">
                                    <label for="">Código de reserva</label>
                                    <input type="text" placeholder="  ">
                                </div>
                             

                            </div>
                           
                         

                            <div class="formFooter">
                                <input type="button" value="Añadir reserva" class="bttn btn">
                                <a href="http://localhost/hoteleriaSena/dashboard/reserva.php" class="bttn2 btn2">Cancelar</a>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>