<?php
    include('../../includes/conexion.php');
    session_start();
    $alert=null;
    /* Datos de clientes */
    $tipo=null;
    $cedula=null;
    $nombre=null;
    $apellido=null;
    $correo=null;
    $pais=null;/* Detalles de cliente */
    $fecha=null;
    $lugar=null;
    $genero=null;
    $correo_corporativo=null;
    $telefono=null;
    $telefono_auxiliar=null;
    /* Datos de reserva */
    $cathabitacion=null;
    $habitacion=null;
    //Datos de empresa
    $empresa=null;
    $nit=null;
    $nombreEmpresa=null;
    $correoEmpresa=null;
    //----------------
    $npersonas=null;
    $tipoPago=null;
    $fechaIn=null;
    $fechaOut=null;
    $codigoReseva=$_SESSION['reservaEdit'];
    $mostrarInformacionReserva=true;

     /* Registrar o actualizar */
     if (
        /* Validaciones de cliente */
        isset($_POST["cedula"]) && isset($_POST["nombre"]) &&  isset($_POST["apellido"])
        &&  isset($_POST["fecha"]) &&  isset($_POST["lugar"]) &&  isset($_POST["pais"])
        &&  isset($_POST["genero"]) &&  isset($_POST["correoPer"]) &&  isset($_POST["telefonoMovil"])
        /* Validaciones de reservas */
        && isset($_POST["npersonas"]) && isset($_POST["fechain"]) && isset($_POST["fechaout"])
    ) {
        /* Datos del cliente */
        $tipo=$_POST['tipo'];/* Tipo de documento */
        $cedula=$_POST['cedula'];
        $nombre=$_POST['nombre'];
        $apellido=$_POST['apellido'];
        $correo=$_POST['correoPer'];
        $pais=$_POST['pais'];/* Detalles de cliente */
        $fecha=$_POST['fecha'];
        $lugar=$_POST['lugar'];
        $genero=$_POST['genero'];
        $correo_corporativo=$_POST['correoCor'];
        $telefono=$_POST['telefonoMovil'];
        $telefono_auxiliar=$_POST['TelefonoAux'];
        if ($tipo!="select") {
            /* Actualizar DATOS DE CLIENTE */
            $sql2="UPDATE datos_cliente SET pais='$pais',fecha_nacimiento='$fecha',lugar_nacimiento='$lugar',
            genero='$genero',correo_corporativo='$correo_corporativo',numero_movil='$telefono',
            numero_auxiliar='$telefono_auxiliar' WHERE cedula=$cedula";
            $update=mysqli_query($con,$sql2);
            if (!$update) {
                die("ERROR AL ACTUALIZAR DATOS DEL CLIENTE");
            }

            /* Actualizar CLIENTE */
            $sql2="UPDATE clientes SET nombres='$nombre',apellidos='$apellido',correo='$correo' WHERE cedula=$cedula";
            $update=mysqli_query($con,$sql2);
            if (!$update) {
                die("ERROR AL ACTUALIZAR CLIENTE");
            }

            /* Guardar datos de reserva */
            $cathabitacion=$_POST['categorias'];
            $habitacion=$_POST['hab'];
            $empresa=$_POST['empresa'];
            $npersonas=$_POST['npersonas'];
            $tipoPago=$_POST['tipopago'];
            $fechaIn=$_POST['fechain'];
            $fechaOut=$_POST['fechaout'];
            $codigoReseva=$_POST['codigores'];/* Codigo para la reserva */
            $nit= $_POST["nit"];
            $nombreEmpresa= $_POST["nombreEmpres"];
            $correoEmpresa= $_POST["correoEmpresa"];

            /* Validacion de si esta seleccionado una habitacion */
            if (($habitacion!="select") && ($empresa!="select") && ($tipoPago!="select")){
                /* Modulo de registro o actualizacion de empresa */
                $banderaEmpresa=true;
                if ($empresa=="si") {
                    if (isset($_POST["nit"]) && isset($_POST["nombreEmpres"])) {

                        /* Verificacion de existencia de empresa */
                        $verifiacionEmpresa=mysqli_query($con,"SELECT * FROM empresa WHERE nit='$nit'");
                        if (!$verifiacionEmpresa) {
                            die("ERROR AL CONSULTAR EXISTENCIA DE EMPRESA ".mysqli_error($con));
                        }
                        if (mysqli_num_rows($verifiacionEmpresa)>0) {
                            $actualizacionEmpresa=mysqli_query($con,"UPDATE empresa SET nombre='$nombreEmpresa',correo='$correoEmpresa' WHERE nit='$nit';");
                            if (!$actualizacionEmpresa) {
                                die("ERROR AL ACTUALIZAR EMPRESA ".mysqli_error($con));
                            }
                        } else {
                            $insertarEmpresa=mysqli_query($con,"INSERT INTO empresa(nit,nombre,correo) VALUES('$nit','$nombreEmpresa','$correoEmpresa')");
                            if (!$insertarEmpresa) {
                                die("ERROR AL REGISTRAR EMPRESA ".mysqli_error($con));
                            }
                        }
                        $banderaEmpresa=true;
                    }else{
                        $banderaEmpresa=false;
                        $mostrarInformacionReserva=false;
                        $alert="Faltan campos por rellenar!";                        
                    }
                }

                /* Modulo de actualiizacion de reserva */
                if ($banderaEmpresa) {
                    $sqlupdateReserva="UPDATE reserva SET tipo_pago='$tipoPago',nit='$nit',idhabitacion=$habitacion,numero_personas=$npersonas,date_in='$fechaIn',date_out='$fechaOut' WHERE cod_reserva='$codigoReseva'";
                    $updateReserva=mysqli_query($con,$sqlupdateReserva);
                    if (!$updateReserva) {
                        die("ERROR AL ACTUALIZAR RESERVA ".mysqli_error($con));
                    }else{
                        /* Actualizar estado de habitacion anterior si es cambiada */
                        $habitacionInicial=$_SESSION['desicionEmpresa'];
                        if ($habitacionInicial!=$habitacion) {
                            /* Actualizar estado habitacion */
                            $sqlupdateHab="UPDATE habitacion SET estado='disponible' WHERE idHabitacion=$habitacionInicial";
                            $updateHab=mysqli_query($con,$sqlupdateHab);
                            if (!$updateHab) {
                                die("ERROR AL ACTUALIZAR ESTADO DE HABITACION EXISTENTE".mysqli_error($con));
                            }    
                        }
                        /* Actualizar estado habitacion */
                        $sqlupdateHab="UPDATE habitacion SET estado='reservado' WHERE idHabitacion=$habitacion";
                        $updateHab=mysqli_query($con,$sqlupdateHab);
                        if (!$updateHab) {
                            die("ERROR AL ACTUALIZAR ESTADO DE HABITACION".mysqli_error($con));
                        }
                        header("Location: ../reserva.php");
                    }
                }


            }else{
                $alert="Faltan campos por rellenar!";
                $mostrarInformacionReserva=false;
            }
            
        }else{
            $alert="Faltan campos por rellenar!";
            $mostrarInformacionReserva=false;
        }


    }

    if ($mostrarInformacionReserva) {
        //Consultar detalles de reserva
        $sqlreserva="SELECT cli.tipo,cli.cedula,cli.nombres,cli.apellidos, dc.fecha_nacimiento,dc.lugar_nacimiento,dc.pais,dc.genero,cli.correo, dc.correo_corporativo,dc.numero_movil,dc.numero_auxiliar, hab.idHabitacion,hab.codHab, r.nit,r.numero_personas,r.tipo_pago,r.date_in,r.date_out FROM `reserva` AS r INNER JOIN clientes AS cli ON r.cedula=cli.cedula inner JOIN datos_cliente AS dc ON dc.cedula=r.cedula INNER JOIN habitacion AS hab ON r.idhabitacion=hab.idHabitacion WHERE r.cod_reserva='$codigoReseva'";
        $result=mysqli_query($con,$sqlreserva);
        if (!$result) {
            die("ERROR AL CONSULTAR DETALLES".mysqli_error($con));
        }
        while ($row = mysqli_fetch_array($result)) {
            /* Datos personales */
            $tipo=$row['tipo'];
            $cedula=$row['cedula'];
            $_SESSION["cedulClie"]=$cedula;/* Session de cedula del cliente */
            $nombre=$row['nombres'];
            $apellido=$row['apellidos'];
            $fecha=$row['fecha_nacimiento'];
            $lugar=$row['lugar_nacimiento'];
            $pais=$row['pais'];
            $genero=$row['genero'];
            $correo=$row['correo'];
            $correo_corporativo=$row['correo_corporativo'];
            $telefono=$row['numero_movil'];
            $telefono_auxiliar=$row['numero_auxiliar'];
            /* Datos de habitacion */
            $habitacion=$row['idHabitacion'];
            if (isset($habitacion) ){
                $_SESSION['desicionEmpresa']=$habitacion;/* Sesion de desicion de empresa */
            }
            $cathabitacion=$row['codHab'];
            $empresa="no";
            if ($row['nit']!=null) {
                $empresa="si";
                $nit=$row['nit'];
                $sqlEmpresa=mysqli_query($con,"SELECT * FROM empresa WHERE nit='$nit'");
                if (!$sqlEmpresa) {
                    die("ERROR AL CONSULTAR DATOS DE EMPRESA".mysqli_error($con));
                }
                while ($row2 = mysqli_fetch_array($sqlEmpresa)) {
                    $nombreEmpresa=$row2['nombre'];
                    $correoEmpresa=$row2['correo'];
                }
                /* Consultar datos de empresa */
            }
            $npersonas=$row['numero_personas'];
            $tipoPago=$row['tipo_pago'];
            $fechaIn=$row['date_in'];
            $fechaOut=$row['date_out'];
        }
    }

    /* Consultar  categorias de las habitaciones*/
    $categoriasHab=array();

    $sql= "SELECT chab.codHab,chab.categoria FROM `categorias_habitaciones` AS chab;";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR CATEGORIAS DE LAS HABITACIONES".mysqli_error($con));
    }

    while ($row = mysqli_fetch_array($result)) {
        $categoriasHab[]= array(
            "cod"=>$row['codHab'],
            "nombre"=>$row['categoria']
        );
    }

    /* Consultar habitaciones */
    $habitacionSql=array();

    $sql= "SELECT * FROM `habitacion`;";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR HABITACIONES".mysqli_error($con));
    }

    while ($row = mysqli_fetch_array($result)) {
        $habitacionSql[]= array(
            "id"=>$row['idHabitacion'],
            "habitacion"=>"Habitacion ".$row['numero_habitacion']." - Piso ".$row['piso']
        );
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
            </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
            <div class="content">
                <div class="forms">
                    <form action="" method="POST">
                            <!-- Datos personales -->
                            <span>Nueva reserva </span>
                            <h2>Información personal</h2>

                            <?php if(isset($alert)):?>
                            <div class="alert">
                                <?php echo $alert;?>
                            </div>
                            <?php endif;?>

                            <div class="side">
                                <div class="inputC">
                                    <label for="">Tipo de documento</label>
                                    <select name="tipo" id="tipoDoc">
                                        <option value="select" id="select">Seleccione</option>
                                        <option value="TI" id="TI" <?php if(isset($tipo)) if($tipo=="TI") echo 'selected';?>>Tarjeta de identidad</option>
                                        <option value="CC" id="CC" <?php if(isset($tipo)) if($tipo=="CC") echo 'selected';?>>Cédula de ciudadania</option>
                                        <option value="CE" id="CE" <?php if(isset($tipo)) if($tipo=="CE") echo 'selected';?>>Cédula de extranjera</option>
                                    </select>
                                </div>
                              
                                <div class="inputC">
                                    <label for="">Identificación</label>
                                    <input type="text" placeholder="  " id="cedula" name="cedula" value="<?php if(isset($cedula)) echo $cedula;?>" readonly>
                                </div>

                                <div class="inputC">
                                    <label for="">Nombres</label>
                                    <input type="text" placeholder="  " id="nombre" name="nombre" value="<?php if(isset($nombre)) echo $nombre;?>" required>
                                </div>

                                <div class="inputC">
                                    <label for="">Apellidos</label>
                                    <input type="text" placeholder="  " id="apellido" name="apellido" value="<?php if(isset($apellido)) echo $apellido;?>" required>
                                </div>

                                <div class="inputC">
                                    <label for="">Fecha de nacimiento</label>
                                    <input type="date" placeholder="  " id="fecha" name="fecha" value="<?php if(isset($fecha)) echo $fecha;?>"required>
                                </div>

                                <div class="inputC">
                                    <label for="">Lugar de nacimiento</label>
                                    <input type="text" placeholder="  " id="lugar" name="lugar" value="<?php if(isset($lugar)) echo $lugar;?>">
                                </div>

                                <div class="inputC">
                                    <label for="">País</label>
                                    <input type="text" placeholder="  " id="pais" name="pais" required value="<?php if(isset($pais)) echo $pais;?>">
                                </div>
                                <div class="inputC">
                                    <label for="">Género</label>
                                    <label for="">
                                        <input type="radio" name="genero" id="masculino" value="masculino" <?php if(isset($genero)) if($genero=="masculino") echo 'checked';?>>Masculino
                                        <input type="radio" name="genero" id="femenino" value="femenino" <?php if(isset($genero)) if($genero=="femenino") echo 'checked';?>>Femenino
                                        <input type="radio" name="genero" id="otros" value="otro" <?php if(isset($genero)) if($genero=="otro") echo 'checked';?>>Otro
                                    </label>
                                </div>
                                <div class="inputC">
                                    <label for="">Correo personal</label>
                                    <input type="email" placeholder="  " id="correoPer" name="correoPer"  value="<?php if(isset($correo)) echo $correo;?>" required>
                                </div>
                                <div class="inputC">
                                    <label for="">Correo corporativo</label>
                                    <input type="text" placeholder="  " id="correoCor" name="correoCor" value="<?php if(isset($correo_corporativo)) echo $correo_corporativo;?>">
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono móvil</label>
                                    <input type="text" placeholder="  " id="telefonoMovil" name="telefonoMovil" value="<?php if(isset($telefono)) echo $telefono;?>" required>
                                </div>
                                <div class="inputC">
                                    <label for="">Telefono auxiliar</label>
                                    <input type="text" placeholder="  " id="TelefonoAux" name="TelefonoAux" value="<?php if(isset($telefono_auxiliar)) echo $telefono_auxiliar;?>">
                                </div>
                            </div>
                            <!-- Informacion de reserva -->
                            <h2>Información reserva</h2>
                            <div class="side">
                                <div class="inputC">
                                    <label for="">Categoria de habitación</label>
                                    <select name="categorias" id="categorias">
                                       <option value="select">Seleccione</option>
                                        <?php foreach($categoriasHab as $value):?>
                                        <option 
                                            value="<?php echo $value['cod']?>" 
                                            id="<?php echo $value['cod']?>"
                                            <?php if(isset($cathabitacion)) if ($cathabitacion==$value['cod']) echo 'selected';?>
                                        >
                                         <?php echo $value['nombre']?>
                                        </option>
                                        <?php endforeach;?>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">Habitaciones</label>
                                    <select name="hab" id="habitaciones">
                                        <option value="select">Seleccione</option>
                                        <?php
                                            if(isset($cathabitacion)):
                                            foreach($habitacionSql as $value):?>
                                            <option value="<?php echo $value['id'];?>" <?php if(isset($habitacion)) if($habitacion==$value['id']) echo 'selected';?>><?php echo $value['habitacion'];?></option>
                                        <?php endforeach;
                                            endif;?>
                                    </select>
                                </div>
                                <div class="inputC">
                                    <label for="">¿Es una empresa? </label>
                                    <select name="empresa" id="desicionEmpresa">
                                        <option value="select">Seleccione</option>
                                        <option value="si" <?php if(isset($empresa)) if($empresa=="si") echo 'selected';?>>Si</option>
                                        <option value="no" <?php if(isset($empresa)) if($empresa=="no") echo 'selected';?>>No</option>
                                    </select>
                                </div>
                                <div class="inputC empresaContainer1" style="<?php if(isset($empresa)){if($empresa=="si"){echo "display: flex";}else{echo "display: none";}}else{echo "display: none";}?>">
                                    <label for="">Nit</label>
                                    <input type="text" placeholder=" " name="nit" value="<?php if(isset($nit)) echo $nit;?>" id="nit">
                                </div>
                                <div class="inputC empresaContainer2" style="<?php if(isset($empresa)){if($empresa=="si"){echo "display: flex";}else{echo "display: none";}}else{echo "display: none";}?>">
                                    <label for="">nombre</label>
                                    <input type="text" placeholder="  " name="nombreEmpres" id="nombreEmpres" value="<?php if(isset($nombreEmpresa)) echo $nombreEmpresa;?>">
                                </div>
                                <div class="inputC empresaContainer3" style="<?php if(isset($empresa)){if($empresa=="si"){echo "display: flex";}else{echo "display: none";}}else{echo "display: none";}?>">
                                    <label for="">correo de contacto</label>
                                    <input type="email" placeholder="  " name="correoEmpresa" id="correoEmpresa" value="<?php if(isset($correoEmpresa)) echo $correoEmpresa;?>">
                                </div>
                                <div class="inputC">
                                    <label for="">Número de personas</label>
                                    <input type="number" name="npersonas" value="<?php if(isset($npersonas)) echo $npersonas;?>" required>
                                </div>
                                <div class="inputC">
                                    <label for="">Tipo de pago</label>
                                    <select name="tipopago" id="">
                                        <option value="select" >Seleccione</option>
                                        <option value="efectivo" <?php if(isset($tipoPago)) if($tipoPago=="efectivo") echo 'selected';?>>Efectivo </option>
                                        <option value="tarjeta"  <?php if(isset($tipoPago)) if($tipoPago=="tarjeta") echo 'selected';?>>Tarjeta</option>
                                    </select>
                                </div>

                                <div class="inputC">
                                    <label for="">Check-in</label>
                                    <input type="date" placeholder="  " name="fechain" value="<?php if(isset($fechaIn)) echo $fechaIn;?>"required>
                                </div>
                                <div class="inputC">
                                    <label for="">Check-out</label>
                                    <input type="date" placeholder="  " name="fechaout" value="<?php if(isset($fechaOut)) echo $fechaOut;?>" required>
                                </div>
                                <div class="inputC">
                                    <label for="">Código de reserva</label>
                                    <input type="text" placeholder="  " name="codigores"  value="<?php if(isset($codigoReseva)){echo $codigoReseva;}?>" readonly>
                                </div>
                             

                            </div>
                           
                         

                            <div class="formFooter">
                                <input type="submit" value="Añadir reserva" class="bttn btn">
                                <a href="http://localhost/hoteleriaSena/dashboard/reserva.php" class="bttn2 btn2">Cancelar</a>
                                <input type="reset" value="Restablecer Valores" class="bttn btn" onclick="location.reload()">
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="../ajaxjs/reserva.js"></script>

<!-- <script src="js/modal.js"></script> -->
</html>