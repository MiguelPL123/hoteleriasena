<?php

    include('../../includes/conexion.php');
    session_start();

    $folio=$_SESSION['idMaster'];
    $estado=$_SESSION['estado'];

    $sql="SELECT * FROM `folios_extra` AS fe INNER JOIN habitacion AS h ON fe.idHabitacion=h.idHabitacion WHERE folio_maestro='$folio'";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR INFORMACION DE FOLIOS EXTRAS".mysqli_error($con));
    }
    $detalles_personas_reserva=array();

    while ($row = mysqli_fetch_array($result)) {
        $folioextra=$row['folio_extra'];
        $habitacion="habitacion ".$row['numero_habitacion'];
        $sql2="SELECT cg.cedula,c.nombres,c.apellidos,cg.fecha_llegada FROM `clie_reserva_grupál` AS cg INNER JOIN clientes AS c ON cg.cedula=c.cedula WHERE folio_extra='$folioextra';";
        $result2=mysqli_query($con,$sql2);
        if (!$result) {
            die("ERROR AL CONSULTAR INFORMACION DE PERSONAS".mysqli_error($con));
        }
        while ($row2 = mysqli_fetch_array($result2)) {
            if($row2['fecha_llegada']==null){
                $detalles_personas_reserva[]=array(
                    "folioe"=> null,
                    "cedula"=> $row2['cedula'],
                    "nombres"=> $row2['nombres'],
                    "apellidos"=> $row2['apellidos'],
                    "habitacion"=> $habitacion,
                    "fecha_llegada"=> $row2['fecha_llegada'],
                    
                );
            }else{
                $detalles_personas_reserva[]=array(
                    "folioe"=> $folioextra,
                    "cedula"=> $row2['cedula'],
                    "nombres"=> $row2['nombres'],
                    "apellidos"=> $row2['apellidos'],
                    "habitacion"=> $habitacion,
                    "fecha_llegada"=> $row2['fecha_llegada'],
                );
            }
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">

    <title>Document</title>
</head>

<body> 
    <header class="flex">
       <div class="logo">
            <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
            </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
    <div class="container flex">
            <div class="content">
                <div class="" style="display: flex; flex-direction: column; justify-content: space-evenly; height: 100% ">
                    <div style=" height: 100%; padding: 10px;   overflow-y: auto;">
                        <h2 class="form-h2">
                            Folio Maestro:
                            <input type="text" id="folioMaestro" style="text-align:center; font-size: 20px;" value="<?php echo $folio;?>" readonly>
                        </h2>
                        <h2 style="width: 100%; display: flex;justify-content: center;  padding: 25px;">Registro de Personas</h2>
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th>N° folio Extra</th>
                                    <th>Cedula</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th>Habitaciones Asignadas</th>
                                    <th>Fecha Llegada</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($detalles_personas_reserva as $key => $value):?>
                                <tr>                                   
                                    <td><?php echo $value['folioe'];?></td>
                                    <td><?php echo $value['cedula'];?></td>
                                    <td><?php echo $value['nombres'];?></td>
                                    <td><?php echo $value['apellidos'];?></td>
                                    <td><?php echo $value['habitacion'];?></td>
                                    <td><?php echo $value['fecha_llegada'];?></td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    <?php include("../../includes/modales/folioExtra.php") ?>
    <div class="modalContainer " id="v2"></div>
    <?php include("../../includes/modales/deleteModal.php") ?>
    <?php include("../../includes/modales/nuevoCargo.php") ?>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="../js/table.js"></script>

<script src="../../js/modal.js"></script>

<script  src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>

<script>$(document).ready(function () {$('#modalTable').DataTable({responsive: true,scrollCollapse: true,paging: false,search:false,});});</script>

<script>$(document).ready(function () {$('#example').DataTable({responsive: true,scrollCollapse: true,paging: true,search:true,});});</script>
</html>