<?php
    include("../../includes/validacionAccesoDash.php");
    include("../../includes/conexion.php");
    


    if(isset($_REQUEST['fechaout'])){
        if(isset($_SESSION['reservaCode'])){
            $fechaout=$_POST['fechaout'];
            $reservaCodigo=$_SESSION['reservaCode'];

            $actualizar="UPDATE reserva SET date_out='$fechaout',fechaModificacion= CURRENT_DATE() WHERE cod_reserva='$reservaCodigo'";
            $qery=mysqli_query($con,$actualizar);

            if(!$qery){
                die("ERROR AL EDITAR CHECKOUT".mysqli_error($con));
            }
            header("Location: checkOut.php");
        }
    }
    
    if(isset($_SESSION['reservaCode'])){
        unset($_SESSION['reservaCode']);
    }



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../../includes/dashNavTop__cap.php") ?><!-- Barra de navegacion en la parte superior -->

    <main class="flex">
        <div class="container flex">
            <div class="content ">
            
            <div class="dual">
                    <div class="left minForm">
                 
                        <span>Consumo  de habitacion</span>
                       
                       <form method="POST" enctype="multipart/form-data" class="form__display">
                            <div class="form__top">
                                <select name="" id="">
                                    <option value="">Seleccione....</option>
                                </select>
                                <input type="number" name="precio" placeholder="Precio">

                                <?php if(isset($alerta)):?>
                                <div class="alert">
                                    <p><?php echo $alerta;?></p>
                                </div>
                                <?php endif;?>
                            </div>
                       
                            <div class="formFooter">
                                <input type="submit" value="Agregar" class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2" onclick="quitarImg()">
                            </div>
                        </form>

                    </div>
                    <div class="right">
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th class="tbId">#</th>
                                    <th>Servicio/Punto de venta</th>
                                    <th>Precio</th>
                                    <th>IVA</th>
                                    <th>Precio Total</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>356fr</td>
                                    <td>Restaurante</td>
                                    <td>25000</td>
                                    <td>19%</td>
                                    <td>
                                       30000
                                     </td>
                                    <td class="tbOpt">
                                        <!-- <input type="button" class="bttn btn" value="Editar" id="EditCategoria" onclick="iniModal(1)"> -->
                                        <input type="button" class="bttn btn2" value="Eliminar" id="DeleteCategoria"onclick="iniModal(3)">
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
                
        <?php include("../../includes/modales/folioPerso.php") ?>
        <div class="modalContainer " id="v2"></div>
        <?php include("../../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v4"></div>



    </main>
</body>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>
    
    <script src="ajaxjs/checkout.js"></script>
    <script src="../../js/table.js"></script>
    <script src="../../js/modal.js"></script>
</html>