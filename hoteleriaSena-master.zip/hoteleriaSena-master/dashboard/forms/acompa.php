<?php
    include('../../includes/conexion.php');

    session_start();
    $codigoReserva=$_SESSION['code'];

    $alerta=null;
    
    $numero=null;
    $tipoDocumento=null;
    $nombre=null;
    $apellido=null;

    //Registra Acompañante
    if (isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['numero'])) {

        $numero=$_POST['numero'];
        $tipoDocumento=$_POST['tipoEdit'];
        $nombre=$_POST['nombre'];
        $apellido=$_POST['apellido'];

        if ($tipoDocumento!="select") {

            $sql="SELECT * FROM acompañantes WHERE documento=$numero";
            $result= mysqli_query($con,$sql);
            if (!$result) {
                die('ERROR AL CONSULTAR ACOMPAÑANTES!'.mysqli_error($con));
            }
            if (mysqli_num_rows($result)>0) {
                $sql2="SELECT * FROM acom_reserva WHERE documento=$numero AND codReserva='$codigoReserva'";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {
                    die("ERROR AL CONSULTAR ACOM RESERVA".mysqli_error($con));
                }
                if (mysqli_num_rows($result2)>0) {
                    $alerta="Ya este acompañante ha sido registrado!";
                } else {
                    $insert2="INSERT INTO acom_reserva(`documento`, `codReserva`) VALUES($numero,'$codigoReserva');";
                    $result2= mysqli_query($con,$insert2);
                    if (!$result2) {
                        die('ERROR AL REGISTRAR ACOMPAÑANTES y RESERVAS!'.mysqli_error($con));
                    }
                    header("Location: acompa.php");
                }
                
            } else {
                $insert="INSERT INTO acompañantes(`nombre`, `apellido`, `tipoDoc`, `documento`) VALUES('$nombre','$apellido','$tipoDocumento',$numero);";
                $result2= mysqli_query($con,$insert);
                if (!$result2) {
                    die('ERROR AL REGISTRAR ACOMPAÑANTES!'.mysqli_error($con));
                }

                $insert2="INSERT INTO acom_reserva(`documento`, `codReserva`) VALUES($numero,'$codigoReserva');";
                $result2= mysqli_query($con,$insert2);
                if (!$result2) {
                    die('ERROR AL REGISTRAR ACOMPAÑANTES y RESERVAS!'.mysqli_error($con));
                }
                header("Location: acompa.php");
            }
        }else{
            $alerta="Debe seleccionar un tipo de documento!";    
        }
    }

    //Editar Acompañante
    if (isset($_POST['nombreEdit']) && isset($_POST['apellidoEdit']) && isset($_POST['numeroEdit'])) {

        $numero2=$_POST['numeroEdit'];
        $tipoDocumento2=$_POST['tipoEdit2'];
        $nombre2=$_POST['nombreEdit'];
        $apellido2=$_POST['apellidoEdit'];
        if ($tipoDocumento2!="select") {
            $bandera=true;
            if ($_SESSION['cedAcom']!=$numero2) {
                $sql2="SELECT * FROM acompañantes WHERE documento=$numero2";
                $result2=mysqli_query($con,$sql2);
                if (!$result2) {
                    die("ERROR AL CONSULTAR ACOM RESERVA".mysqli_error($con));
                }
                if (mysqli_num_rows($result2)>0) {
                    $bandera=false;
                }
            }

            if ($bandera) {
                $insert="UPDATE acompañantes SET `nombre`='$nombre2', `apellido`='$apellido2', `tipoDoc`='$tipoDocumento2', `documento`=$numero2 WHERE documento=".$_SESSION['cedAcom'].";";
                $result2= mysqli_query($con,$insert);
                if (!$result2) {
                    die('ERROR AL ACTUALIZAR ACOMPAÑANTES!'.mysqli_error($con));
                }

                $insert2="UPDATE acom_reserva SET `documento`=$numero2 WHERE documento=".$_SESSION['cedAcom']." AND codReserva='$codigoReserva'";
                $result2= mysqli_query($con,$insert2);
                if (!$result2) {
                    die('ERROR AL REGISTRAR ACOMPAÑANTES y RESERVAS!'.mysqli_error($con));
                }
                unset($_SESSION['cedAcom']);
            }else{
                $alerta="Lo siento ya existe un numero de registro con ese numero!";    
            }
        }else{
            $alerta="Recuerde que debe seleccionar un tipo de documento!";    
        }
    }

    /* Consultar acompañantes */

    $sql="SELECT a.tipoDoc,a.documento,a.nombre,a.apellido FROM `acom_reserva` AS ar INNER JOIN acompañantes AS a ON ar.documento=a.documento WHERE ar.codReserva='$codigoReserva';";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULAT DETALLES DE ACOMPAÑANTES ".mysqli_error($con));
    }
    
    $acompas=array();

    while ($row = mysqli_fetch_array($result)) {
        $acompas[]=array(
            "tipo"=>$row['tipoDoc'],
            "documento"=>$row['documento'],
            "nombre"=>$row['nombre'],
            "apellido"=>$row['apellido']
        );
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <img src="../../images/senablanco.png" alt="">
            <h2>Hoteleria y turismo SENA</h2>
       </div>
    </header>
    <main class="flex">

        <div class="container flex">
            <div class="content">
                    <div class="head">
                        <?php if(isset($alerta)):?>
                            <div class="alert">
                                <?php echo $alerta;?>
                            </div>
                        <?php endif;?>
                        <br>                     
                    </div>
                    <div class="dual">
                    <div class="left minForm">
                 
                            <span>Registrar acompañante</span>
                       
                        <form action="" method="post">

                            <label for="">Número de documento</label>
                            <input type="number" placeholder="número" name="numero" id="numero" value="<?php if(isset($numero)) echo $numero?>" required>

                            <label for="">Tipo de documneto</label>

                            <select name="tipoEdit" id="tipoDoc">
                                <option value="select" id="select">Seleccione</option>
                                <option value="TI" id="TI" <?php if(isset($tipoDocumento)) if($tipoDocumento=="TI") echo 'selected';?>>Tarjeta de identidad</option>
                                <option value="CC" id="CC" <?php if(isset($tipoDocumento)) if($tipoDocumento=="CC") echo 'selected';?>>Cédula de Ciudadania</option>
                                <option value="CE" id="CE" <?php if(isset($tipoDocumento)) if($tipoDocumento=="CE") echo 'selected';?>>Cédula de extranjería</option>
                            </select>

                            <label for="">Nombres del acompañante</label>
                            <input type="text" placeholder="Nombres" name="nombre" value="<?php if(isset($nombre)) echo $nombre?>" id="nombre" required>

                            <label for="">Apellidos del acompañante</label>
                            <input type="text" placeholder="Apellidos" name="apellido" value="<?php if(isset($apellido)) echo $apellido?>" id="apellido" required>

                            <div class="formFooter">
                                <input type="submit" value="+ Añadir " class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2" onclick="location.reload()">
                            </div>
                        </form>

                    </div>
                    <div class="right">
                        <table id="example" class="display" style="width:100%">
                            <thead>
                                <tr>
                                    <th>Tipo Doc</th>
                                    <th>Documento</th>
                                    <th>Nombre</th>
                                    <th>Apellido</th>
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($acompas as $key => $value):?>
                                <tr>
                                    <td><?php echo $value['tipo']?></td>
                                    <td><?php echo $value['documento']?></td>
                                    <td><?php echo $value['nombre']?></td>
                                    <td><?php echo $value['apellido']?></td>
                                    <td class="tbOpt" doc="<?php echo $value['documento']?>">
                                        <input type="button" class="bttn btn3" value="Editar" id="editAcompa">
                                        <input type="button" class="bttn btn2" value="Eliminar" id="deleteAcompa">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
        <?php include("../../includes/modales/acompa.php") ?>
        <?php include("../../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v3"></div>
        <div class="modalContainer " id="v4"></div>
    </main>
</body>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../../js/table.js"></script>
<script src="../../js/table.js"></script>
<script src="../../js/modal.js"></script>
<script src="../ajaxjs/acompa.js"></script>

</html>