<?php
    include('../../includes/conexion.php');
    session_start();
    /* $_SESSION['registrosClientes'][155616]["habitacion-asignada"]=null; */ //Eliminar campo habitacion
    /* foreach ($_SESSION['registrosClientes'] as $key => $value) {
        $_SESSION['registrosClientes'][$value["cedula"]]["habitacion-asignada"]=null;;
    } */
    /* unset($_SESSION['habclie']); */
    /* unset($_SESSION['registrosClientes']["select"]); */
    /* var_dump($_SESSION['registrosClientes']);select */

    //Consultar Habitaciones
    $sql = "SELECT ca.categoria, ca.imagen, h.precio, h.numero_habitacion,h.idHabitacion, h.estado, h.piso, h.descripcion,h.idHabitacion FROM `habitacion` AS h 
            INNER JOIN categorias_habitaciones AS ca ON ca.codHab=h.codHab WHERE h.estado='disponible' 
            ORDER BY ca.categoria ASC;";  
    $result=mysqli_query($con, $sql);
    if(!$result){die("ERROR AL CONSULTAR CATEGORIA CON HABITACIONES".mysqli_error($con));}
  
    $habitaciones=array();
    while($row=mysqli_fetch_array($result)){
        $habitaciones[]=array($row['categoria'],$row['numero_habitacion'],$row['piso'],$row['precio'],$row['estado'],$row['idHabitacion']);
    }
    
    //Clientes Registrados
    $personas=$_SESSION['registrosClientes'];
    //Crear Diccionario de habitaciones
    $sql="SELECT * FROM habitacion";
    $result=mysqli_query($con,$sql);
    if(!$result){die("ERROR AL CONSULTAR HABITACIONES".mysqli_error($con));}
    $dicthabitaciones=array();
    while ($row = mysqli_fetch_array($result)) {
        $dicthabitaciones[$row['idHabitacion']]=$row['numero_habitacion'];
    }
    /* var_dump($_SESSION['registrosClientes']); */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.css">
    <style>.dataTables_filter {display: none;}#example_wrapper{width:100%;}</style>
    <title>Document</title>
</head>
<body> 
    <header class="flex">
       <div class="logo">
            <a href="../../home.php">
               <img src="../../images/senablanco.png" alt="">
            </a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../../includes/logout.php">
           
                <span>Cerrar sesión</span>
            </a>
        </div>
    </header>
    <main class="flex">
        <div class="container flex">
        <div class="content">
            <div class="" style="display: flex; flex-direction: column; justify-content: space-evenly; height: 100% ">
                    <div style=" height: 50%; padding: 10px;   overflow-y: auto;">
                        <h2 style="width: 100%; display: flex;justify-content: center;  padding: 25px;">Habitaciones del registro</h2>
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th>Categoria</th>
                                    <th>Habitacion</th>
                                    <th>Piso</th>
                                    <th>Precio</th>
                                    <th>Estado</th>
                                    <!-- <th>Descripción</th> -->
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                         
                            <?php foreach($habitaciones as $value):?>
                                <tr idhab='<?php echo $value[5]?>' nombre="<?php echo $value[1]?>">                                   
                                    <td><?php echo $value[0]?></td>
                                    <td>Habitacion &nbsp;<?php echo $value[1]?></td>
                                    <td><?php echo $value[2]?></td>
                                    <td><?php echo $value[3]?></td>
                                    <td><?php echo $value[4]?></td>
                                    <td class="tbOpt">
                                        <input type="button" class="bttn btn ingresarhab" value="Ingresar">
                                    </td>
                                </tr>
                            <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                    <div style=" height: 50%; padding: 10px;   overflow-y: auto;">
                        <h2 style="width: 100%; display: flex;justify-content: center; padding: 25px;">Usuarios del registro</h2>
                        <table id="example2" class="display" >
                            <thead>
                                <tr>
                                    <th>Identificación</th>
                                    <th>Nombres</th>
                                    <th>Apellidos</th>
                                    <th>Habitacion</th>
                                    <!-- <th>Descripción</th> -->
                                    <!-- <th class="opt">Acción</th> -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($personas as $value):?>
                                <tr>
                                    <td><?php echo $value["cedula"]?></td>
                                    <td><?php echo $value["nombre"]?></td>
                                    <td><?php echo $value["apellido"]?></td>
                                    <td><?php if($value["habitacion-asignada"]!=null) echo  "Habitacion ".$dicthabitaciones[$value["habitacion-asignada"]];?></td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
                    <center><button class="bttn bttn4" id="finalizacion">Finalizar Reservacion</button></button></center>
                </div>
            </div>
        </div>
    <?php include("../../includes/modales/grupPerso.php") ?>
    <div class="modalContainer " id="v2"></div>
    <?php include("../../includes/modales/deleteModal.php") ?>
    <div class="modalContainer " id="v4"></div>
    </main>
</body>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="../js/table.js"></script>
<script src="../ajaxjs/reserva.js"></script>
<script src="../ajaxjs/reservaGrup.js"></script>
<script src="../../js/modal.js"></script>
<script  src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.js"></script>
<script>$(document).ready(function () {$('#example').DataTable({});});</script>
<script>$(document).ready(function () {$('#example2').DataTable({});});</script>
</html>
Contraer

