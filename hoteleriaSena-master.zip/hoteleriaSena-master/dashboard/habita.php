<?php
include("../includes/conexion.php");
include("../includes/validacionAccesoDash.php");

$alerta=null;

$habitacion=null;
$categoriaE=null;
$estado = null;
$precio = null;
$piso = null; 
$descripcion = null;


if(isset($_POST['habitacion'])){
    $habitacion=$_POST['habitacion'];
    $categoriaE=$_POST['categ'];
    $estado = $_POST['estado'];
    $precio = $_POST['precio'];
    $piso = $_POST['piso']; 
    $descripcion = $_POST['descripcion'];

    if($categoriaE!="seleccione"){
        if($estado!="seleccione"){

            $verificar = "SELECT * FROM habitacion WHERE numero_habitacion=$habitacion";
            $buscar = mysqli_query($con,$verificar);
            if(!$buscar){
                die("ERROR AL BUSCAR HABITACION".mysqli_error($con));
            }else{
                if(mysqli_num_rows($buscar)>0){
                    $alerta="ESTA HABITACION YA EXISTE";
                }else{
                    $sql = "INSERT INTO habitacion(numero_habitacion,piso,precio,estado,descripcion,codHab) VALUES($habitacion,$piso,$precio,'$estado','$descripcion','$categoriaE');";
                    $result = mysqli_query($con, $sql);
    
                    if(!$result){
                        die("ERROR AL GUARDAR HABITACION".mysqli_error($con));
                    }
    
                    header("Location: habita.php");
                }
            }            
        }else{
            $alerta="SELECCIONE EL ESTADO";
        }
    }else{
        $alerta="SELECCIONE UNA CATEGORIA";
    }

}

//EDITAR HABITACIONES

if(isset($_POST['habitacion1'])){
    if(isset($_SESSION['idHabitacion'])){
        $habitacion = $_POST['habitacion1'];
        $temporal=$_SESSION['numeroHabitacion'];
        
        $piso = $_POST['piso1'];
        $precio = $_POST['precio1'];
        $categoria = $_POST['categoria1'];
        $estado = $_POST['estado1'];
        $descripcion = $_POST['descripcion1'];

        $id = $_SESSION['idHabitacion'];     

        if($habitacion!=$temporal){
            $verificar = "SELECT * FROM habitacion WHERE numero_habitacion=$habitacion";
            $buscar = mysqli_query($con,$verificar);
            if(!$buscar){
                die("ERROR AL BUSCAR HABITACION".mysqli_error($con));
            }else{
                if(mysqli_num_rows($buscar)>0){
                    echo "YA EXISTE UNA HABITACION CON ESTE NUMERO";
                }else{
                    $sql="UPDATE habitacion SET numero_habitacion='$habitacion', piso='$piso', precio='$precio', estado='$estado', descripcion='$descripcion', codHab='$categoria' WHERE idHabitacion=$id";
                    $result = mysqli_query($con, $sql);
                    if(!$result){
                        die("ERROR AL ACTUALIZAR HABITACION".mysqli_error($con));
                    } 
                    header("Location: habita.php");
                }
            }
        }else{
            $sql="UPDATE habitacion SET numero_habitacion='$habitacion', piso='$piso', precio='$precio', estado='$estado', descripcion='$descripcion', codHab='$categoria' WHERE idHabitacion=$id";
            $result = mysqli_query($con, $sql);
            if(!$result){
                die("ERROR AL ACTUALIZAR HABITACION".mysqli_error($con));
            } 
            header("Location: habita.php");
        }
    }
}

//CONSULTAR CATEGORIAS
$sql = "SELECT * FROM categorias_habitaciones";
$result = mysqli_query($con, $sql);

if(!$result){
    die("ERROR AL CONSULTAR CATEGORIAS".mysqli_error($con));
}

$categoria=array();

while($row = mysqli_fetch_array($result)){
    $categoria[]=array($row['codHab'],$row['categoria']);
}


$sql = "SELECT ca.categoria, ha.idHabitacion, ha.numero_habitacion, ha.piso, ha.precio, ha.estado, ha.descripcion FROM `habitacion` as ha INNER JOIN categorias_habitaciones as ca WHERE ha.codHab=ca.codHab";
$resultado = mysqli_query($con, $sql);

if(!$resultado){
    die("ERROR AL CONSULTAR HABITACION".mysqli_error($con));
}

$habitaciones=array();

while($row = mysqli_fetch_array($resultado)){
    $habitaciones[]=array($row['idHabitacion'],$row['categoria'],$row['numero_habitacion'],$row['piso'],$row['precio'],$row['estado'],$row['descripcion']);

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content">
               <div class="dual">
                    <div class="left">
                        <span>Formulario de habitaciones</span>
                       <form method="post" class="">
                            <label for=""># Habitacion</label>
                            <input type="number" placeholder="  " name="habitacion"
                            value="<?php if(isset($habitacion)){echo $habitacion;}?>" required>

                            <label for="">Piso</label>
                            <input type="number" placeholder="  " name="piso" 
                            value="<?php if(isset($piso)){echo $piso;}?>" required>

                            <label for="">Precio/Por dia</label>
                            <input type="number" placeholder="  " name="precio"
                            value="<?php if(isset($precio)){echo $precio;}?>" required>

                            <label for="">Descripcion</label>
                            <textarea name="descripcion" id="" cols="30" rows="10"
                            required><?php if(isset($descripcion)){echo $descripcion;}?></textarea>

                            <label for="">Categoria</label>

                            <select id="" name="categ">
                                <option value="seleccione">  Seleccione </option>
                                <?php foreach($categoria as $value):?>
                                <option value="<?php echo $value[0]?>" <?php if(isset($categoriaE)){if($categoriaE==$value[0]){echo 'selected';}}?>><?php echo $value[1]?></option>
                                <?php endforeach;?>
                            </select>

                            <label for="">Disponibilidad</label>
                            <select id="" name="estado">
                                <option value="seleccione">  Seleccione </option>
                                <option value="disponible"  <?php if(isset($estado)){if($estado=="disponible"){echo 'selected';}}?>>Disponible</option>
                                <option value="ocupado" <?php if(isset($estado)){if($estado=="ocupado"){echo 'selected';}}?>>Ocupado</option>
                                <option value="reservado" <?php if(isset($estado)){if($estado=="reservado"){echo 'selected';}}?>>Reservado</option>
                                <option value="vacia sucia" <?php if(isset($estado)){if($estado=="vacia sucia"){echo 'selected';}}?>>Vacia sucia</option>
                                <option value="mantenimieto" <?php if(isset($estado)){if($estado=="mantenimieto"){echo 'selected';}}?>>Mantenimiento</option>
                             
                            </select>
                                    <?php if(isset($alerta)):?>
                                    <div class="alert">
                                        <p><?php echo $alerta;?></p>
                                    </div>
                                    <?php endif;?>
                            <div class="formFooter">
                                <input type="submit" value="Guardar cambios" class="bttn btn">
                                <input type="reset" value="Cancelar " class="bttn2 btn2" >
                            </div>
                        </form>
                    </div>
                    <div class="right">
                        <table id="example" class="display" >
                            <thead>
                                <tr>
                                    <th class="tbId">#</th>
                                    <th>Categoria</th>
                                    <th>Habitacion</th>
                                    <th>Piso</th>
                                    <th>Precio</th>
                                    <th>Estado</th>
                                    <!-- <th>Descripción</th> -->
                                    <th class="opt">Acción</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($habitaciones as $value):?>
                                <tr>
                                    <td><?php echo $value[0]?></td>
                                    <td><?php echo $value[1]?></td>
                                    <td><?php echo "Habitacion ".$value[2]?></td>
                                    <td><?php echo $value[3]?></td>
                                    <td><?php echo $value[4]?></td>
                                    <td><?php echo $value[5]?></td>
                                    <!-- <td><?php echo $value[6]?></td> -->
                                    <td class="tbOpt" idHabitacion="<?php echo $value[0]?>" numeroHabitacion="<?php echo $value[2]?>">
                                        <input type="button" class="bttn btn" value="Editar" id="editarHabitacion" onclick="iniModal(1)">
                                        <input type="button" class="bttn btn2" value="Eliminar" id="EliminarHabitacion" onclick="iniModal(3)">
                                    </td>
                                </tr>
                                <?php endforeach;?>
                            </tbody>
                        </table>
                    </div>
               </div>
            </div>
        </div>
        <div class="modalContainer " id="v2"></div>
        <?php include("../includes/modales/habita.php") ?>
        <?php include("../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v4"></div>

    </main>
</body>

<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="ajaxjs/habitaciones.js"></script>
<script src="../js/modal.js"></script>
</html>