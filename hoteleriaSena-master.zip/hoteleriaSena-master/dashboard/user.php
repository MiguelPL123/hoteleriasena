<?php
include('../includes/conexion.php');
include("../includes/validacionAccesoDash.php");
if ($_SESSION['tipo']!="0") {
    header("Location: dashboard.php");
}

//Guardar informacion de usuario
if (isset($_POST['nombre']) && isset($_POST['user']) && isset($_POST['contrasena'])) {
    $nombre=$_POST['nombre'];
    $usuario=$_POST['user'];
    $contra=$_POST['contrasena'];
    $tipo=$_POST['tipo'];
    if ($tipo!="-1") {
        $result= mysqli_query($con,"INSERT INTO `usuarios` (`id`, `nombres`, `usuario`, `contrasena`, `tipo`) VALUES (NULL, '$nombre', '$usuario', '$contra', '$tipo')");
        if (!$result) {
            die('ERROR AL GUARDAR USUARIO'.mysqli_error($con));
        }
        header('Location: user.php');
    }

}

//ACTUALZAR REGISTRO
if (isset($_POST['nombreEdit']) && isset($_POST['userEdit']) && isset($_POST['contraEdit'])) {
    $nombre=$_POST['nombreEdit'];
    $usuario=$_POST['userEdit'];
    $contra=$_POST['contraEdit'];
    $tipo=$_POST['tipoEdit'];
    $idUser=$_SESSION['idUser'];
    echo "Registro exitoso...";
    if ($tipo!="-1") {
        $result= mysqli_query($con,"UPDATE usuarios SET `nombres`='$nombre', `usuario`='$usuario', `contrasena`='$contra', `tipo`='$tipo' WHERE id=$idUser");
        if (!$result) {
            die('ERROR AL ACTUALIZAR USUARIO'.mysqli_error($con));
        }
        unset($_SESSION['idUser']);
        header('Location: user.php');
    }

}

//Consultar Usuarios
$result= mysqli_query($con,"SELECT * FROM usuarios");
if (!$result) {
    die('ERROR AL CONSULTAR USUARIOS'.mysqli_error($con));
}
$usuarios=array();
while ($usu = mysqli_fetch_array($result)) {
    $tipoUsuario=$usu['tipo'];
    if ($tipoUsuario=="0") {
        $tipoUsuario="Administrador";
    }else{
        $tipoUsuario="Aprendiz";
    }
    $usuarios[]= array(
        "id"=>$usu['id'],
        "nombres"=>$usu['nombres'],
        "usuario"=>$usu['usuario'],
        "tipo"=>$tipoUsuario,
    );
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container flex">
            <div class="content ">
                <div class="head">
                    <input type="button" name="" id="" value="+ Nuevo usuario"  class="bttn" onclick="iniModal(1)">
                </div>
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th class="tbId">#</th>
                            <th>Nombre</th>
                            <th>Usuario</th>
                            <th>Tipo</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($usuarios as $key => $value):?>
                        <tr>
                            <td><?php echo $value['id'];?></td>
                            <td><?php echo $value['nombres'];?></td>
                            <td><?php echo $value['usuario'];?></td>
                            <td><?php echo $value['tipo'];?></td>
                            <td class="tbOpt" num="<?php echo $value['id'];?>">
                                <input type="button" class="bttn btn" value="Editar" id="editUserBtn">
                                <input type="button" class="bttn btn2" value="Eliminar" id="deleteUserBtn">
                            </td>
                        </tr>
                        <?php endforeach;?>
                    </tbody>
                </table>




            </div>
        </div>
        <?php include("../includes/modales/user.php") ?>
        <?php include("../includes/modales/edituser.php") ?>
        <?php include("../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v4"></div>

    </main>
</body>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="../js/modal.js"></script>
<script src="./ajaxjs/user.js"></script>
</html>