<?php
    include('../includes/conexion.php');
    include("../includes/validacionAccesoDash.php");
    $sql = "SELECT r.cod_reserva,cli.nombres,cli.apellidos,hab.numero_habitacion,r.date_in,r.date_out,r.estado FROM `reserva` AS r INNER JOIN clientes AS cli ON r.cedula=cli.cedula INNER JOIN habitacion AS hab ON r.idhabitacion=hab.idHabitacion WHERE r.fechaModificacion=CURDATE() ORDER BY r.estado ASC;";
    $result= mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR RESERVA");
    }
    $reservas=array();

    while ($row = mysqli_fetch_array($result)) {
        $estadoReserva=$row['estado'];
        switch ($estadoReserva) {
            case 1:
                $estadoReserva="Pendiente";
                break;
            case 2:
                $estadoReserva="Check-In";
                break;
            case 3:
                $estadoReserva="Check-Out";
                break;
            case 4:
                $estadoReserva="Cancelado";
                break;
        }
        $reservas[]=array(
            "cod"=>$row['cod_reserva'],
            "nombre"=>$row['nombres']." ".$row['apellidos'],
            "habitacion"=>$row['numero_habitacion'],
            "datein"=>$row['date_in'],
            "dateout"=>$row['date_out'],
            "estado"=>$estadoReserva,
        );
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
  

</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main>
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container">
            <div class="content">
                <header class="bg1">
                    <div class="Iniheader flex">
                        <span>Movimientos del dia</span>
                    </div>
                </header>
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th class="tbId">cod</th>
                            <th>nombres</th>
                            <th>habitacion</th>
                            <th>datein</th>
                            <th>dateout</th>
                            <th>estado</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                      
                        <?php foreach ($reservas as $key => $value):?>
                        <tr>
                            <td><?php echo $value['cod']?></td>
                            <td><?php echo $value['nombre']?></td>
                            <td>Habitacion <?php echo $value['habitacion']?></td>
                            <td><?php echo $value['datein']?></td>
                            <td><?php echo $value['dateout']?></td>
                            <td><?php echo $value['estado']?></td>
                            <td class="tbOpt" reser="<?php echo $value['cod']?>">
                                <input type="button" class="bttn btn3" value="Info" id="infoReserva" onclick="iniModal(2)">
                            </td>
                        </tr>
                        <?php endforeach;?>

                    </tbody>
                </table>
            </div>
        </div>
        <div class="modalContainer " id="v1"></div>
        <?php include("../includes/modales/reserva2.php") ?>
        <div class="modalContainer " id="v4"></div>
    </main>
</body>
<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="../js/modal.js"></script>
<script src="ajaxjs/reservaDash.js"></script>
<!-- <script src="js/modal.js"></script> -->
</html>