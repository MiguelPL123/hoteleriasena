<?php
    include('../includes/conexion.php');
    include("../includes/validacionAccesoDash.php");
    
    unset(  $_SESSION["cargosReserva"],
            $_SESSION['datosempresa'],
            $_SESSION['datosreseva'],
            $_SESSION['personas'],
            $_SESSION['registrosClientes'],
            $_SESSION['habclie'],
            $_SESSION["foliomaestroGrup"]
    );


    $sql="SELECT rg.codigo_reserva,e.nombre,rg.fecha_llegada,rg.fecha_salida,rg.estado,rg.folio_maestro FROM `reserva_grupal` AS rg
    INNER JOIN empresa AS e ON rg.codigo_emp=e.codigo_emp;";
    $result=mysqli_query($con,$sql);
    if (!$result) {
        die("ERROR AL CONSULTAR INFORMACION DE RESERVACION". mysqli_error($con));
    }
    $reservaGrupal=array();
    while ($row = mysqli_fetch_array($result)) {
        $estadoReserva=$row['estado'];
        switch ($estadoReserva) {
            case 1:
                $estadoReserva="Pendiente";
                break;
            case 2:
                $estadoReserva="Check-In";
                break;
            case 3:
                $estadoReserva="Check-Out";
                break;
            case 4:
                $estadoReserva="Cancelado";
                break;
            case 5:
                $estadoReserva="Check-In";
                break;
        }
        $reservaGrupal[]=array(
            "codigo"=>$row['codigo_reserva'],
            "nombre"=>$row['nombre'],
            "fechain"=>$row['fecha_llegada'],
            "fechaout"=>$row['fecha_llegada'],
            "estado"=>$estadoReserva,
            "foliomaestro"=>$row['folio_maestro']
        );

    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>
    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->
        <div class="container">
            <div class="content ">
                <div class="head">
                    <a href="forms/newReservaGrupal.php" class="bttn">+ Nueva reserva</a>
                </div>
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th class="tbId">cod</th>
                            <th>nombres</th>
                            <th>datein</th>
                            <th>dateout</th>
                            <th>estado</th>
                            <th>Folio Maestro</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservaGrupal as $key => $value):?>
                            <tr>
                                <td><?php echo $value['codigo'];?></td>
                                <td><?php echo $value['nombre'];?></td>
                                <td><?php echo $value['fechain'];?></td>
                                <td><?php echo $value['fechaout'];?></td>
                                <td><?php echo $value['estado'];?></td>
                                <td><?php echo $value['foliomaestro'];?></td>
                                <td class="tbOpt" data-code="<?php echo $value['codigo'];?>">
                                    <input type="button" class="bttn btn3 infoReserva" value="Info">
                                    <!-- <input type="button" class="bttn btn2" value="Eliminar" id="eliminarReservaBtn" onclick="iniModal(3)"> -->
                                </td>
                            </tr>    
                        <?php endforeach;?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="modalContainer " id="v1"></div>
        <?php include("../includes/modales/reserva_grup.php") ?>
        <?php include("../includes/modales/deleteModal.php") ?>
        <div class="modalContainer " id="v4"></div>
       
    </main>

</body>

<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

<script src="../js/table.js"></script>
<script src="../js/modal.js"></script>
<!-- <script src="ajaxjs/reservaDash.js"></script> -->
<script src="ajaxjs/detallesreservagrup.js"></script>

<script>$(document).ready(function () {$('#modalTable').DataTable({responsive: true,scrollCollapse: true,paging: false,search:true,searching: false});});</script>
</html>