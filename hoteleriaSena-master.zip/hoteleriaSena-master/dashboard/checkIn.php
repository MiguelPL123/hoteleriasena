<?php    
    include("../includes/validacionAccesoDash.php");
    include("../includes/conexion.php");

    unset($_SESSION['numeropersonasAcom']);
    $checkGlobal=array();

    //ACTUALIZAR
    if(isset($_POST['nombre'])){
        if(isset($_SESSION['code'])){
            $fecha_in=$_POST['fecha_in'];
            $hora_in=$_POST['hora_in'];
            $code = $_SESSION['code'];
            $count=0;
            $sqC="SELECT COUNT(*) FROM `acom_reserva` WHERE codReserva='$code';";
            $result2 = mysqli_query($con, $sqC);
            if(!$result2){
                die("ERROR AL CONTAR ACOMPAÑANTES".mysqli_error($con));
            }
            $count= mysqli_fetch_array($result2)['COUNT(*)'];
            
            $sql="UPDATE reserva SET estado=2, date_in='$fecha_in', hora_in='$hora_in',numero_personas=1,fechaModificacion= CURRENT_DATE() WHERE cod_reserva='$code'";

            if ($count>0) {
                $sql="UPDATE reserva SET estado=2, date_in='$fecha_in', hora_in='$hora_in',numero_personas=$count,fechaModificacion= CURRENT_DATE() WHERE cod_reserva='$code'";
            }
            

            $result = mysqli_query($con, $sql);
            if(!$result){
                die("ERROR AL PASAR A CHECK IN".mysqli_error($con));
            } 
            header("Location: checkIn.php");
        }  
    }

    if(isset($_POST['motivo'])){
        if(isset($_SESSION['code'])){
            $motivo=$_POST['motivo'];
            $garantia=$_POST['garantia'];
            $efectivo=$_POST['efectivo'];
            $deposito=$_POST['deposito'];
            $codigo=$_SESSION['code'];

            $consulta="SELECT * FROM detalles_reserva WHERE cod_reserva='$codigo'";
            $result = mysqli_query($con, $consulta);
            if(!$result){
                die("ERROR AL CONSULTAR DETALELS DE RESERVA".mysqli_error($con));
            }
            if(mysqli_num_rows($result)>0){
                $act="UPDATE detalles_reserva 
                SET motivo='$motivo', garantia='$garantia', pago='$efectivo', personas=0, deposito='$deposito' 
                WHERE cod_reserva='$codigo'";
                $resp=mysqli_query($con, $act);
                if(!$resp){
                    die("ERROR AL ACTUALIZAR DETALLES RESERVA".mysqli_error($con));
                }
            }else{
                $sql="INSERT INTO detalles_reserva(motivo,garantia,pago,deposito,cod_reserva) 
                VALUES('$motivo','$garantia','$efectivo','$deposito','$codigo')";
                $insert=mysqli_query($con,$sql);
                if(!$insert){
                    die("ERROR AL INSERTAR DETALELS RESERVA".mysqli_error($con));
                }
            }
        }
    }

    //CONSULTAS
    $sql = "SELECT ca.categoria, h.numero_habitacion, r.estado, r.cod_reserva, r.date_in, r.date_out, cli.nombres, cli.apellidos FROM categorias_habitaciones AS ca 
    INNER JOIN habitacion AS h ON ca.codHab=h.codHab 
    INNER JOIN reserva AS r ON r.idhabitacion=h.idHabitacion 
    INNER JOIN clientes AS cli ON r.cedula=cli.cedula WHERE r.estado=1;";
    $resultado = mysqli_query($con, $sql);
    if(!$resultado){
        die("ERROR AL CONSULTAR CHECK IN".mysqli_error($con));
    }
    $checkin=array();
    $checkinIndividual=array();
    while($row = mysqli_fetch_array($resultado)){
        $checkin[]=array($row['cod_reserva'], $row['categoria'],$row['numero_habitacion'],'Pendiente',$row['nombres'],$row['apellidos'],$row['date_in'],$row['date_out']);
        
        $checkinIndividual[]=array("codigoReserva"=>$row['cod_reserva'],
        "nombre"=>$row['nombres'],
        "apellido"=>$row['apellidos'],
        "categoria"=>$row['categoria'],
        "habitacion"=>$row['numero_habitacion'],
        "estado"=>'Pendiente',"tipo"=>'Individual');
    
    }



    $sql="SELECT rp.codigo_reserva, e.nombre, rp.folio_maestro, rp.estado FROM `reserva_grupal` AS rp INNER JOIN empresa as e WHERE rp.codigo_emp=e.codigo_emp and rp.estado=1 or rp.estado=5;";
    $result=mysqli_query($con,$sql);
    if(!$result)die("error".mysqli_error($con));

    $checkinGurpal=array();
    while($row=mysqli_fetch_array($result)){
        $checkinGurpal[]=array("codigoReserva"=>$row['codigo_reserva'],
        "nombre"=>$row['nombre'],
        "apellido"=>$row['nombre'],
        "categoria"=>$row['folio_maestro'],
        "habitacion"=>$row['folio_maestro'],
        "estado"=>'Pendiente',"tipo"=>'Grupal');
    }
    
    array_push($checkGlobal,$checkinIndividual);
    if (count($checkinGurpal)>0) {
        array_push($checkGlobal,$checkinGurpal);
    }



    if(isset($_POST['fecha_in2'])){
        
        $fehcaIn=$_POST['fecha_in2'];
        $hora=$_POST['hora_in'];
        $extra=$_POST['extra'];
        $maestro1=$_POST['maestro1'];
        $cedula=$_POST['personasExtra'];


        $verificar="SELECT * FROM clie_reserva_grupál WHERE folio_extra='$extra' and fecha_llegada is null";
        $respeusta=mysqli_query($con,$verificar);
        $numero1=mysqli_num_rows($respeusta);

        if($numero1>0){
            $numero1=$numero1-1;
            $sql="UPDATE clie_reserva_grupál SET fecha_llegada='$fehcaIn', hora='$hora' WHERE cedula='$cedula' and folio_extra='$extra'";
    
            $result=mysqli_query($con,$sql);
            if(!$result)die("error".mysqli_error($con));
            if($numero1==0){
                $sql="UPDATE folios_extra SET estado='checked' WHERE folio_extra='$extra'";
                $result=mysqli_query($con,$sql);
                if(!$result)die("error".mysqli_error($con));
            }
        }

        $sql3="UPDATE reserva_grupal SET estado=5 WHERE folio_maestro='$maestro1'";
        $result1=mysqli_query($con,$sql3);
        if(!$result1)die("error".mysqli_error($con));
        
        
        $consulta="SELECT * FROM folios_extra WHERE estado='pendiente' and folio_maestro='$maestro1'";
        $resp = mysqli_query($con,$consulta);
        $numero=mysqli_num_rows($resp);

        if($numero==0){
            $update="UPDATE reserva_grupal SET estado=2 WHERE folio_maestro=$maestro1";
            $sql=mysqli_query($con,$update);

            if(!$sql)die("error".mysqli_error($con));
                
        }
        
        header("Location: checkIn.php");
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://fonts.sandbox.google.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
    <link rel="" href="https://cdn.datatables.net/fixedheader/3.1.6/css/fixedHeader.dataTables.min.css">
    <title>Document</title>
</head>
<body>

    <?php include("../includes/dashNavTop.php") ?><!-- Barra de navegacion en la parte superior -->
    <main class="flex">
        <?php include("../includes/dashNav.php") ?><!-- Barra de navegacion entre ventanas -->

        <div class="container flex">
            <div class="content ">
                <table id="example" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th class="tbId"># Reserva</th>
                            <th>Nombres</th>
                            <th>Categoria</th>
                            <th>Habitación</th>
                            <th>Estado</th>
                            <th>Tipo</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody>
                                <?php foreach($checkGlobal as $value1):?>
                                    <?php foreach($value1 as $value2):?>
                        <tr>
                            <td><?php echo $value2["codigoReserva"]?></td>
                            <?php if($value2["tipo"]=="Individual"):?>
                                <td><?php echo $value2["nombre"]?>&nbsp;<?php echo $value2["apellido"]?></td>
                            <?php else: ?>
                                <td><?php echo $value2["nombre"]?></td>
                            <?php endif;?>

                            <?php if($value2["tipo"]=="Individual"):?>
                                <td><?php echo $value2["categoria"]?></td>
                            <?php else: ?>     
                                <td>Folio Maestro:</td>
                            <?php endif;?>

                            <?php if($value2["tipo"]=="Individual"):?>
                                <td>Habitacion <?php echo $value2["habitacion"]?></td>
                            <?php else: ?>  
                                <td><?php echo $value2["habitacion"]?></td>
                            <?php endif;?>
                            <td><?php echo $value2["estado"]?></td>
                            <td><?php echo $value2["tipo"]?></td>

                            <td class="tbOpt" reservaGrup="<?php echo $value2["codigoReserva"]?>" folioMaestro="<?php echo $value2["habitacion"]?>" tipo="<?php echo $value2["tipo"]?>" codigo="<?php echo $value2["codigoReserva"]?>" habitacion="<?php echo $value2["habitacion"]?>">
                                <!-- <input type="button" class="bttn btn3" value="Info" id="info" onclick="iniModal(5)"> -->
                                <input type="button" class="bttn btn" value="Check" id="check" onclick="abrirModalCheck()">
                                <input type="button" class="bttn btn3" value="Info" id="info" onclick="abrirModalInfo()">
                                <input type="button" class="bttn btn2" value="Cancelar" id="cancelar" onclick="iniModal(3)">

                            </td>
                        </tr>
                                   <?php endforeach;?>
                                <?php endforeach;?>
                        
                    </tbody>
                    </table>
            </div>
        </div>
        <?php include("../includes/modales/checkin.php") ?>
        <?php include("../includes/modales/checkin2.php") ?>
        <?php include("../includes/modales/checkin3.php") ?>
        <?php include("../includes/modales/deleteModal.php") ?>
        <?php include("../includes/modales/checkinGrup.php") ?>

      
    </main>
</body>

    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>

    <script src="ajaxjs/checkin.js"></script>
    <script src="../js/table.js"></script>
    <!-- <script src="../js/modal.js"></script> -->
    <script src="../js/modal_plus.js"></script>
    
    <script>
        function abrirModalCheck(){
            $(document).on('click', '#check', function(){
            let element = $(this)[0].parentElement;
            let tipo = $(element).attr('tipo');

            if(tipo=='Individual'){
                document.getElementById('individual').style.display='block';
                document.getElementById('grupal').style.display='none';
                iniModal(1)
            }else{
                document.getElementById('individual').style.display='none';
                document.getElementById('grupal').style.display='block';
                iniModal(1)
            }
         });
        }

        function abrirModalInfo(){
            $(document).on('click', '#info', function(){
            let element = $(this)[0].parentElement;
            let tipo = $(element).attr('tipo');

            if(tipo=='Individual'){
                document.getElementById('individual2').style.display='block';
                document.getElementById('grupal2').style.display='none';
                iniModal(2)
            }else{
                document.getElementById('individual2').style.display='none';
                document.getElementById('grupal2').style.display='block';
                iniModal(2)
            }
         });
        }
    </script>

</html>