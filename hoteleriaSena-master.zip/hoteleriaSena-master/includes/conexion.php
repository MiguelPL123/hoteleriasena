<?php
$host = "localhost";
$user  = "root";
$pass = "";
$bd = "hoteleriasena";

$con = mysqli_connect($host,$user,$pass,$bd);

?>