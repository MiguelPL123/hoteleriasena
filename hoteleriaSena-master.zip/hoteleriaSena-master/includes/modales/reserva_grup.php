
<div class="modalContainer " id="v2">
    <div class="modalForm table__form">
        <form action="" class="">
            <div class="form__top">
                <label for="">Codigo Empresa: &nbsp;<b><span id="codigoemp"></span></b></label>

                <label for="">Medio Reservacion: &nbsp;<b><span id="medio"></span></b></label>
                
                <label for="">Nombres Empresa: &nbsp;<b><span id="nombresemp"></span></b></label>

                <label for="">Cargo: &nbsp;<b><span id="cargo"></span></b></label>

                <label for="">Fecha cotizacion: &nbsp;<b><span id="fechacotizacion"></span></b></label>

                <label for="">Contacto: &nbsp;<b><span id="contacto"></span></b></label>                
                
                <label for="">Fecha In: &nbsp;<b><span id="fechain"></span></b></label>

                <label for=""># Personas: &nbsp;<b><span id="numpersonas"></span></b></label>

                <label for="">Fecha Out: &nbsp;<b><span id="fechaout"></span></b></label>


                <label for="">Folio Maestro: &nbsp;<b><span id="foliomaestro"></span></b></label>

                <label for="">Código de reserva: &nbsp;<b><span id="codigoreserva"></span></b></label>


                <div style="width: 100%; text-align: left; padding-left: 37px;" id="acompas">
                    
                </div>
            </div>
            <div class="form_bot">
                <label for="" class="align-center"><h3>Cargos</h3></label>

                <table id="modalTable" class="display" style="width:100%">
                    <thead>
                    <tr>
                        <th>Descripción</th>
                        <th>Valor</th>
                        <th>IVA</th>
                        <th>Total+IVA</th>
                    </tr>
                    </thead>
                    <tbody id="cargosreservagrup">
                        
                    </tbody>
                </table>
            
            </div>
         
            

            <div class="formFooter">
                <a href="forms/verRegistro__personas-grupal.php" class="bttn btn">Personas</a>
                <!-- <input type="button" value="Detalles " class="bttn2 btn3 click"    onclick="iniModal(4)"> -->
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(2)">
            </div>
        </form>
       
    </div>
</div>


