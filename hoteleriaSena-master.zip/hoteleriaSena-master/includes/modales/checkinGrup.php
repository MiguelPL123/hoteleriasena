<div class="modalContainer " id="v5">
    <div class="modalForm ">
        <form method="POST">
            <label for="">Cedula  </label>
            <input type="number" placeholder="Cedula" name="cedula" id="cedula" readonly>

            <label for="">Nombre  </label>
            <input type="text" placeholder="Nombre" name="nombre" id="nombre" readonly>

            <label for="">Telefono</label>
            <input type="text" placeholder="Telefono" name="telefono" id="telefono" readonly>

            <label for="">Fecha Check-in  </label>
            <input type="date" placeholder="" name="fecha_in" id="fecha_in">

            <label for="">Hora Check-in </label>
            <input type="time" placeholder="" name="hora_in" id="hora_in">

            <label for="">Noches de estadia</label>
            <input type="number" placeholder="Dias" name="dias" id="dias" readonly>

            <div class="formFooter">
                <input type="submit" value="Check-in" class="bttn btn">
            
             
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="location.reload()">

                <a class="bttn  bttn3" id="btnacompañante"> Acompañantes</a>

            </div>
        </form>
    </div>
</div>