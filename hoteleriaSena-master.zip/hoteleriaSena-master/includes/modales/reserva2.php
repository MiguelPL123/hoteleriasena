
<div class="modalContainer " id="v2">
    <div class="modalForm ">
        <form action="" class="">
            <label for="">Identificación: &nbsp;<b><span id="cedula">Example</span></b></label>

            <label for="">Nombres: &nbsp;<b><span id="nombres">Example</span></b></label>

            <label for="">Apellidos: &nbsp;<b><span id="apellidos">Example</span></b></label>

            <label for="">Correo: &nbsp;<b><span id="correo">Example</span></b></label>

            <label for="">Celular: &nbsp;<b><span id="celular">Example</span></b></label>
    
            <label for="">Habitación: &nbsp;<b><span id="habitacion">Example</span></b></label>
            
            <label for="">Tipo de pago: &nbsp;<b><span id="pago">Example</span></b></label>
            
            <label for="">¿Es una empresa?: &nbsp;<b><span id="empresa">Example</span></b></label>

            <label for="">Check-in: &nbsp;<b><span id="checkin">Example</span></b></label>

            <label for="">Check-out: &nbsp;<b><span id="checkout">Example</span></b></label>

            <label for="">Código de reserva: &nbsp;<b><span id="codigo">Example</span></b></label>
            
            <label for=""><h3>Acompañantes:</h3></label>

            <div style="width: 100%; text-align: left; padding-left: 37px;" id="acompas">
                <label for=""><b><span>1007795174</span></b>&nbsp; - Bryan Charris</label>
            </div>
            
            

            <div class="formFooter">
                <!-- <a href="forms/foliosGrup.php" class="bttn btn">Folios</a> -->
                <!-- <input type="button" value="Detalles " class="bttn2 btn3 click"    onclick="iniModal(4)"> -->
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(2)">
            </div>
        </form>
    </div>
</div>


