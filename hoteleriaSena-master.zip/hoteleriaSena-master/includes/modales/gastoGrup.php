<div class="modalContainer " id="v1">
    <div class="modalForm "">
        <form action="" class="">
            <label for="">Cargo</label>
            <select name="tipo" id="servicio">
                <option value="select">Seleccione</option>
                <?php foreach ($servicios as $key => $value):?>
                    <option value="<?php echo $value['codServicio'];?>"><?php echo $value['nombres'];?></option>
                <?php endforeach;?>
            </select>

            <label for="">Valor Servicio</label>
            <input type="number" placeholder="" id="valor" readonly>

            <label for="">IVA</label>
            <input type="text" value="19%" readonly>

            <label for="">Total (Servicio X numero de personas) con IVA</label>
            <input type="number" placeholder="" id="total" readonly>

            <div class="formFooter">
                <input type="button" value="Registrar " class="bttn2 btn3 click" id="registrarCargo">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" id="finalizarprocesocargos">
            </div>
        </form>
    </div>
</div>
