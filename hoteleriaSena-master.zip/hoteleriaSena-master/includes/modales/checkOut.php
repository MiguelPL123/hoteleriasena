<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <!-- INDIVIDUAL -->
        <form style="display: none;" class="" id="individual">
            <div class="form__grid">
                <label for="">Categoria Habitación : &nbsp; <b><span id="categoria1"></span></b></label>
                <label for="">Precio Habitación : &nbsp; <b> $<span id="precio"></span></b></label>
                <label for="">No Referencia : &nbsp; <b><span id="referencia"></span></b></label>
                <label for="">No Contacto : &nbsp; <b><span id="contrato"></span></b> </label>
                <label for="">Check-in Fecha/Hora : &nbsp; <b><span id="fechaIn"></span> &nbsp; <span id="horaIn"></span></b></label>
                <label for="">Check-out Fecha/Hora : &nbsp; <b><span id="fechaOut"></span> &nbsp; <span id="horaOut"></span></b></label>
                <label for="">Dias : &nbsp; <b><span id="dias"></span></b></label>
                <label for="">Iva: &nbsp; <b>19%</b></label>
                <label for="">Monto (Precio * Dias) : &nbsp; <b><span id="monto"></span></b></label>
            </div>
            <div class="formFooter">
                <input type="button" id="checkout" value="Checkout" class="bttn2 btn">
                <input type="button" id="editar" value="Editar " class="bttn2 btn " onclick="iniModal(4)">
                <input type="button" value="Cerrar " class="bttn2 btn2 click" onclick="closeModals(1)">
            </div>
        </form>
        <!-- GRUPAL -->
        <form style="display:none;" class="" id="grupal">
            <div class="form__grid">
                <label for="">Empresa: &nbsp;<b><span id="empresaInfo"></span></b></label>

                <label for="">NIT: &nbsp;<b><span id="nitInfo"></span></b></label>

                <label for="">Correo: &nbsp;<b><span id="correoInfo"></span></b></label>

                <label for="">Pais: &nbsp;<b><span id="paisInfo"></span></b></label>

                <label for="">Contacto: &nbsp;<b><span id="contactoInfo"></span></b></label>
        
                <label for="">Cargo del Contacto: &nbsp;<b><span id="cargoInfo"></span></b></label>
                
                <label for="">Fecha de Salida: &nbsp;<b><span id="fechaSalidaInfo"></span></b></label>

                <label for="">Hora de Salida: &nbsp;<b><span id="horaSalidaInfo"></span></b></label>

                <label for="">Cantidad de personas: &nbsp;<b><span id="CPersonasInfo"></span></b></label>

                <label for="">Folio Maestro: &nbsp;<b><span id="FMaestroInfo"></span></b></label>

                <label for="">Medio de la Reserva: &nbsp;<b><span id="MedioInfo"></span></b></label>          
            </div>
            <div class="formFooter">
                <input type="button" id="checkOutGrupal" value="Checkout" class="bttn2 btn">
                <input type="button" value="Cerrar " class="bttn2 btn2 click" onclick="closeModals(1)">
            </div>
        </form>
        
    </div>
</div>