<div class="modalContainer " id="v3">
    <div class="modalForm deleteForm">
        <form action="" class="">
            <h2>¿Está seguro de querer borrar este campo? </h2>
            <div class="formFooter">
                <input type="button" value="Borrar registro" class="bttn btn2" id="EliminarRegistro">
                <input type="button" value="Cancelar " class="bttn2 btn" onclick="closeModals(3)">
            </div>
        </form>
    </div>
</div>
