
<div class="modalContainer " id="v4">
    <div class="modalForm ">
        <form method="post">
            <label for="">Código reserva  </label>
            <input type="text" name="codigo2" id="codigo2" placeholder="Código reserva">

            <label for="">Motivo del viaje</label>
            <input type="text" name="motivo" id="motivo" placeholder="Motivo">

            <label for="">Garantia de la reserva  </label>
            <input type="number" name="garantia" id="garantia" placeholder="Garantia">
            
            <label for="">Formas de pago</label>
            <select name="efectivo">
                <option value="Efectivo">Efectivo</option>
            </select>

            <label for="">Depósito </label>
            <input type="number" name="deposito" id="deposito" placeholder="Depósito">

            <div class="formFooter">
                <input type="submit" value="Guardas detalles" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(4)">
            </div>
        </form>
    </div>
</div>