

<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form method="POST" enctype="multipart/form-data">
            <label for="">Categoria  </label>
            <input type="text" placeholder="Categoria" name="categoria1" id="categoria1">
            
            <label for="">Imagen</label>
            <input type="file" placeholder="" name="imagen1" id="imagen1" onchange="displayImg2(this,$(this))">

            <img src="" alt="" name="foto1" id="foto1">

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>