<div class="modalContainer " id="v2">
    <div class="modalForm ">
        <form action="" class="">
            <label for="">Tipo de documento : &nbsp;<b><span id="tipo">sdas</span></b></span></label>
            <label for="">Identificación : &nbsp;<b><span id="cedula">sdas</span></b></span></label>
            <label for="">Nombres : &nbsp;<b><span id="nombres"></span></b></span></label>
            <label for="">Apellidos : &nbsp;<b><span id="apellidos"></span></b></span></label>
            <label for="">Genero : &nbsp;<b><span id="genero"></span></b></span></label>
            
            <label for="">Fecha de Nacimiento : &nbsp;<b><span id="fechanac"></span></b></span></label>
            <label for="">Lugar de Nacimiento : &nbsp;<b><span id="lugarnac"></span></b></span></label>
            <label for="">Ciudad de Referencia : &nbsp;<b><span id="ciudadres"></span></b></span></label>
            <label for="">Pais : &nbsp;<b><span id="pais"></span></b></span></label>
            <label for="">Dirección de Recidencia : &nbsp;<b><span id="direccion"></span></b></span></label>
            
            <label for="">Correo Personal : &nbsp;<b><span id="correoper"></span></b></span></label>
            <label for="">Correo Corporativo : &nbsp;<b><span id="correocor"></span></b></span></label>

            <label for="">Telefono Fijo : &nbsp;<b><span id="numerofijo"></span></b></span></label>
            <label for="">Telefono Movil : &nbsp;<b><span id="numeromovil"></span></b></span></label>
            <label for="">Numero Auxiliar : &nbsp;<b><span id="numeroaux"></span></b></span></label>

            <div class="formFooter">
                <input type="button" value="Reservar " class="bttn2 btn" onclick="location.href='forms/newReserva.php'">
                <input type="button" value="Cerrar " class="bttn2 btn2 click" onclick="location.reload()">
            </div>
        </form>
    </div>
</div>







