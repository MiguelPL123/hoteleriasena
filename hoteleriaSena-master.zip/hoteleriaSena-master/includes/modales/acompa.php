
<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form method="POST" action="">
            
            <label for="">Tipo de documneto</label>

            <select name="tipoEdit2" id="tipoEdit2">
                <option value="select" id="select">Seleccione</option>
                <option value="TI" id="TI2" >Tarjeta de identidad</option>
                <option value="CC" id="CC2" >Cédula de Ciudadania</option>
                <option value="CE" id="CE2" >Cédula de extranjería</option>
            </select>

            <label for="">Número de documento</label>
            <input type="number" placeholder="número" name="numeroEdit" id="numeroEdit" required>

            <label for="">Nombres del acompañante</label>
            <input type="text" placeholder="Nombres" name="nombreEdit"  id="nombreEdit" required>

            <label for="">Apellidos del acompañante</label>
            <input type="text" placeholder="Apellidos" name="apellidoEdit"  id="apellidoEdit" required>

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="location.reload()">
            </div>
        </form>
    </div>
</div>