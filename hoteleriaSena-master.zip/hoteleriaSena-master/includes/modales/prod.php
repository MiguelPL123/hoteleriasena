
<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form method="POST">
            <label for="">Código</label>
            <input type="number" placeholder="Nombre" name="codeProd" id="codeProd" readonly>
            <label for="">Nombre</label>
            <input type="text" placeholder="Nombre" name="nombreProd" id="nombreProd">
            <label for="">Precio</label>
            <input type="number" placeholder="Precio" name="precioProd" id="precioProd">
            <label for="">Descripción</label>
            <input type="text" placeholder="Descripción" name="descProd" id="descProd">

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>