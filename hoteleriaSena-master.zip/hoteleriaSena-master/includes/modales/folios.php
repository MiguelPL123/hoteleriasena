
<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form method="POST" enctype="multipart/form-data">
            <label for="">Código del Servicio  </label>
            <input type="text" placeholder="Codigo" name="folio1" id="folio" readonly>
            <label for="">Nombre del Servicio </label>
            <input type="text" placeholder="Nombre Servicio / Punto de Venta" name="nombre1" id="nombreFolio">
            <label for="">Precio </label>
            <input type="text" placeholder="Precio Servicio" name="precio1" id="precio1">

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>