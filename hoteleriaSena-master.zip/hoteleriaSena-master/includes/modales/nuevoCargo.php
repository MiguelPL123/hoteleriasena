<div class="modalContainer " id="v4">
    <div class="modalForm">
        <form method="POST" class="">
            <label for="">Cargo </label>
            <select name="servicios" id="servicios">
                <option value="select">Seleccione...</option>
                <?php foreach($servicios as $value):?>
                <option value="<?php echo $value[1];?>"><?php echo $value[2];?></option>
                <?php endforeach;?>
            </select>

            <label for="">ICO</label>

            <label for="">Valor Sin Ico</label>
            <input type="number" id="valorServicioSinIco" name="valorServicioSinIco" required>

            <label for="">Valor+ICO</label>
            <input type="number" id="valorServicioMasIco" name="valorServicioMasIco" required>
                
            
            <label for="">Descripción</label>
            <input type="text" name="descripcionServicio" required>

            <label for="">Fecha</label>
            <input type="date" name="fechaServicio" required>


            <div class="formFooter">
                <input type="submit" value="Añadir cargo" class="bttn2 btn3 click" >
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(4)">
            </div>
        </form>
    </div>
</div>
