<?php

?>
<div class="modalContainer " id="v1">
    <div class="modalForm " style="display: none;" id="individual">
        <form method="POST">
            <label for="">Cedula  </label>
            <input type="number" placeholder="Cedula" name="cedula" id="cedula" readonly>

            <label for="">Nombre  </label>
            <input type="text" placeholder="Nombre" name="nombre" id="nombre" readonly>

            <label for="">Telefono</label>
            <input type="text" placeholder="Telefono" name="telefono" id="telefono" readonly>

            <label for="">Fecha Check-in  </label>
            <input type="date" placeholder="" name="fecha_in" id="fecha_in">

            <label for="">Hora Check-in </label>
            <input type="time" placeholder="" name="hora_in" id="hora_in">

            <label for="">Noches de estadia</label>
            <input type="number" placeholder="Dias" name="dias" id="dias" readonly>

            <div class="formFooter">
                <input type="submit" value="Check-in" class="bttn btn">
            
             
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="location.reload()">

                <a class="bttn  bttn3" id="btnacompañante"> Acompañantes</a>

            </div>
        </form>

    </div>
    



    <div class="modalForm " style="display: none;" id="grupal">
        <form method="POST" class="modal_form-cont">
            <div class="form_head">
                <label for="">Habitación  </label>
                <select name="" id="habitacion1">
                    <option value="">Seleccionar...</option>
                </select>

                <label for="">Folio maestro  </label>
                <input type="text" placeholder="" name="maestro1" id="maestro1" readonly>

                <label for="" id="textExtra">Folio extra  </label>
                <input type="text" placeholder="" name="extra" id="extra" readonly>

                <label for="">Fecha Check-in  </label>
                <input type="date" placeholder="" name="fecha_in2" id="fecha_in" required>

                <label for="">Hora Check-in </label>
                <input type="time" placeholder="" name="hora_in" id="hora_in" required>

                <label for="">Nombre</label>
                <select name="personasExtra" id="personasExtra">
                    <option value="">Seleccionar...</option>
                </select>                  
                <!-- <input type="text" id="personasExtra" readonly> -->
            </div>
            <div class="formFooter">
                <input type="button" value="Finalizar Check-in" class="bttn btn2" id="checkinFinal">
                <input type="submit" value="Check-in" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="location.reload()">
                <!-- <a class="bttn  bttn3" id="btnacompañante"> Acompañantes</a> -->
            </div>
        </form>
    </div>


</div>