
<div class="modalContainer " id="v2">
    <div class="modalForm ">
        <form action="" method="POST">
            <label for="">Nombre</label>
            <input type="text"  name="nombreEdit" id="nombreEdit" required>
            <label for="">Usuario</label>
            <input type="text"  name="userEdit" id="userEdit" required>
            <label for="">Contraseña</label>
            <input type="password" name="contraEdit" id="contraEdit" required>
            <label for="">Tipo de usuario</label>
            <select name="tipoEdit">
                <option value="-1" id="select" >Seleccione</option>
                <option value="0" id="admin">Administrador</option>
                <option value="1" id="aprendiz">Aprendíz</option>
            </select>

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="location.reload()">
            </div>
        </form>
    </div>
</div>