
<div class="modalContainer " id="v1">
    <div class="modalForm">
        <form action="" method="post">
            <label for="">Nombres</label>
            <input type="text" placeholder="" name="nombre"required>
            <label for="">Usuario</label>
            <input type="text" placeholder="" name="user"required>
            <label for="">Contraseña</label>
            <input type="password" placeholder="  " name="contrasena" required>
            <label for="">Tipo de usuario</label>
            <select name="tipo" id="">
                <option value="-1">Seleccione</option>
                <option value="0">Administrador</option>
                <option value="1">Aprendíz</option>
            </select>

            <div class="formFooter">
                <input type="submit" value="Agregar usuario" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>