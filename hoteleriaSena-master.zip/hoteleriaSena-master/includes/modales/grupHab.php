<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form action="" class="">
            <label for="">Categoria </label>
            <select name="tipo" id="tipoDoc">
                <option value="select">Seleccione</option>
                <option value="TI">Tarjeta de identidad</option>
            </select>
​
            <label for="">Habitación</label>
            <input type="text" placeholder="Habitación">
​
            <label for="">Piso</label>
            <input type="number" min="1">
​
            <label for="">Precio</label>
            <input type="number" >
​
            <label for="">Estado</label>
            <select name="tipo" id="tipoDoc">
                <option value="select">Seleccione</option>
                <option >Reservado</option>
            </select>
​
​
            <div class="formFooter">
                <input type="button" value="Guardar Cambios " class="bttn2 btn3 click" >
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>