
<div class="modalContainer " id="v1">
    <div class="modalForm ">
        <form method="POST">
            <label for="">Habitacion</label>
            <input type="number" name="habitacion1" id="habitacion1" placeholder="  ">

            <label for="">Piso</label>
            <input type="number" name="piso1" id="piso1" placeholder="  ">

            <label for="">Precio</label>
            <input type="number" name="precio1" id="precio1" placeholder="  ">

            <label for="">Descripcion</label>
            <textarea name="descripcion1" id="descripcion1" cols="30" rows="10">
            </textarea>

            <label for="">Categoria</label>
            <select name="categoria1">
                <?php foreach($categoria as $value):?>
                <option value="<?php echo $value[0];?>"id="<?php echo $value[0];?>"><?php echo $value[1];?></option>
                <?php endforeach;?>
                </select>

            <label for="">Disponibilidad</label>
            <select name="estado1" id="estado1">
                <option value="disponible" id="disp">Disponible</option>
                <option value="ocupado" id="ocupado">Ocupado</option>
                <option value="reservado" id="reservado">Reservado</option>
                <option value="vacia sucia" id="vaciasucia">Vacia Sucia</option>
                <option value="mantenimieto" id="mantenimieto">Mantenimiento</option>


            </select>

            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="location.reload()">
            </div>
        </form>
    </div>
</div>