
<div class="modalContainer " id="v2">
    <div class="modalForm ">
        <form action="" class="">
            <label for="">Identificación: &nbsp;<b><span id="cedula"></span></b></label>

            <label for="">Nombres: &nbsp;<b><span id="nombres"></span></b></label>

            <label for="">Apellidos: &nbsp;<b><span id="apellidos"></span></b></label>

            <label for="">Correo: &nbsp;<b><span id="correo"></span></b></label>

            <label for="">Celular: &nbsp;<b><span id="celular"></span></b></label>
    
            <label for="">Habitación: &nbsp;<b><span id="habitacion"></span></b></label>
            
            <label for="">Tipo de pago: &nbsp;<b><span id="pago"></span></b></label>
            
            <label for="">¿Es una empresa?: &nbsp;<b><span id="empresa"></span></b></label>

            <label for="">Check-in: &nbsp;<b><span id="checkin"></span></b></label>

            <label for="">Check-out: &nbsp;<b><span id="checkout"></span></b></label>

            <label for="">Código de reserva: &nbsp;<b><span id="codigo"></span></b></label>
            
            <label for=""><h3>Acompañantes:</h3></label>

            <div style="width: 100%; text-align: left; padding-left: 37px;" id="acompas">
                
            </div>
            
            

            <div class="formFooter">
                <!-- <a href="forms/foliosGrup.php" class="bttn btn">Folios</a> -->
                <!-- <input type="button" value="Detalles " class="bttn2 btn3 click"    onclick="iniModal(4)"> -->
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(2)">
            </div>
        </form>
    </div>
</div>


