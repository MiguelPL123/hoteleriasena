
<div class="modalContainer " id="v4">
    <div class="modalForm ">
        <form method="post">
            <label for="">Habitación</label>
            <input type="text" placeholder="  "  id="habitaOut" readonly>
            
            <label for="">Nombre </label>
            <input type="text" placeholder="  "  id="nombreOut" readonly>

            <label for="">Telefono </label>
            <input type="text" placeholder="  " id="tellOut" readonly>

            <label for="">Fecha Check-Out </label>
            <input type="date" placeholder="  " name="fechaout" id="fechasalida">

            <label for="">Noches de estadia </label>
            <input type="number" placeholder="  " id="nochesOut" readonly>
            
            <div class="formFooter">
                <input type="submit" value="Guardas detalles" class="bttn btn" id="guardarDetallesCheckOut">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(4)">
            </div>
        </form>
    </div>
</div>