<div class="modalContainer " id="v1">
    <div class="modalForm " style="max-height: 300px !important;">
        <form action="" class="">
            <label for="">Asignar persona </label>
            <input type="text" id="habitaPer" readonly>
            <select name="tipo" id="clienthab">
                <option value="select">Seleccione</option>
                <option value="">Persona</option>
            </select>
            <input type="hidden" id="codHab">
            <div class="formFooter">
                <input type="button" value="Guardar " class="bttn2 btn3 click" id="registrarhabclie">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="location.reload();">
                <!-- closeModals(1) -->
            </div>
        </form>
    </div>
</div>