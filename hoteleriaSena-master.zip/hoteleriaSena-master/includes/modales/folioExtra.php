<div class="modalContainer " id="v1">
    <div class="modalForm">
        <form action="" class="modal_form-cont">
            <div class="form_head">
                <div class="form_title">
                    <input type="button" value="Añadir Cargo" class="bttn2 btn3" onclick="iniModal(4)">
                </div>
                <table id="modalTable" class="display">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Cargo</th>
                            <th>Descripción</th>
                            <th>Fecha</th>
                            <th>ICO</th>
                            <th>Total+ICO</th>
                            <th class="opt">Acción</th>
                        </tr>
                    </thead>
                    <tbody id="tbodyCargo">
                        <?php foreach($extras as $value):?>
                        <tr>                               
                        
                            <td><?php echo $value[0]?></td>
                            <td><?php echo $value[1]?></td>
                            <td><?php echo $value[2]?></td>
                            <td><?php echo $value[3]?></td>
                            <td><?php echo $value[4]?> %</td>
                            <td><?php echo $value[5]?></td>
                            <td><?php echo $value[6]?></td>
                            <td class="tbOpt" idCargoExtra='<?php echo $value[0]?>'>
                                <input type="button" class="bttn btn2" value="Eliminar" id='eliminar' onclick="iniModal(3)">
                            </td>
                        </tr>
                        <?php endforeach;?>
                    </tbody>
                </table>
            </div>
            <div class="formFooter">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(1)">
            </div>
        </form>
    </div>
</div>
