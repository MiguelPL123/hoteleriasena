
<div class="modalContainer  " id="v1">
    <div class="modalForm  small__form">
        <form method="POST" action="">
   
            
            <label for="">Nombre</label>
            <input type="text" placeholder="Nombres" name="nombreEdit"  id="nombreEdit" required>

            <label for="">Precio</label>
            <input type="number" placeholder="número" name="numeroEdit" id="numeroEdit" required>


            <div class="formFooter">
                <input type="submit" value="Guardar cambios" class="bttn btn">
                <input type="button" value="Cancelar " class="bttn2 btn2" onclick="location.reload()">
            </div>
        </form>
    </div>
</div>