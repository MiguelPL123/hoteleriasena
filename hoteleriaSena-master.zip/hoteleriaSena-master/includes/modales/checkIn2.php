
<div class="modalContainer " id="v2">
    <div class="modalForm " style="display:none;" id="individual2">
        <form action="" class="">
            <label for="">Codigo Reserva  </label>
            <input type="text" id="codigo" placeholder="Codigo" readonly>

            <label for="">Fecha inicio</label>
            <input type="date" id="inicio" placeholder="Inicio" readonly>

            <label for="">Fecha final </label>
            <input type="date" id="final" placeholder="" readonly>
            
            <label for="">Noches de estadia</label>
            <input type="number" placeholder="Dias" id="dias2" readonly>

            <div class="formFooter">
                <input type="button" value="Detalles " class="bttn2 btn3 click" id="detalles" onclick="iniModal(4)">
                <input type="button" value="Cancelar " class="bttn2 btn2 click" onclick="closeModals(2)">
            </div>
        </form>
    </div>
    <div class="modalForm "style="display: none;" id="grupal2">
    <form action="" class="" >
            <label for="">Empresa: &nbsp;<b><span id="empresaInfo"></span></b></label>

            <label for="">NIT: &nbsp;<b><span id="nitInfo"></span></b></label>

            <label for="">Correo: &nbsp;<b><span id="correoInfo"></span></b></label>

            <label for="">Pais: &nbsp;<b><span id="paisInfo"></span></b></label>

            <label for="">Contacto: &nbsp;<b><span id="contactoInfo"></span></b></label>
    
            <label for="">Cargo del Contacto: &nbsp;<b><span id="cargoInfo"></span></b></label>
            
            <label for="">Fecha Cotización: &nbsp;<b><span id="cotizaInfo"></span></b></label>

            <label for="">Fecha de Llegada: &nbsp;<b><span id="llegadaInfo"></span></b></label>

            <label for="">Fecha de Salida: &nbsp;<b><span id="salidaInfo"></span></b></label>

            <label for="">Cantidad de personas: &nbsp;<b><span id="CPersonasInfo"></span></b></label>

            <label for="">Folio Maestro: &nbsp;<b><span id="FMaestroInfo"></span></b></label>

            <label for="">Medio de la Reserva: &nbsp;<b><span id="MedioInfo"></span></b></label>

            <div class="formFooter">
                <input type="button" value="Cerrar " class="bttn2 btn2 click" onclick="closeModals(2)">
            </div>
        </form>
    </div>
</div>
