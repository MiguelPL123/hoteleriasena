<header class="flex">
       <div class="logo">
            <a href="../home.php"><img src="../images/senablanco.png" alt=""></a>
            <h2>Hoteleria y turismo SENA</h2>
       </div>
        <div class="logoutBtn">
            <a href="../includes/logout.php">
                <i><span class="material-symbols-outlined">
                power_settings_new
                </span></i>
                <span>Cerrar sesión</span>
            </a>
        </div>
</header>