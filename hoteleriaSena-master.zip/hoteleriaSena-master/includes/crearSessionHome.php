<?php
    session_start();
    $habitacion=$_POST['element'];
    $_SESSION['idhabitacion']=$habitacion;
?>