<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    

<nav class="nav ">
    <ul class="flex">
        <li>
            <a href="dashboard.php" id=""  class="">
                <i class="fa-solid fa-house"></i>
                <span id=""  class="">Inicio</span>
            </a>
        </li>
        <li>
            <a href="reserva.php" id=""  class="">
                <i class="fa-solid fa-book"></i>
                <span id=""  class="">Reserva</span>
            </a>
        </li>
        <li>
            <a href="reservaGrupal.php" id=""  class="">
            <i class="fa-solid fa-file"></i>

                <span id=""  class="">Reserva Grupal</span>
            </a>
        </li>
        <li>
            <a href="checkIn.php" id=""  class="">
                <i class="fa-solid fa-arrow-right-to-bracket"></i>
                <span id=""  class="">Check In</span>
            </a>
        </li>
        <li>
            <a href="checkOut.php" id=""  class="">
            <i class="fa-solid fa-arrow-left"></i>
                <span id=""  class="">Check Out</span>
            </a>
        </li>
        <li>
            <a href="catHab.php" id=""  class="">
                <i class="fa-solid fa-list"></i>
                <span id=""  class="">Categoria Habitaciones</span>
            </a>
        </li>
        <li>
            <a href="habita.php" id=""  class="">
                 <i class="fa-solid fa-bed"></i>
                <span id=""  class="">Habitaciones</span>
            </a>
        </li>
        <li>
            <a href="servicios.php" id="" class="">
            <i class="fa-solid fa-bell-concierge"></i>
                <span id="1" class="click">Servicios</span>
            </a>
        </li>
<!--         <li>
            <a href="folios.php" id="" class="">
                 <i class="fa-solid fa-folder-open"></i>
                <span id="1" class="click">Folios Extras</span>
            </a>
        </li> -->
        <li>
            <a href="clien.php" id="" class="">
                <i class="fa-solid fa-user-group"></i>
                <span id="1" class="click">Clientes</span>
            </a>
        </li>
      
        <?php if ($_SESSION['tipo']==0):?>
            <li>
                <a href="user.php" id=""  class="">
                     <i class="fa-solid fa-users"></i>
                    <span id="2"  class="click">Usuarios</span>
                </a>
            </li>
        <?php endif;?>

        <?php if ($_SESSION['tipo']==0):?>
        <li>
            <a href="configuracion.php" id="" class="">
                 <i class="fa-solid fa-gear"></i>
                <span id="1" class="click">Configuración</span>
            </a>
        </li>
        <?php endif;?>
    </ul>
</nav>